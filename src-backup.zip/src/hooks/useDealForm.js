import {useState} from 'react';
import {useDispatch} from 'react-redux';
import {useMutation, useQuery} from '@tanstack/react-query';
import {api} from '../utils/api';

const getPageData = (
  formData,
  pageName,
  sectionName = 'ProductAssignmentDetails',
) => {
  // 1. Check if formData or the 'pages' array exists
  if (!formData || !formData.pages || !Array.isArray(formData.pages)) {
    return {fields: [], pageTitle: '', actions: []};
  }

  // 2. Find the correct page object in the 'pages' array
  const page = formData.pages.find(p => p.pageName === pageName);

  if (!page || !page.sections || !Array.isArray(page.sections)) {
    console.warn(`Page "${pageName}" or its sections not found in form data.`);
    return {fields: [], pageTitle: page?.title || '', actions: []};
  }

  // 3. Find the correct section object within the page's 'sections' array
  const section = page.sections.find(s => s.name === sectionName);

  // 4. Extract fields and actions
  let buttons = section?.buttons || [];

  // Adding a default Cancel button for robustness (if not provided by API)
  if (!buttons.find(b => b.buttonId === 'btn_cancel')) {
    buttons = [
      {
        buttonId: 'btn_cancel',
        label: 'Cancel',
        type: 'secondary',
        apiCallRequired: false,
        method: 'NONE',
        endpoint: null,
      },
      ...buttons,
    ];
  }

  return {
    fields: section?.fields || [],
    pageTitle: page.title || pageName,
    actions: buttons,
  };
};

export default function useDealForm() {
  const dispatch = useDispatch();
  const [manualLoading, setManualLoading] = useState(false);

  // --- 1. GET Deal Creation Form Data ---
  const {
    data: dealFormData,
    isLoading: isLoadingDealForm,
    error: dealFormError,
  } = useQuery({
    queryKey: ['PageGroup/Deal_Creation'],
    queryFn: async () => {
      try {
        const response = await api.get('PageGroup/Deal_Creation');
        const {data} = response;

        return data.data;
      } catch (error) {
        const errorMessage =
          error?.response?.data?.message ||
          error.message ||
          'Error fetching deal form structure';

        console.error(errorMessage);
        throw new Error(errorMessage);
      }
    },
    staleTime: 1000 * 60 * 5,
    cacheTime: 1000 * 60 * 10,
    refetchOnWindowFocus: false,
  });
  // ------------------------------------

  // --- 2. POST Deal Submission Mutation (UPDATED to handle FormData and dynamic endpoint) ---
  const {mutateAsync: createNewDeal} = useMutation({
    mutationKey: ['createNewDeal', 'user'],
    // Receive payload (containing fields array) and endpoint
    mutationFn: async ({payload, endpoint}) => {
      try {
        setManualLoading(true);

        //  1. Create FormData object
        const formData = new FormData();
        formData.append('pageName', payload.pageName);

        //  2. Append fields in the required fields[n].fieldName format
        payload.fields.forEach((field, index) => {
          formData.append(`fields[${index}].fieldName`, field.fieldName);
          formData.append(`fields[${index}].value`, field.value);
        });
        console.log('*************', payload);
        //  3. Use the dynamic endpoint for the POST request
        const finalEndpoint = 'deal'; //endpoint ||
        console.log('*************', finalEndpoint);
        const response = await api.post(finalEndpoint, formData, {
          headers: {
            // This header is essential for multipart/form-data
            'Content-Type': 'multipart/form-data',
          },
        });

        const {data} = response;

        return {
          ...data,
          message: data?.message || 'Deal created successfully.',
        };
      } catch (error) {
        const errorMessage = error.message || 'Deal creation failed';
        throw new Error(errorMessage);
      } finally {
        setManualLoading(false);
      }
    },
  });
  // ------------------------------------

  // Combined Loading State
  const isLoading = isLoadingDealForm || manualLoading;

  return {
    dealFormData, // The main data to build the form UI
    isLoading,
    dealFormError,
    createNewDeal, // Function to submit the form
    getPageData, // Utility to extract pages from dealFormData
  };
}
