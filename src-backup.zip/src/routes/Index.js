import React from 'react';
import {
  DefaultTheme,
  NavigationContainer,
  useNavigation,
} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {View, ActivityIndicator, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';

// --- Import all components ---
import TabsComponent from './TabsComponent';
import LoginScreen from '../views/pages/authentication/LoginScreen';
import SignupScreen from '../views/pages/authentication/SignupScreen';
import ForgotScreen from '../views/pages/authentication/ForgotScreen';
import Verification from '../views/pages/authentication/Verification';
import DealsDiscountScreen from '../views/pages/onBoardScreen/DealsDiscountScreen';
import CreateDeal from '../views/pages/onBoardScreen/CreateDeal';
import AssignProducts from '../views/pages/onBoardScreen/AssignProducts';
import BulkUpload from '../views/pages/onBoardScreen/BulkUpload';
import AddNewProduct from '../views/pages/onBoardScreen/AddNewProduct';

//Add by Rajan

import HelpSupport from '../views/pages/onBoardScreen/HelpSupport';
import CreateTicket from '../views/pages/onBoardScreen/CreateTicket';
import ViewTicket from '../views/pages/onBoardScreen/ViewTicket';
import Security from '../views/pages/onBoardScreen/Security';
import Terms from '../views/pages/onBoardScreen/TeamSupport';
import TeamSupport from '../views/pages/onBoardScreen/TeamSupport';
import CreateOperator from '../views/pages/onBoardScreen/CreateOperator';
import CreateUser from '../views/pages/onBoardScreen/CreateUser';
import MyPost from '../views/pages/onBoardScreen/MyPost';
import CreatePost from '../views/pages/onBoardScreen/CreatePost';
import EditPost from '../views/pages/onBoardScreen/EditPost';
import CreateDepartment from '../views/pages/onBoardScreen/CreateDepartment';

import CreateAd from '../views/pages/onBoardScreen/CreateAd';
import InventoryListScreen from '../views/pages/onBoardScreen/InventoryListScreen';
import ItemDetailsScreen from '../views/pages/onBoardScreen/ItemDetailsScreen';
import InventoryScreen from '../views/pages/onBoardScreen/InventoryScreen';

const Stack = createNativeStackNavigator();

// --- AuthLoadingScreen: Ensures history is cleared ---
// const AuthLoadingScreen = () => {
//   const navigation = useNavigation();
//   const {userInfo} = useSelector(({user}) => user);

//   React.useEffect(() => {
//     const destination = userInfo ? 'Dashboard' : 'LoginScreen';
//     // ✅ FIX: Use replace() to remove AuthLoadingScreen from the stack.
//     navigation.replace(destination);
//   }, [userInfo, navigation]);

//   return (
//     <View style={loadingStyles.loadingContainer}>
//       <ActivityIndicator size="large" color="#ED8A00" />
//     </View>
//   );
// };
// --------------------------------------------------------

const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: '#fff',
  },
};

export default function Routes({navigationRef, isReadyRef}) {
  const {userInfo} = useSelector(({user}) => user);
  const isLoggedIn = !!userInfo?.user?.id;
  return (
    <NavigationContainer
      ref={navigationRef}
      onReady={() => {
        isReadyRef.current = true;
      }}
      theme={theme}>
      <Stack.Navigator
        //   initialRouteName="LoginScreen"
        screenOptions={{headerShown: false}}>
        {!isLoggedIn ? (
          <>
            {/* 2. Authentication Flow Screens */}
            <Stack.Screen name="LoginScreen" component={LoginScreen} />
            <Stack.Screen name="SignupScreen" component={SignupScreen} />
            <Stack.Screen name="ForgotScreen" component={ForgotScreen} />
            <Stack.Screen name="Verification" component={Verification} />
          </>
        ) : (
          <>
            {/* 3. Main Application Flow Target */}
            {/* This screen name 'Dashboard' is the target for navigation.replace() */}
            <Stack.Screen name="Dashboard" component={TabsComponent} />

            <Stack.Screen
              name="DealsDiscountScreen"
              component={DealsDiscountScreen}
            />
            <Stack.Screen name="CreateDeal" component={CreateDeal} />
            <Stack.Screen name="AssignProducts" component={AssignProducts} />
            <Stack.Screen name="BulkUpload" component={BulkUpload} />
            <Stack.Screen name="AddNewProduct" component={AddNewProduct} />

            <Stack.Screen
              name="CreateDepartment"
              component={CreateDepartment}
            />

            <Stack.Screen name="CreateAd" component={CreateAd} />

            <Stack.Screen name="InventoryScreen" component={InventoryScreen} />

            <Stack.Screen
              name="InventoryListScreen"
              component={InventoryListScreen}
            />
            <Stack.Screen
              name="ItemDetailsScreen"
              component={ItemDetailsScreen}
            />

            {/* Add by Rajan*/}
            <Stack.Screen name="HelpSupport" component={HelpSupport} />
            <Stack.Screen name="CreateTicket" component={CreateTicket} />
            <Stack.Screen name="ViewTicket" component={ViewTicket} />
            <Stack.Screen name="Security" component={Security} />
            <Stack.Screen name="TeamSupport" component={TeamSupport} />
            <Stack.Screen name="CreateOperator" component={CreateOperator} />

            <Stack.Screen name="CreateUser" component={CreateUser} />
            <Stack.Screen name="MyPost" component={MyPost} />
            <Stack.Screen name="CreatePost" component={CreatePost} />
            <Stack.Screen name="EditPost" component={EditPost} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const loadingStyles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
});
