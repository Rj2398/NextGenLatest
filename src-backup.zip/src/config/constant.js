export const baseURL = 'https://dev-backend.nextgenedus.com/api/v1/';

export const imageBase = 'https://dev-backend.nextgenedus.com/api/v1/';

export const KEYS = {
  USER_INFO: 'USER_INFO',
  DEVICE_TOKEN: 'DEVICE_TOKEN',
};
