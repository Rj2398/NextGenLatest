// screens/CreateDeal.js 

import React, { useState, useMemo } from 'react';
import {
    View, Text, StyleSheet, ScrollView, Alert, ActivityIndicator, Platform,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

// Import necessary components and hook
import useDealForm from '../../../hooks/useDealForm';
import FormInput from '../../components/CreateDeals/FormInput'; 
import CustomSwitchButton from '../../components/CreateDeals/CustomSwitchButton'; 
import BothButtons from '../../components/CreateDeals/BothButtons'; 
import Header from '../../components/Header';

// --- Constants and Mock Components ---
const Colors = {
    darkText: '#161B25', mediumText: '#555', lightBg: '#f5f5f5',  
    white: '#fff', borderColor: '#ddd', primary: '#FF5722' 
};
const DateTimePicker = ({ isVisible, mode, value, onChange }) => {
    if (!isVisible) return null;
    Alert.alert("Native Date Picker Triggered", `Date Picker should appear now.`, [{ text: "Cancel", style: 'cancel', onPress: () => onChange(null, null) }, { text: "Select Date (Mock)", onPress: () => { onChange(null, new Date()); } }]);
    return null;
};
const formatDate = (date) => {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
};
// ------------------------------------


const CreateDeal = () => {
    const navigation = useNavigation();
    // Use the provided hook
    const { dealFormData, isLoading, dealFormError, createNewDeal } = useDealForm();

    // --- Data Parsing: Extract fields and dynamic buttons from the first page ---
    const pageData = useMemo(() => {
        if (!dealFormData) return { fields: [], pageTitle: 'Create Deal', actions: [] };

        // Target: Page 'Deal_BasicInformation', Section 'DealDetails'
        const page = dealFormData.pages.find(p => p.pageName === 'Deal_BasicInformation');
        const section = page?.sections.find(s => s.name === 'DealDetails');
        
        let buttons = section?.buttons || [];
        
        // Manually adding the 'Cancel' button (Secondary type)
        if (!buttons.find(b => b.buttonId === 'btn_cancel')) {
            buttons = [
                { buttonId: 'btn_cancel', label: 'Cancel', type: 'secondary', apiCallRequired: false, method: 'NONE', endpoint: null },
                ...buttons
            ];
        }

        return {
            fields: section?.fields || [],
            pageTitle: page?.title || 'Deal Basic Information',
            actions: buttons,
        };
    }, [dealFormData]);

    // --- State & Initialization ---
    const initialState = useMemo(() => {
       return pageData.fields.reduce((acc, field) => {
           let defaultValue = field.defaultValue !== null ? String(field.defaultValue) : (field.placeholder || '');
           if (field.fieldName === 'is_active') { 
               defaultValue = field.defaultValue !== null ? field.defaultValue : true; 
           } else if (field.fieldType === 'DateTime') { 
               defaultValue = 'DD/MM/YYYY'; 
           } else if (field.fieldType === 'Select' && !defaultValue) {
               defaultValue = field.placeholder || 'Select value';
           }
           acc[field.fieldName] = defaultValue;
           return acc;
       }, {});
    }, [pageData.fields]);

    const [formData, setFormData] = useState(initialState);
    const [isDatePickerVisible, setDatePickerVisible] = useState(false);
    const [currentDateField, setCurrentDateField] = useState(null); 
    const [selectedDateValue, setSelectedDateValue] = useState(new Date()); 

    React.useEffect(() => { setFormData(initialState); }, [initialState]); 
    
    const handleChange = (fieldName, value) => setFormData(prev => ({ ...prev, [fieldName]: value }));

    
    
    // --- DYNAMIC BUTTON CLICK HANDLER (Endpoint Logic) ---
    const handleActionClick = async (action) => {
        
        // 1. Handle local 'Cancel' action
        if (action.buttonId === 'btn_cancel' || action.method === 'NONE') {
          //  Alert.alert("Cancel", "Deal creation cancelled.");
            navigation.goBack();
            return;
        }
    
        
        // Define the next page route name based on API data structure
        // The next page is 'Deal_ProductAssignment' (pageId: 101)
        const nextScreen = 'AssignProducts'; 
        
        // 3. Conditional Logic: Check if 'endpoint' is defined or empty ("")
        
        if (action.endpoint === "" || action.endpoint === null) {
            // A. ENDPOINT IS EMPTY/NULL -> PERFORM NAVIGATION (As requested)
            
         //   Alert.alert("Navigation", `Navigating to next step: ${action.label}`);
            
            // Navigate to the next page
            // NOTE: Ensure 'DealProductAssignment' is a valid route name in your navigator
            navigation.navigate(nextScreen, { dealDetails: formData }); 
            
        } else {
            // B. ENDPOINT IS NOT EMPTY -> PERFORM API CALL (Placehoder)
            
            Alert.alert("Action Required", `API Call needed for endpoint: ${action.endpoint}. Skipping for now.`);
            
            // NOTE: We will implement the API call logic later
            // try {
            //     const result = await createNewDeal(formData); 
            //     Alert.alert("Success", result.message || `${action.label} completed!`);
            //     navigation.navigate(nextScreen); 
            // } catch (e) {
            //     Alert.alert("Error", e.message || `Failed to execute action: ${action.label}`);
            // }
        }
    };
    // -----------------------------------------------------


    // --- Render Form Fields (Logic remains the same) ---
    const renderFormFields = () => {
        const fields = pageData.fields;
        
        // Filter fields for correct rendering
        const dateFields = fields.filter(f => f.fieldType === 'DateTime');
        const standardFields = fields.filter(f => f.fieldType !== 'DateTime' && f.fieldName !== 'is_active'); 
        const switchField = fields.find(f => f.fieldName === 'is_active'); 
        
        const elements = [];
        const totalFields = standardFields.length;

        // 1. Standard Fields (Text, Select, Decimal, etc.)
        standardFields.forEach((field, index) => {
            const isSelectField = field.fieldType === 'Select' || field.fieldName === 'currency_code'; 
            const fieldZIndex = totalFields - index;
            
            elements.push(
                <FormInput
                    key={field.fieldName}
                    fieldType={field.fieldType} 
                    label={field.localization?.localizedText || field.label}
                    placeholder={field.localization?.localizedPlaceholder || field.placeholder || ''}
                    isRequired={field.isRequired}
                    value={formData[field.fieldName]} 
                    options={isSelectField ? field.options : []}
                    inputZIndex={fieldZIndex}
                    onChangeText={(text) => handleChange(field.fieldName, text)}
                    keyboardType={field.fieldType === 'Decimal' ? 'numeric' : 'default'}
                />
            );
        });

        // 2. Date Fields (DateTime)
         if (dateFields.length > 0) {
             const dateInputs = dateFields.map(field => (
                <View key={field.fieldName} style={styles.datePickerContainer}>
                    <FormInput
                        fieldType={field.fieldType}
                        label={field.localization?.localizedText || field.label}
                        placeholder={'DD/MM/YYYY'}
                        isRequired={field.isRequired}
                        value={formData[field.fieldName]}
                        onSelectPress={() => {
                            setDatePickerVisible(true);
                            setCurrentDateField(field.fieldName);
                        }}
                    />
                </View>
            ));
            
             elements.push(<View key="date-row" style={styles.dateRow}>{dateInputs}</View>);
        }

        // 3. Switch Field (Checkbox)
        if (switchField) {
             elements.push(
                <CustomSwitchButton
                    key={switchField.fieldName}
                    label={switchField.localization?.localizedText || switchField.label}
                    value={formData[switchField.fieldName]}
                    onValueChange={(value) => handleChange(switchField.fieldName, value)}
                />
            );
        }
        
        return elements;
    };


    // --- Loading and Error UI ---
    if (isLoading) {
        return (
            <View style={styles.centerContainer}>
                <ActivityIndicator size="large" color={Colors.primary} />
                <Text style={styles.loadingText}>Fetching Deal Form...</Text>
            </View>
        );
    }

    if (dealFormError || !dealFormData || pageData.fields.length === 0) {
        return (
            <View style={styles.centerContainer}>
                <Text style={styles.errorText}>Error loading form data or no fields found.</Text>
            </View>
        );
    }
    // ----------------------------

    return (
        <View style={styles.container}>
            
            <Header title={pageData.pageTitle || "Create Deals"} onBackPress={() => handleActionClick({ buttonId: 'btn_cancel', method: 'NONE' })} />

            <ScrollView contentContainerStyle={styles.scrollViewContent} showsVerticalScrollIndicator={false}>
                <View style={styles.card}>
                    
                    {renderFormFields()}

                    {/* Renders buttons dynamically based on API data and sorting */}
                    <BothButtons 
                        actions={pageData.actions} 
                        onActionClick={handleActionClick} 
                    />
                </View>
            </ScrollView>
            
            {/* Native Date Picker Component */}
            {isDatePickerVisible && (
                 <DateTimePicker
                    isVisible={true} 
                    mode="date"
                    value={selectedDateValue} 
                    onChange={(event, date) => {
                        setDatePickerVisible(false);
                        if (date) handleChange(currentDateField, formatDate(date));
                    }}
                />
            )}
            
        </View>
    );
};

export default CreateDeal;


// --- STYLESHEETS (Remains the same) ---
const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: Colors.lightBg },
    scrollViewContent: { paddingHorizontal: 20, paddingBottom: 40, paddingTop: 10 },
    card: {
        backgroundColor: Colors.white, borderRadius: 12, padding: 20,
        ...Platform.select({ ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 }, android: { elevation: 3 } }),
    },
    dateRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 5 },
    datePickerContainer: { flex: 1, marginRight: 10 },
    centerContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.lightBg },
    loadingText: { marginTop: 10, fontSize: 16, color: Colors.darkText },
    errorText: { fontSize: 18, color: 'red', fontWeight: 'bold', marginBottom: 10 },
});