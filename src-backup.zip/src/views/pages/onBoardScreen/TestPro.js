// import {
//   StyleSheet,
//   Text,
//   View,
//   ScrollView,
//   TouchableOpacity,
//   Alert,
//   Platform,
// } from 'react-native';
// import React, {useState, useMemo, useEffect} from 'react';
// // Assuming these paths are correct in your React Native project
// import PriceVariantGroup from '../../components/PriceVariantGroup';
// import ProductImagePicker from '../../components/ProductImagePicker';
// import useProductModal from '../../../hooks/useProduct';
// import InputGroup from '../../components/InputGroup';
// import DescriptionInput from '../../components/DescriptionInput';
// import DropdownGroup from '../../components/DropdownGroup';
// import CheckboxGroup from '../../components/CheckBoxGroup';
// import NumberInputGroup from '../../components/NumberInputGroup';
// import {baseURL} from '../../../config/constant';
// import {fetchChildCategories} from '../../../utils/apiFunction';
// import Header from '../../components/Header';
// import Loader from '../../components/Loader';

// // Utility function (kept outside the component)

// // =========================================================================
// // MAIN COMPONENT
// // =========================================================================
// const AddNewProduct = () => {
//   const [subcategories, setSubcategories] = useState([]);
//   const [VariantUI, setVariantUI] = useState(null); // Used for the attributes structure

//   const {
//     getAllProductModal,
//     basicInformation,
//     getCategory,
//     isLoadinAllModal,
//     isLoading: isSubmitting,
//   } = useProductModal();

//   const [formData, setFormData] = useState({});

//   console.log(formData,"**************************");
//   const [productVariants, setProductVariants] = useState([]);

//   // State to manage dynamically added variant pages
//   const [variantPages, setVariantPages] = useState([]);

//   // Field object to be conditionally injected
//   const newFieldObject = {
//     id: 1040,
//     fieldName: 'attributes',
//     fieldType: 'Page', // This is the placeholder that triggers VariantUI rendering
//     isRequired: true,
//     isReadOnly: false,
//     displayOrder: 1,
//     isVisible: true,
//     label: 'Product Attributes*',
//     placeholder: 'Enter product attributes',
//     helpText: 'Attributes of the product',
//     displayName: '',
//     regexPattern: "^[A-Za-z0-9\\s\\-\\&'\\.,()]{2,200}$",
//     defaultValue: null,
//     maxLength: null,
//     minLength: null,
//     otpLength: null,
//     options: null,
//     fileConfig: null,
//     endpoint:
//       'https://dev-backend.nextgenedus.com/api/v1/Products/variant-page-with-attributes',
//     fieldMetadata: null,
//     localization: {
//       languageCode: 'en',
//       countryCode: 'AE',
//       localizedText: 'Product Attributes',
//       localizedPlaceholder: null,
//       localizedHelpText: null,
//     },
//     isDefault: false,
//     isOpenView: false,
//   };

//   // 1. Refactor useMemo to extract the page template and all other non-variant pages
//   const {nonVariantPages, variantPageTemplate} = useMemo(() => {
//     const rawPages = getAllProductModal?.pages || [];
//     const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);

//     const nonVariantPages = [];
//     let variantTemplate = null;

//     sortedPages.forEach(page => {
//       // Deep copy to ensure safe manipulation
//       const pageCopy = JSON.parse(JSON.stringify(page));

//       const isTargetPage = pageCopy.pageName === 'Ecommerce_Product_Variant';

//       if (isTargetPage) {
//         // Inject the 'attributes' field into the first section of the template
//         if (pageCopy.sections && pageCopy.sections.length > 0) {
//           const targetSection = pageCopy.sections[0];
//           const existingFields = targetSection.fields || [];

//           // Prepend the new field object
//           const combinedFields = [newFieldObject, ...existingFields];

//           // Sort the entire combined array by displayOrder
//           const sortedFields = combinedFields.sort(
//             (a, b) => a.displayOrder - b.displayOrder,
//           );

//           // Update the fields array of the first section
//           pageCopy.sections[0].fields = sortedFields;
//         }

//         variantTemplate = pageCopy;
//       } else {
//         // Standard non-variant page
//         nonVariantPages.push(pageCopy);
//       }
//     });

//     return {
//       nonVariantPages,
//       variantPageTemplate: variantTemplate,
//     };
//   }, [getAllProductModal]);

//   // 2. Initialize the dynamic pages when the template is ready
//   useEffect(() => {
//     if (variantPageTemplate && variantPages.length === 0) {
//       // Add the first instance of the variant page with a unique ID
//       setVariantPages([{...variantPageTemplate, uniqueId: Date.now()}]);
//     }
//   }, [variantPageTemplate, variantPages.length]);

//   // 3. Handler to add a new variant page instance
//   const handleAddNewVariantPage = () => {
//     if (!variantPageTemplate) {
//       Alert.alert('Error', 'Variant page template not loaded.');
//       return;
//     }

//     // Create a new unique instance of the template page
//     const newPageInstance = {
//       ...JSON.parse(JSON.stringify(variantPageTemplate)), // Deep copy sections and fields
//       uniqueId: Date.now() + Math.random(), // Ensure a unique key
//     };

//     setVariantPages(prev => [...prev, newPageInstance]);
//   };

//   const handleFieldChange = (fieldName, value) => {
//     // ⚠️ IMPORTANT: For dynamically added pages, you need to scope the fieldName
//     // using the page's uniqueId to prevent one page from overwriting another's data.
//     // E.g., const key = pageUniqueId ? `${pageUniqueId}_${fieldName}` : fieldName;
//     setFormData(prev => ({...prev, [fieldName]: value}));
//   };

//   const renderField = field => {
//     const commonProps = {
//       key: field.id,
//       label: field.label,
//       placeholder: field.placeholder,
//       isRequired: field.isRequired,
//       value: formData[field.fieldName] || field.defaultValue,
//       onChange: value => handleFieldChange(field.fieldName, value),
//       onChangeText: text => handleFieldChange(field.fieldName, text),
//     };

//     switch (field.fieldType) {
//       case 'Text':
//         return <InputGroup {...commonProps} />;
//       case 'Number':
//         return <NumberInputGroup {...commonProps} />;
//       case 'Checkbox':
//         return (
//           <CheckboxGroup {...commonProps} onChange={commonProps.onChange} />
//         );
//       case 'TextArea':
//         return <DescriptionInput {...commonProps} />;
//       case 'Page':
//         if (field.fieldName === 'attributes') {
//           // Renders the entire VariantUI block (sections + fields) here
//           return VariantUI?.sections ? (
//             <View key={field.id} style={styles.variantAttributesBlock}>
//               <Text style={styles.variantBlockTitle}>
//                 {VariantUI.title || field.label}
//               </Text>

//               {VariantUI.sections.map(section => (
//                 <View key={section.id} style={styles.sectionContainer}>
//                   <Text style={styles.sectionTitle}>{section.title}</Text>

//                   {/* Recursively reuse renderField for the variant attribute fields */}
//                   {section.fields.map(
//                     attributeField =>
//                       attributeField.isVisible !== false &&
//                       renderField(attributeField),
//                   )}
//                 </View>
//               ))}
//             </View>
//           ) : (
//             <Text style={styles.loadingText}>Loading Variant UI...</Text>
//           );
//         }
//         return null;

//       case 'Select':
//         // --- Data Mapping (For the initial parent category dropdown) ---
//         const rawCategoryItems = getCategory?.items ?? [];
//         const mappedCategoryOptions = rawCategoryItems
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- Handler to Fetch Children and Update State ---
//         const handleCategorySelect = async selectedId => {
//           // 1. Update the form state for the currently selected dropdown (Category ID)
//           commonProps.onChange(selectedId);

//           try {
//             // 2. Fetch the child data (Subcategories)
//             const response = await fetchChildCategories(
//               'Category',
//               selectedId,
//               'parentId', // Query key is 'parentId'
//             );

//             // 3. Fetch Variant UI data (Assuming 'categoryId' is the key here)
//             const categoryData = await fetchChildCategories(
//               'Products/variant-page-with-attributes',
//               selectedId, // Use the actual selectedId here
//               'categoryId',
//             );
//             setVariantUI(categoryData?.data);

//             const subcategoryItems = response?.data?.items ?? [];
//             setSubcategories(subcategoryItems);
//           } catch (error) {
//             console.error('Failed to fetch data:', error);
//             setSubcategories([]);
//           }
//         };

//         // --- Subcategory Options Mapping ---
//         const mappedSubcategoryOptions = subcategories
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- RENDERING LOGIC ---
//         if (field?.fieldName === 'category_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedCategoryOptions}
//               onSelect={handleCategorySelect} // Triggers fetch
//               onChangeText={() => {}}
//             />
//           );
//         } else if (field?.fieldName === 'subcategory_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedSubcategoryOptions}
//               onSelect={commonProps.onChange}
//               onChangeText={() => {}}
//             />
//           );
//         }

//         // For all other 'Select' fields
//         return (
//           <DropdownGroup
//             {...commonProps}
//             options={field.options ?? []}
//             onSelect={commonProps.onChange}
//             onChangeText={() => {}}
//           />
//         );

//       case 'File':
//         return (
//           <ProductImagePicker
//             {...commonProps}
//             key={field.id}
//             images={formData[field.fieldName] || []}
//             setImages={commonProps.onChange}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // --- 4. SUBMISSION HANDLER ---
//   const handleSubmit = async () => {

//   };

//   return (
//     <ScrollView contentContainerStyle={styles.contentContainer}>
//       <Header title={'Add New Product'} onBackPress={true} />
//       <Loader visible={isLoadinAllModal || isSubmitting} />

//       {/* 2. RENDERING: Map over the non-variant pages */}
//       {nonVariantPages.map(page => (
//         <View key={page.pageId}>
//           <View style={styles.headerContainer}>
//             <Text style={styles.pageTitle}>{page.title}</Text>
//           </View>

//           {page.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>
//               {section.description && (
//                 <Text style={styles.sectionDescription}>
//                   {section.description}
//                 </Text>
//               )}

//               {/* Render fields within the section */}
//               {section.fields.map(
//                 field => field.isVisible !== false && renderField(field),
//               )}
//             </View>
//           ))}
//         </View>
//       ))}

//       {/* 3. RENDERING: Dynamic Variant Pages (The page that can be cloned) */}
//       {variantPages.map((page, index) => (
//         <View key={page.uniqueId} style={styles.variantPageWrapper}>
//           <View style={styles.headerContainer}>
//             <Text style={styles.pageTitle}>
//               {page.title} {index > 0 ? `(Instance ${index + 1})` : ''}
//             </Text>

//             {/* Conditional "Add New" button ONLY on the first instance */}
//             {index === 0 && (
//               <TouchableOpacity
//                 style={styles.addButton}
//                 onPress={handleAddNewVariantPage}>
//                 <Text style={styles.addButtonText}>+ Add New</Text>
//               </TouchableOpacity>
//             )}
//           </View>

//           {page.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>
//               {section.description && (
//                 <Text style={styles.sectionDescription}>
//                   {section.description}
//                 </Text>
//               )}

//               {/* Render sorted fields within the section */}
//               {section.fields.map(
//                 // Note: The renderField call for 'attributes' renders the PriceVariantGroup
//                 field => field.isVisible !== false && renderField(field),
//               )}
//             </View>
//           ))}
//         </View>
//       ))}

//       <TouchableOpacity
//         style={[
//           styles.submitButton,
//           isSubmitting && styles.submitButtonDisabled,
//         ]}
//         onPress={handleSubmit}
//         disabled={isSubmitting}>
//         <Text style={styles.submitButtonText}>
//           {isSubmitting ? 'SAVING...' : 'SAVE PRODUCT'}
//         </Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// export default AddNewProduct;

// // =========================================================================
// // STYLES
// // =========================================================================
// const styles = StyleSheet.create({
//   contentContainer: {
//     padding: 20,
//     backgroundColor: '#fff',
//     minHeight: '100%',
//   },
//   variantPageWrapper: {
//     marginBottom: 30, // Space between dynamically added pages
//   },
//   headerContainer: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: 15,
//   },
//   addButtonText: {
//     color: '#FFFFFF',
//     fontSize: 14,
//     fontWeight: '600',
//   },
//   addButton: {
//     backgroundColor: '#F89941',
//     borderRadius: 5,
//     width: 100,
//     height: 40,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   pageTitle: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     marginTop: 10,
//     paddingBottom: 5,
//     color: '#333',
//   },
//   sectionContainer: {
//     marginBottom: 25,
//     paddingBottom: 15,
//     borderBottomWidth: StyleSheet.hairlineWidth,
//     borderBottomColor: '#ccc',
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '700',
//     color: '#333',
//     marginBottom: 4,
//   },
//   sectionDescription: {
//     fontSize: 14,
//     color: '#888',
//     marginBottom: 15,
//   },
//   submitButton: {
//     backgroundColor: '#F89941',
//     padding: 15,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 30,
//     marginBottom: 50,
//   },
//   submitButtonDisabled: {
//     backgroundColor: '#FFA07A',
//     opacity: 0.7,
//   },
//   submitButtonText: {
//     color: '#FFFFFF',
//     fontSize: 16,
//     fontWeight: '700',
//   },
//   // Styles for Variant Attributes Block
//   variantAttributesBlock: {
//     marginTop: 20,
//     padding: 15,
//     borderRadius: 8,
//     backgroundColor: '#F9FAFB', // Light gray background
//     borderWidth: 1,
//     borderColor: '#E0E0E0',
//   },
//   variantBlockTitle: {
//     fontSize: 18,
//     fontWeight: '800',
//     color: '#333',
//     marginBottom: 15,
//   },
//   loadingText: {
//     fontSize: 14,
//     color: '#999',
//     padding: 10,
//     backgroundColor: '#f0f0f0',
//     borderRadius: 5,
//     textAlign: 'center',
//   },
// });

// import {
//   StyleSheet,
//   Text,
//   View,
//   ScrollView,
//   TouchableOpacity,
//   Alert,
//   Platform,
// } from 'react-native';
// import React, {useState, useMemo, useEffect} from 'react';
// // Assuming these paths are correct in your React Native project
// import PriceVariantGroup from '../../components/PriceVariantGroup';
// import ProductImagePicker from '../../components/ProductImagePicker';
// import useProductModal from '../../../hooks/useProduct';
// import InputGroup from '../../components/InputGroup';
// import DescriptionInput from '../../components/DescriptionInput';
// import DropdownGroup from '../../components/DropdownGroup';
// import CheckboxGroup from '../../components/CheckBoxGroup';
// import NumberInputGroup from '../../components/NumberInputGroup';
// import {baseURL} from '../../../config/constant';
// import {fetchChildCategories} from '../../../utils/apiFunction';
// import Header from '../../components/Header';
// import Loader from '../../components/Loader';

// // Utility function (kept outside the component)
// function createProductFormData(payload) {
//   const formData = new FormData();

//   // Basic product fields
//   formData.append('productId', payload.productId);
//   formData.append('name', payload.name);
//   formData.append('category', payload.category);
//   formData.append('description', payload.description);
//   formData.append('brand', payload.brand);
//   formData.append('gst_number', payload.gst_number);
//   formData.append('country_of_origin', payload.country_of_origin);

//   // Variants (Note: Logic needs expansion to gather variants from all dynamic pages)
//   payload.variants.forEach((variant, index) => {
//     formData.append(`variants[${index}][size]`, variant.size);
//     formData.append(`variants[${index}][color]`, variant.color);
//     formData.append(`variants[${index}][price]`, variant.price);

//     if (variant.variant_image) {
//       formData.append(`variants[${index}][variant_image]`, {
//         uri: variant.variant_image.uri,
//         type: variant.variant_image.type,
//         name: variant.variant_image.name,
//       });
//     }
//   });

//   return formData;
// }

// // =========================================================================
// // MAIN COMPONENT
// // =========================================================================
// const AddNewProduct = () => {
//   const [subcategories, setSubcategories] = useState([]);
//   const [VariantUI, setVariantUI] = useState(null); // Used for the attributes structure

//   const {
//     getAllProductModal,
//     basicInformation,
//     getCategory,
//     isLoadinAllModal,
//     isLoading: isSubmitting,
//   } = useProductModal();

//   const [formData, setFormData] = useState({});
//   const [productVariants, setProductVariants] = useState([]);

//   // State to manage dynamically added variant pages
//   const [variantPages, setVariantPages] = useState([]);

//   // Field object to be conditionally injected
//   const newFieldObject = {
//     id: 1040,
//     fieldName: 'attributes',
//     fieldType: 'Page', // This is the placeholder that triggers VariantUI rendering
//     isRequired: true,
//     isReadOnly: false,
//     displayOrder: 1,
//     isVisible: true,
//     label: 'Product Attributes*',
//     placeholder: 'Enter product attributes',
//     helpText: 'Attributes of the product',
//     displayName: '',
//     regexPattern: "^[A-Za-z0-9\\s\\-\\&'\\.,()]{2,200}$",
//     defaultValue: null,
//     maxLength: null,
//     minLength: null,
//     otpLength: null,
//     options: null,
//     fileConfig: null,
//     endpoint:
//       'https://dev-backend.nextgenedus.com/api/v1/Products/variant-page-with-attributes',
//     fieldMetadata: null,
//     localization: {
//       languageCode: 'en',
//       countryCode: 'AE',
//       localizedText: 'Product Attributes',
//       localizedPlaceholder: null,
//       localizedHelpText: null,
//     },
//     isDefault: false,
//     isOpenView: false,
//   };

//   // 1. Refactor useMemo to extract the page template and all other non-variant pages
//   const {nonVariantPages, variantPageTemplate} = useMemo(() => {
//     const rawPages = getAllProductModal?.pages || [];
//     const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);

//     const nonVariantPages = [];
//     let variantTemplate = null;

//     sortedPages.forEach(page => {
//       // Deep copy to ensure safe manipulation
//       const pageCopy = JSON.parse(JSON.stringify(page));

//       const isTargetPage = pageCopy.pageName === 'Ecommerce_Product_Variant';

//       if (isTargetPage) {
//         // Inject the 'attributes' field into the first section of the template
//         if (pageCopy.sections && pageCopy.sections.length > 0) {
//           const targetSection = pageCopy.sections[0];
//           const existingFields = targetSection.fields || [];

//           // Prepend the new field object
//           const combinedFields = [newFieldObject, ...existingFields];

//           // Sort the entire combined array by displayOrder
//           const sortedFields = combinedFields.sort(
//             (a, b) => a.displayOrder - b.displayOrder,
//           );

//           // Update the fields array of the first section
//           pageCopy.sections[0].fields = sortedFields;
//         }

//         variantTemplate = pageCopy;
//       } else {
//         // Standard non-variant page
//         nonVariantPages.push(pageCopy);
//       }
//     });

//     return {
//       nonVariantPages,
//       variantPageTemplate: variantTemplate,
//     };
//   }, [getAllProductModal]);

//   // 2. Initialize the dynamic pages when the template is ready
//   useEffect(() => {
//     if (variantPageTemplate && variantPages.length === 0) {
//       // Add the first instance of the variant page with a unique ID
//       setVariantPages([{...variantPageTemplate, uniqueId: Date.now()}]);
//     }
//   }, [variantPageTemplate, variantPages.length]);

//   // 3. Handler to add a new variant page instance
//   const handleAddNewVariantPage = () => {
//     if (!variantPageTemplate) {
//       Alert.alert('Error', 'Variant page template not loaded.');
//       return;
//     }

//     // Create a new unique instance of the template page
//     const newPageInstance = {
//       ...JSON.parse(JSON.stringify(variantPageTemplate)), // Deep copy sections and fields
//       uniqueId: Date.now() + Math.random(), // Ensure a unique key
//     };

//     setVariantPages(prev => [...prev, newPageInstance]);
//   };

//   const handleFieldChange = (fieldName, value) => {
//     // ⚠️ IMPORTANT: For dynamically added pages, you need to scope the fieldName
//     // using the page's uniqueId to prevent one page from overwriting another's data.
//     // E.g., const key = pageUniqueId ? `${pageUniqueId}_${fieldName}` : fieldName;
//     setFormData(prev => ({...prev, [fieldName]: value}));
//   };

//   const renderField = field => {
//     const commonProps = {
//       key: field.id,
//       label: field.label,
//       placeholder: field.placeholder,
//       isRequired: field.isRequired,
//       value: formData[field.fieldName] || field.defaultValue,
//       onChange: value => handleFieldChange(field.fieldName, value),
//       onChangeText: text => handleFieldChange(field.fieldName, text),
//     };

//     switch (field.fieldType) {
//       case 'Text':
//         return <InputGroup {...commonProps} />;
//       case 'Number':
//         return <NumberInputGroup {...commonProps} />;
//       case 'Checkbox':
//         return (
//           <CheckboxGroup {...commonProps} onChange={commonProps.onChange} />
//         );
//       case 'TextArea':
//         return <DescriptionInput {...commonProps} />;
//       case 'Page':
//         if (field.fieldName === 'attributes') {
//           // Renders the entire VariantUI block (sections + fields) here
//           return VariantUI?.sections ? (
//             <View key={field.id} style={styles.variantAttributesBlock}>
//               <Text style={styles.variantBlockTitle}>
//                 {VariantUI.title || field.label}
//               </Text>

//               {VariantUI.sections.map(section => (
//                 <View key={section.id} style={styles.sectionContainer}>
//                   <Text style={styles.sectionTitle}>{section.title}</Text>

//                   {/* Recursively reuse renderField for the variant attribute fields */}
//                   {section.fields.map(
//                     attributeField =>
//                       attributeField.isVisible !== false &&
//                       renderField(attributeField),
//                   )}
//                 </View>
//               ))}

//               {/* Render the core variant group UI */}
//               {/* <PriceVariantGroup
//                 variants={productVariants}
//                 setVariants={setProductVariants}
//               /> */}
//             </View>
//           ) : (
//             <Text style={styles.loadingText}>Loading Variant UI...</Text>
//           );
//         }
//         return null;

//       case 'Select':
//         // --- Data Mapping (For the initial parent category dropdown) ---
//         const rawCategoryItems = getCategory?.items ?? [];
//         const mappedCategoryOptions = rawCategoryItems
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- Handler to Fetch Children and Update State ---
//         const handleCategorySelect = async selectedId => {
//           // 1. Update the form state for the currently selected dropdown (Category ID)
//           commonProps.onChange(selectedId);

//           try {
//             // 2. Fetch the child data (Subcategories)
//             const response = await fetchChildCategories(
//               'Category',
//               selectedId,
//               'parentId', // Query key is 'parentId'
//             );

//             // 3. Fetch Variant UI data (Assuming 'categoryId' is the key here)
//             const categoryData = await fetchChildCategories(
//               'Products/variant-page-with-attributes',
//               selectedId, // Use the actual selectedId here
//               'categoryId',
//             );
//             setVariantUI(categoryData?.data);

//             const subcategoryItems = response?.data?.items ?? [];
//             setSubcategories(subcategoryItems);
//           } catch (error) {
//             console.error('Failed to fetch data:', error);
//             setSubcategories([]);
//           }
//         };

//         // --- Subcategory Options Mapping ---
//         const mappedSubcategoryOptions = subcategories
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- RENDERING LOGIC ---
//         if (field?.fieldName === 'category_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedCategoryOptions}
//               onSelect={handleCategorySelect} // Triggers fetch
//               onChangeText={() => {}}
//             />
//           );
//         } else if (field?.fieldName === 'subcategory_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedSubcategoryOptions}
//               onSelect={commonProps.onChange}
//               onChangeText={() => {}}
//             />
//           );
//         }

//         // For all other 'Select' fields
//         return (
//           <DropdownGroup
//             {...commonProps}
//             options={field.options ?? []}
//             onSelect={commonProps.onChange}
//             onChangeText={() => {}}
//           />
//         );

//       case 'File':
//         return (
//           <ProductImagePicker
//             {...commonProps}
//             key={field.id}
//             images={formData[field.fieldName] || []}
//             setImages={commonProps.onChange}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // --- 4. SUBMISSION HANDLER ---
//   const handleSubmit = async () => {
//     const payload = {
//       productId: 'new_temp_id',
//       name: formData.name,
//       category: formData.category_id,
//       variants: productVariants,
//       // ⚠️ Remember to gather data from all items in variantPages here
//     };

//     if (!payload || !payload.name || !payload.category) {
//       Alert.alert('Missing Data', 'Please fill in required basic information.');
//       return;
//     }

//     try {
//       const submissionData = createProductFormData(payload);
//       const response = await basicInformation(submissionData);

//       if (response?.success) {
//         Alert.alert('Success', 'Product submitted successfully!');
//         console.log('✅ Product submitted successfully:', response);
//       } else {
//         Alert.alert(
//           'Submission Failed',
//           response?.message || 'An unknown error occurred.',
//         );
//         console.warn('⚠️ Failed to submit product:', response);
//       }
//     } catch (error) {
//       console.error('❌ Error submitting product:', error);
//       Alert.alert(
//         'API Error',
//         error.message || 'Could not connect to the server.',
//       );
//     }
//   };

//   return (
//     <ScrollView contentContainerStyle={styles.contentContainer}>
//       <Header title={'Add New Product'} onBackPress={true} />
//       <Loader visible={isLoadinAllModal || isSubmitting} />

//       {/* 2. RENDERING: Map over the non-variant pages */}
//       {nonVariantPages.map(page => (
//         <View key={page.pageId}>
//           <View style={styles.headerContainer}>
//             <Text style={styles.pageTitle}>{page.title}</Text>
//           </View>

//           {page.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>
//               {section.description && (
//                 <Text style={styles.sectionDescription}>
//                   {section.description}
//                 </Text>
//               )}

//               {/* Render fields within the section */}
//               {section.fields.map(
//                 field => field.isVisible !== false && renderField(field),
//               )}
//             </View>
//           ))}
//         </View>
//       ))}

//       {/* 3. RENDERING: Dynamic Variant Pages (The page that can be cloned) */}
//       {variantPages.map((page, index) => (
//         <View key={page.uniqueId} style={styles.variantPageWrapper}>
//           <View style={styles.headerContainer}>
//             <Text style={styles.pageTitle}>
//               {page.title} {index > 0 ? `(Instance ${index + 1})` : ''}
//             </Text>

//             {/* Conditional "Add New" button ONLY on the first instance */}
//             {index === 0 && (
//               <TouchableOpacity
//                 style={styles.addButton}
//                 onPress={handleAddNewVariantPage}>
//                 <Text style={styles.addButtonText}>+ Add New</Text>
//               </TouchableOpacity>
//             )}
//           </View>

//           {page.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>
//               {section.description && (
//                 <Text style={styles.sectionDescription}>
//                   {section.description}
//                 </Text>
//               )}

//               {/* Render sorted fields within the section */}
//               {section.fields.map(
//                 // Note: The renderField call for 'attributes' renders the PriceVariantGroup
//                 field => field.isVisible !== false && renderField(field),
//               )}
//             </View>
//           ))}
//         </View>
//       ))}

//       <TouchableOpacity
//         style={[
//           styles.submitButton,
//           isSubmitting && styles.submitButtonDisabled,
//         ]}
//         onPress={handleSubmit}
//         disabled={isSubmitting}>
//         <Text style={styles.submitButtonText}>
//           {isSubmitting ? 'SAVING...' : 'SAVE PRODUCT'}
//         </Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// export default AddNewProduct;

// // =========================================================================
// // STYLES
// // =========================================================================
// const styles = StyleSheet.create({
//   contentContainer: {
//     padding: 20,
//     backgroundColor: '#fff',
//     minHeight: '100%',
//   },
//   variantPageWrapper: {
//     marginBottom: 30, // Space between dynamically added pages
//   },
//   headerContainer: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: 15,
//   },
//   addButtonText: {
//     color: '#FFFFFF',
//     fontSize: 14,
//     fontWeight: '600',
//   },
//   addButton: {
//     backgroundColor: '#F89941',
//     borderRadius: 5,
//     width: 100,
//     height: 40,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   pageTitle: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     marginTop: 10,
//     paddingBottom: 5,
//     color: '#333',
//   },
//   sectionContainer: {
//     marginBottom: 25,
//     paddingBottom: 15,
//     borderBottomWidth: StyleSheet.hairlineWidth,
//     borderBottomColor: '#ccc',
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '700',
//     color: '#333',
//     marginBottom: 4,
//   },
//   sectionDescription: {
//     fontSize: 14,
//     color: '#888',
//     marginBottom: 15,
//   },
//   submitButton: {
//     backgroundColor: '#F89941',
//     padding: 15,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 30,
//     marginBottom: 50,
//   },
//   submitButtonDisabled: {
//     backgroundColor: '#FFA07A',
//     opacity: 0.7,
//   },
//   submitButtonText: {
//     color: '#FFFFFF',
//     fontSize: 16,
//     fontWeight: '700',
//   },
//   // Styles for Variant Attributes Block
//   variantAttributesBlock: {
//     marginTop: 20,
//     padding: 15,
//     borderRadius: 8,
//     backgroundColor: '#F9FAFB', // Light gray background
//     borderWidth: 1,
//     borderColor: '#E0E0E0',
//   },
//   variantBlockTitle: {
//     fontSize: 18,
//     fontWeight: '800',
//     color: '#333',
//     marginBottom: 15,
//   },
//   loadingText: {
//     fontSize: 14,
//     color: '#999',
//     padding: 10,
//     backgroundColor: '#f0f0f0',
//     borderRadius: 5,
//     textAlign: 'center',
//   },
// });

// import {
//   StyleSheet,
//   Text,
//   View,
//   ScrollView,
//   TouchableOpacity,
//   Alert,
//   Platform,
// } from 'react-native';
// import React, {useState, useMemo} from 'react';
// // Assuming these paths are correct
// import PriceVariantGroup from '../../components/PriceVariantGroup';
// import ProductImagePicker from '../../components/ProductImagePicker';
// import useProductModal from '../../../hooks/useProduct';
// import InputGroup from '../../components/InputGroup';
// import DescriptionInput from '../../components/DescriptionInput';
// import DropdownGroup from '../../components/DropdownGroup';
// import CheckboxGroup from '../../components/CheckBoxGroup';
// import NumberInputGroup from '../../components/NumberInputGroup';
// import {baseURL} from '../../../config/constant';
// import {fetchChildCategories} from '../../../utils/apiFunction';
// import Header from '../../components/Header';
// import Loader from '../../components/Loader';

// // Utility function (kept outside the component)
// function createProductFormData(payload) {
//   const formData = new FormData();

//   // Basic product fields
//   formData.append('productId', payload.productId);
//   formData.append('name', payload.name);
//   formData.append('category', payload.category);
//   formData.append('description', payload.description);
//   formData.append('brand', payload.brand);
//   formData.append('gst_number', payload.gst_number);
//   formData.append('country_of_origin', payload.country_of_origin);

//   // Variants
//   payload.variants.forEach((variant, index) => {
//     formData.append(`variants[${index}][size]`, variant.size);
//     formData.append(`variants[${index}][color]`, variant.color);
//     formData.append(`variants[${index}][price]`, variant.price);

//     if (variant.variant_image) {
//       formData.append(`variants[${index}][variant_image]`, {
//         uri: variant.variant_image.uri,
//         type: variant.variant_image.type,
//         name: variant.variant_image.name,
//       });
//     }
//   });

//   return formData;
// }

// // =========================================================================
// // MAIN COMPONENT
// // =========================================================================
// const AddNewProduct = () => {
//   const [subcategories, setSubcategories] = useState([]);
//   const [VariantUI, setVariantUI] = useState(null);

//   const {
//     getAllProductModal,
//     basicInformation,
//     getCategory,
//     isLoadinAllModal,
//     isLoading: isSubmitting,
//   } = useProductModal();

//   const [formData, setFormData] = useState({});
//   const [productVariants, setProductVariants] = useState([]);
//   // const [currentProductId, setCurrentProductId] = useState(null); // Not used in this snippet

//   const structuredForm = useMemo(() => {
//     // Define the new field object to be conditionally injected
//     const newFieldObject = {
//       id: 1040,
//       fieldName: 'attributes',
//       fieldType: 'Page',
//       isRequired: true,
//       isReadOnly: false,
//       displayOrder: 1,
//       isVisible: true,
//       label: 'Product Title*',
//       placeholder: 'Enter product title',
//       helpText: 'Title of the product',
//       displayName: '',
//       regexPattern: "^[A-Za-z0-9\\s\\-\\&'\\.,()]{2,200}$",
//       defaultValue: null,
//       maxLength: null,
//       minLength: null,
//       otpLength: null,
//       options: null,
//       fileConfig: null,
//       endpoint:
//         'https://dev-backend.nextgenedus.com/api/v1/Products/variant-page-with-attributes',
//       fieldMetadata: null,
//       localization: {
//         languageCode: 'en',
//         countryCode: 'AE',
//         localizedText: 'Product Title',
//         localizedPlaceholder: null,
//         localizedHelpText: null,
//       },
//       isDefault: false,
//       isOpenView: false,
//     };

//     const rawPages = getAllProductModal?.pages || [];
//     const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);

//     return sortedPages.map(page => {
//       const isTargetPage = page.pageName === 'Ecommerce_Product_Variant';
//       const isCollectionKey = isTargetPage ? {isCollection: true} : {};

//       const sortedSections = page.sections
//         ? [...page.sections].sort((a, b) => a.order - b.order)
//         : [];

//       // Logic to conditionally insert the new field into the FIRST SECTION
//       if (isTargetPage && sortedSections.length > 0) {
//         const targetSection = sortedSections[0];
//         const existingFields = targetSection.fields || [];

//         // Prepend the new field object
//         const combinedFields = [newFieldObject, ...existingFields];

//         // Sort the entire combined array by displayOrder
//         const sortedFields = combinedFields.sort(
//           (a, b) => a.displayOrder - b.displayOrder,
//         );

//         // Update the fields array of the first section (safe due to shallow copy)
//         sortedSections[0] = {
//           ...targetSection,
//           fields: sortedFields,
//         };
//       }

//       // Combine the page, the conditional key, and the potentially modified sections
//       return {
//         ...page,
//         ...isCollectionKey,
//         sections: sortedSections,
//       };
//     });
//   }, [getAllProductModal]);

//   const handleFieldChange = (fieldName, value) => {
//     setFormData(prev => ({...prev, [fieldName]: value}));
//   };

//   const renderField = field => {
//     const commonProps = {
//       key: field.id,
//       label: field.label,
//       placeholder: field.placeholder,
//       isRequired: field.isRequired,
//       value: formData[field.fieldName] || field.defaultValue,
//       onChange: value => handleFieldChange(field.fieldName, value),
//       onChangeText: text => handleFieldChange(field.fieldName, text),
//     };

//     switch (field.fieldType) {
//       case 'Text':
//         return <InputGroup {...commonProps} />;
//       case 'Number':
//         return <NumberInputGroup {...commonProps} />;
//       case 'Checkbox':
//         return (
//           <CheckboxGroup {...commonProps} onChange={commonProps.onChange} />
//         );
//       case 'TextArea':
//         return <DescriptionInput {...commonProps} />;
//       case 'Page':
//         if (field.fieldName === 'attributes') {
//           console.log(VariantUI?.sections, 'VariantUI?.sections');
//           // Renders the entire VariantUI block (sections + fields) here
//           return VariantUI?.sections ? (
//             <View key={field.id} style={styles.variantAttributesBlock}>
//               {/* <Text style={styles.variantBlockTitle}>
//                 {VariantUI.title || field.label}
//               </Text> */}

//               {VariantUI.sections.map(section => (
//                 <View key={section.id} style={styles.sectionContainer}>
//                   <Text style={styles.sectionTitle}>{section.title}</Text>

//                   {/* Recursively reuse renderField for the variant attribute fields */}
//                   {section.fields.map(
//                     attributeField =>
//                       attributeField.isVisible !== false &&
//                       renderField(attributeField),
//                   )}
//                 </View>
//               ))}

//               {/* Render the core variant group UI */}
//               {/* <PriceVariantGroup
//                 variants={productVariants}
//                 setVariants={setProductVariants}
//               /> */}
//             </View>
//           ) : (
//             <Text>Loading Variant UI...</Text>
//           );
//         }
//         return null;

//       case 'Select':
//         // --- Data Mapping (For the initial parent category dropdown) ---
//         const rawCategoryItems = getCategory?.items ?? [];
//         const mappedCategoryOptions = rawCategoryItems
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- Handler to Fetch Children and Update State ---
//         const handleCategorySelect = async selectedId => {
//           // 1. Update the form state for the currently selected dropdown (Category ID)
//           commonProps.onChange(selectedId);

//           try {
//             // 2. Fetch the child data (Subcategories)
//             const response = await fetchChildCategories(
//               'Category',
//               selectedId,
//               'parentId', // Query key is 'parentId'
//             );

//             // 3. Fetch Variant UI data (Assuming 'categoryId' is the key here)
//             // This endpoint needs the selected category ID to fetch correct attributes
//             const categoryData = await fetchChildCategories(
//               'Products/variant-page-with-attributes',
//               selectedId, // Use the actual selectedId here
//               'categoryId',
//             );
//             setVariantUI(categoryData?.data);

//             const subcategoryItems = response?.data?.items ?? [];
//             setSubcategories(subcategoryItems);
//           } catch (error) {
//             console.error('Failed to fetch data:', error);
//             setSubcategories([]);
//           }
//         };

//         // --- Subcategory Options Mapping ---
//         const mappedSubcategoryOptions = subcategories
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- RENDERING LOGIC ---
//         if (field?.fieldName === 'category_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedCategoryOptions}
//               onSelect={handleCategorySelect} // Triggers fetch
//               onChangeText={() => {}}
//             />
//           );
//         } else if (field?.fieldName === 'subcategory_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedSubcategoryOptions}
//               onSelect={commonProps.onChange}
//               onChangeText={() => {}}
//             />
//           );
//         }

//         // For all other 'Select' fields
//         return (
//           <DropdownGroup
//             {...commonProps}
//             options={field.options ?? []}
//             onSelect={commonProps.onChange}
//             onChangeText={() => {}}
//           />
//         );

//       case 'File':
//         return (
//           <ProductImagePicker
//             {...commonProps}
//             key={field.id}
//             images={formData[field.fieldName] || []}
//             setImages={commonProps.onChange}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // --- 3. SEQUENTIAL SUBMISSION HANDLER ---
//   const handleSubmit = async () => {
//     // ⚠️ TODO: Replace this placeholder with actual data construction from formData and productVariants
//     const payload = {
//       // Example:
//       productId: 'new_temp_id',
//       name: formData.name,
//       category: formData.category_id,
//       // ... (other fields)
//       variants: productVariants, // Ensure this is populated correctly
//     };

//     if (!payload || !payload.name || !payload.category) {
//       Alert.alert('Missing Data', 'Please fill in required basic information.');
//       return;
//     }

//     try {
//       const submissionData = createProductFormData(payload);
//       const response = await basicInformation(submissionData);

//       if (response?.success) {
//         // Assuming response has a 'success' flag
//         Alert.alert('Success', 'Product submitted successfully!');
//         console.log('✅ Product submitted successfully:', response);
//         // Clear form or navigate
//       } else {
//         Alert.alert(
//           'Submission Failed',
//           response?.message || 'An unknown error occurred.',
//         );
//         console.warn('⚠️ Failed to submit product:', response);
//       }
//     } catch (error) {
//       console.error('❌ Error submitting product:', error);
//       Alert.alert(
//         'API Error',
//         error.message || 'Could not connect to the server.',
//       );
//     }
//   };

//   return (
//     <ScrollView contentContainerStyle={styles.contentContainer}>
//       <Header title={'Add New Product'} onBackPress={true} />
//       <Loader visible={isLoadinAllModal || isSubmitting} />

//       {/* 2. RENDERING: Map over the sorted structured data (Main Form) */}
//       {structuredForm.map(page => (
//         <View key={page.pageId}>
//           <View style={styles.headerContainer}>
//             <Text style={styles.pageTitle}>{page.title}</Text>
//             {/* Conditional "Add New" button */}
//             {page.isCollection === true && (
//               <TouchableOpacity
//                 style={styles.addButton}
//                 onPress={() => {
//                   console.log(
//                     'Add New button pressed for collection:',
//                     page.title,
//                   );
//                 }}>
//                 <Text style={styles.addButtonText}>+ Add New</Text>
//               </TouchableOpacity>
//             )}
//           </View>

//           {page.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>
//               {section.description && (
//                 <Text style={styles.sectionDescription}>
//                   {section.description}
//                 </Text>
//               )}

//               {/* Render sorted fields within the section */}
//               {section.fields.map(
//                 field => field.isVisible !== false && renderField(field),
//               )}
//             </View>
//           ))}
//         </View>
//       ))}

//       {/* 3. RENDERING: Variant Attributes (Using the same renderField function) */}
//       {VariantUI?.sections && (
//         <View style={styles.variantAttributesBlock}>
//           <Text style={styles.variantBlockTitle}>{VariantUI.title}</Text>

//           {/* Map over the sections in the VariantUI state */}
//           {VariantUI.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>

//               {/* Reuse the renderField function for variant attributes */}
//               {section.fields.map(
//                 field => field.isVisible !== false && renderField(field),
//               )}
//             </View>
//           ))}

//           {/* Include the PriceVariantGroup component for dynamic variants */}
//           <PriceVariantGroup
//             // This is where you connect the variant state
//             variants={productVariants}
//             setVariants={setProductVariants}
//           />
//         </View>
//       )}

//       <TouchableOpacity
//         style={[
//           styles.submitButton,
//           isSubmitting && styles.submitButtonDisabled,
//         ]}
//         onPress={handleSubmit}
//         disabled={isSubmitting}>
//         <Text style={styles.submitButtonText}>
//           {isSubmitting ? 'SAVING...' : 'SAVE PRODUCT'}
//         </Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// export default AddNewProduct;

// // =========================================================================
// // STYLES
// // =========================================================================
// const styles = StyleSheet.create({
//   contentContainer: {
//     padding: 20,
//     backgroundColor: '#fff',
//     minHeight: '100%',
//   },
//   headerContainer: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: 15,
//   },
//   addButtonText: {
//     color: '#FFFFFF',
//     fontSize: 14,
//     fontWeight: '600',
//   },

//   addButton: {
//     backgroundColor: '#F89941',
//     borderRadius: 5,
//     width: 100,
//     height: 40,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },

//   pageTitle: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     // The previous border was conflicting with flex layout, removing or modifying
//     marginTop: 10,
//     paddingBottom: 5,
//     color: '#333',
//   },
//   sectionContainer: {
//     marginBottom: 25,
//     paddingBottom: 15,
//     borderBottomWidth: StyleSheet.hairlineWidth,
//     borderBottomColor: '#ccc',
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '700',
//     color: '#333',
//     marginBottom: 4,
//   },
//   sectionDescription: {
//     fontSize: 14,
//     color: '#888',
//     marginBottom: 15,
//   },
//   submitButton: {
//     backgroundColor: '#F89941',
//     padding: 15,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 30,
//     marginBottom: 50,
//   },
//   submitButtonDisabled: {
//     backgroundColor: '#FFA07A',
//     opacity: 0.7,
//   },
//   submitButtonText: {
//     color: '#FFFFFF',
//     fontSize: 16,
//     fontWeight: '700',
//   },
//   // New styles for Variant Attributes Block
//   variantAttributesBlock: {
//     marginTop: 20,
//     padding: 15,
//     borderRadius: 8,
//     backgroundColor: '#F9FAFB', // Light gray background
//     borderWidth: 1,
//     borderColor: '#E0E0E0',
//     // marginBottom: 10,
//   },
//   variantBlockTitle: {
//     fontSize: 18,
//     fontWeight: '800',
//     color: '#333',
//     marginBottom: 15,
//   },
//   variantAttributesBlock: {
//     marginTop: 20,
//     padding: 15,
//     borderRadius: 8,
//     backgroundColor: '#F9FAFB', // Light gray background
//     borderWidth: 1,
//     borderColor: '#E0E0E0',
//   },
//   variantBlockTitle: {
//     fontSize: 18,
//     fontWeight: '800',
//     color: '#333',
//     marginBottom: 15,
//   },
//   sectionContainer: {
//     marginBottom: 25,
//     paddingBottom: 15,
//     borderBottomWidth: StyleSheet.hairlineWidth,
//     borderBottomColor: '#ccc',
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '700',
//     color: '#333',
//     marginBottom: 4,
//   },
// });

//testing code

// import {
//   StyleSheet,
//   Text,
//   View,
//   ScrollView,
//   TouchableOpacity,
//   Alert,
//   Platform,
// } from 'react-native';
// import React, {useState, useMemo} from 'react';
// // Assuming these paths are correct
// import PriceVariantGroup from '../../components/PriceVariantGroup';
// import ProductImagePicker from '../../components/ProductImagePicker';
// import useProductModal from '../../../hooks/useProduct'; // Your actual hook
// import InputGroup from '../../components/InputGroup';
// import DescriptionInput from '../../components/DescriptionInput';
// import DropdownGroup from '../../components/DropdownGroup';
// import CheckboxGroup from '../../components/CheckBoxGroup';
// import NumberInputGroup from '../../components/NumberInputGroup';
// import {baseURL} from '../../../config/constant';
// import {fetchChildCategories} from '../../../utils/apiFunction';
// import Header from '../../components/Header';
// import Loader from '../../components/Loader';

// function createProductFormData(payload) {
//   const formData = new FormData();

//   // Basic product fields
//   formData.append('productId', payload.productId);
//   formData.append('name', payload.name);
//   formData.append('category', payload.category);
//   formData.append('description', payload.description);
//   formData.append('brand', payload.brand);
//   formData.append('gst_number', payload.gst_number);
//   formData.append('country_of_origin', payload.country_of_origin);

//   // Variants
//   payload.variants.forEach((variant, index) => {
//     formData.append(`variants[${index}][size]`, variant.size);
//     formData.append(`variants[${index}][color]`, variant.color);
//     formData.append(`variants[${index}][price]`, variant.price);

//     if (variant.variant_image) {
//       formData.append(`variants[${index}][variant_image]`, {
//         uri: variant.variant_image.uri,
//         type: variant.variant_image.type,
//         name: variant.variant_image.name,
//       });
//     }
//   });

//   return formData;
// }

// // =========================================================================
// // 2. MAIN COMPONENT - USING REACT QUERY MUTATIONS
// // =========================================================================
// const AddNewProduct = () => {
//   const [subcategories, setSubcategories] = useState([]);
//   const [VariantUI, setVariantUI] = useState(null);

//   console.log(JSON.stringify(VariantUI, null, 2), '*******************');
//   // Destructure individual mutations and the overall loading state from the hook
//   const {
//     getAllProductModal,
//     basicInformation,
//     productVariantApi,
//     productDetailapi,
//     ProductsCompliance,
//     getCategory,
//     loadingCategory,
//     isLoadinAllModal,
//     isLoading: isSubmitting, // Use the combined loading state from the hook
//   } = useProductModal(); // Assuming the hook name is useProductModal

//   const [formData, setFormData] = useState({});
//   const [productVariants, setProductVariants] = useState([]);
//   const [currentProductId, setCurrentProductId] = useState(null);

//   const structuredForm = useMemo(() => {
//     // Define the new field object to be conditionally injected
//     const newFieldObject = {
//       id: 1040,
//       fieldName: 'attributes',
//       fieldType: 'Page',
//       isRequired: true,
//       isReadOnly: false,
//       displayOrder: 1, // This displayOrder will place it first after sorting
//       isVisible: true,
//       label: 'Product Title*',
//       placeholder: 'Enter product title',
//       helpText: 'Title of the product',
//       displayName: '',
//       regexPattern: "^[A-Za-z0-9\\s\\-\\&'\\.,()]{2,200}$",
//       defaultValue: null,
//       maxLength: null,
//       minLength: null,
//       otpLength: null,
//       options: null,
//       fileConfig: null,
//       endpoint:
//         'https://dev-backend.nextgenedus.com/api/v1/Products/variant-page-with-attributes',
//       fieldMetadata: null,
//       localization: {
//         languageCode: 'en',
//         countryCode: 'AE',
//         localizedText: 'Product Title',
//         localizedPlaceholder: null,
//         localizedHelpText: null,
//       },
//       isDefault: false,
//       isOpenView: false,
//     };

//     const rawPages = getAllProductModal?.pages || [];
//     const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);

//     return sortedPages.map(page => {
//       const isTargetPage = page.pageName === 'Ecommerce_Product_Variant';
//       const isCollectionKey = isTargetPage ? {isCollection: true} : {};

//       const sortedSections = page.sections
//         ? [...page.sections].sort((a, b) => a.order - b.order)
//         : [];

//       // Check if the target page condition is met AND the first section exists
//       if (isTargetPage && sortedSections.length > 0) {
//         // 🎯 TARGETING THE FIRST SECTION [0]
//         const targetSection = sortedSections[0];

//         // Ensure fields array exists before modifying
//         const existingFields = targetSection.fields || [];

//         // Prepend the new field object to the fields array
//         const combinedFields = [newFieldObject, ...existingFields];

//         // Sort the entire combined array by displayOrder (This handles the new field's position)
//         const sortedFields = combinedFields.sort(
//           (a, b) => a.displayOrder - b.displayOrder,
//         );

//         // Update the fields array of the first section in the sortedSections array
//         sortedSections[0] = {
//           ...targetSection,
//           fields: sortedFields,
//         };
//       }

//       // Combine the page, the conditional key, and the potentially modified sections
//       return {
//         ...page,
//         ...isCollectionKey,
//         sections: sortedSections,
//       };
//     });
//   }, [getAllProductModal]);

//   const handleFieldChange = (fieldName, value) => {
//     setFormData(prev => ({...prev, [fieldName]: value}));
//   };

//   const renderField = field => {
//     const commonProps = {
//       key: field.id,
//       label: field.label,
//       placeholder: field.placeholder,
//       isRequired: field.isRequired,
//       value: formData[field.fieldName] || field.defaultValue,
//       onChange: value => handleFieldChange(field.fieldName, value),
//       onChangeText: text => handleFieldChange(field.fieldName, text),
//     };

//     switch (field.fieldType) {
//       case 'Text':
//         return <InputGroup {...commonProps} />;
//       case 'Number':
//         return <NumberInputGroup {...commonProps} />;
//       case 'Checkbox':
//         return (
//           <CheckboxGroup {...commonProps} onChange={commonProps.onChange} />
//         );
//       case 'TextArea':
//         return <DescriptionInput {...commonProps} />;

//       case 'Page':
//         return <Text>{field.endpoint}</Text>;
//       case 'Select':
//         // --- Data Mapping (For the initial parent category dropdown) ---
//         const rawCategoryItems = getCategory?.items ?? [];

//         // console.log(rawCategoryItems, 'rawCategoryItems****');
//         const mappedCategoryOptions = rawCategoryItems
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- Handler to Fetch Children and Update State ---
//         const handleCategorySelect = async selectedId => {
//           // console.log(selectedId, '********** Selected Parent ID');

//           // 1. Update the form state for the currently selected dropdown (Category ID)
//           commonProps.onChange(selectedId);

//           try {
//             // 2. Fetch the child data
//             const response = await fetchChildCategories(
//               'Category',
//               selectedId,
//               'parentId',
//             );

//             const categoryData = await fetchChildCategories(
//               'Products/variant-page-with-attributes',
//               '1',
//               'categoryId',
//             );
//             setVariantUI(categoryData?.data);

//             const subcategoryItems = response?.data?.items ?? [];
//             setSubcategories(subcategoryItems);
//           } catch (error) {
//             console.error('Failed to fetch subcategories:', error);
//             setSubcategories([]); // Clear options on failure
//           }
//         };

//         // --- Subcategory Options Mapping (Applies the same transformation to the new state data) ---
//         const mappedSubcategoryOptions = subcategories
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // console.log(mappedSubcategoryOptions, 'mappedSubcategoryOptions');

//         // --- RENDERING LOGIC ---

//         // Check if this is the Category dropdown
//         if (field?.fieldName === 'category_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedCategoryOptions}
//               onSelect={handleCategorySelect} // Triggers fetch of subcategories
//               onChangeText={() => {}}
//             />
//           );
//         }

//         // Check if this is the Subcategory dropdown
//         else if (field?.fieldName === 'subcategory_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               // 🚀 Use the mapped subcategory data from state
//               options={mappedSubcategoryOptions}
//               onSelect={commonProps.onChange} // Updates the form state for subcategory_id
//               onChangeText={() => {}}
//             />
//           );
//         }

//         // For all other 'Select' fields
//         return (
//           <DropdownGroup
//             {...commonProps}
//             options={field.options ?? []}
//             onSelect={commonProps.onChange}
//             onChangeText={() => {}}
//           />
//         );

//       case 'File':
//         return (
//           <ProductImagePicker
//             {...commonProps}
//             key={field.id}
//             images={formData[field.fieldName] || []}
//             setImages={commonProps.onChange}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // --- 3. SEQUENTIAL SUBMISSION HANDLER ---
//   const handleSubmit = async () => {
//     try {
//       const formData = createProductFormData(payload);
//       const response = await basicInformation(formData);

//       if (response) {
//         console.log('✅ Product submitted successfully:', response);
//       } else {
//         console.warn('⚠️ Failed to submit product:', response);
//       }
//     } catch (error) {
//       console.error('❌ Error submitting product:', error);
//     }
//   };

//   return (
//     <ScrollView contentContainerStyle={styles.contentContainer}>
//       {/* <Text style={styles.header}>Add New Product</Text> */}
//       <Header title={'Add New Product'} onBackPress={true} />
//       <Loader visible={isLoadinAllModal} />
//       {/* 2. RENDERING: Map over the sorted structured data */}
//       {structuredForm.map(page => {
//         // console.log(page, 'pagepagepagepage****');
//         return (
//           <View key={page.pageId}>
//             <View
//               style={{flexDirection: 'row', justifyContent: 'space-between'}}>
//               <Text style={styles.pageTitle}>{page.title}</Text>
//               {page.isCollection == true && (
//                 <TouchableOpacity
//                   style={styles.addButton}
//                   onPress={() => {
//                     // Implement your navigation or modal logic here
//                     console.log(
//                       'Add New button pressed for collection:',
//                       page.title,
//                     );
//                   }}>
//                   <Text style={styles.addButtonText}>+ Add New</Text>
//                 </TouchableOpacity>
//               )}
//             </View>

//             {page.sections.map(section => (
//               <View key={section.id} style={styles.sectionContainer}>
//                 <Text style={styles.sectionTitle}>{section.title}</Text>
//                 {section.description && (
//                   <Text style={styles.sectionDescription}>
//                     {section.description}
//                   </Text>
//                 )}

//                 {/* Render sorted fields within the section */}
//                 {section.fields.map(
//                   field => field.isVisible !== false && renderField(field),
//                 )}
//               </View>
//             ))}
//           </View>
//         );
//       })}

//       <TouchableOpacity
//         style={[
//           styles.submitButton,
//           isSubmitting && styles.submitButtonDisabled,
//         ]}
//         onPress={handleSubmit}
//         disabled={isSubmitting}>
//         <Text style={styles.submitButtonText}>
//           {isSubmitting ? 'SAVING...' : 'SAVE PRODUCT'}
//         </Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// export default AddNewProduct;

// const styles = StyleSheet.create({
//   contentContainer: {
//     padding: 20,
//     backgroundColor: '#fff',
//     minHeight: '100%',
//   },
//   header: {
//     fontSize: 24,
//     fontWeight: '800',
//     marginBottom: 20,
//     color: '#333',
//   },
//   addButtonText: {
//     color: '#FFFFFF',
//     fontSize: 14,
//     fontWeight: '600',
//   },

//   addButton: {
//     backgroundColor: '#F89941',
//     // paddingVertical: 6,
//     // paddingHorizontal: 12,
//     borderRadius: 5,
//     width: 100,
//     height: 40,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },

//   pageTitle: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     marginTop: 10,
//     marginBottom: 15,
//     borderBottomWidth: 2,
//     borderBottomColor: '#F89941',
//     paddingBottom: 5,
//     color: '#333',
//   },
//   sectionContainer: {
//     marginBottom: 25,
//     paddingBottom: 15,
//     borderBottomWidth: StyleSheet.hairlineWidth,
//     borderBottomColor: '#ccc',
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '700',
//     color: '#333',
//     marginBottom: 4,
//   },
//   sectionDescription: {
//     fontSize: 14,
//     color: '#888',
//     marginBottom: 15,
//   },
//   submitButton: {
//     backgroundColor: '#F89941',
//     padding: 15,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 30,
//     marginBottom: 50,
//   },
//   submitButtonDisabled: {
//     backgroundColor: '#FFA07A',
//     opacity: 0.7,
//   },
//   submitButtonText: {
//     color: '#FFFFFF',
//     fontSize: 16,
//     fontWeight: '700',
//   },
// });

//below imp code commented don't remove

//
//

///

//

//
//
//
//
//
//
//
//
//
//

//
//
//
//
//
//
//
//
//
//
//
//

//imp code by rajan

// import {
//   StyleSheet,
//   Text,
//   View,
//   ScrollView,
//   TouchableOpacity,
//   Alert,
//   Platform, // Import Platform for file URI fix
// } from 'react-native';
// import React, {useState, useMemo} from 'react';
// // Assuming these paths are correct
// import PriceVariantGroup from '../../components/PriceVariantGroup';
// import ProductImagePicker from '../../components/ProductImagePicker';
// import useProductModal from '../../../hooks/useProduct'; // Your actual hook
// import InputGroup from '../../components/InputGroup';
// import DescriptionInput from '../../components/DescriptionInput';
// import DropdownGroup from '../../components/DropdownGroup';
// import CheckboxGroup from '../../components/CheckBoxGroup';
// import NumberInputGroup from '../../components/NumberInputGroup';
// import {baseURL} from '../../../config/constant';
// import {fetchChildCategories} from '../../../utils/apiFunction';
// import Header from '../../components/Header';
// import Loader from '../../components/Loader';

// // =========================================================================
// // 1. FORM DATA UTILITY (CRITICAL FOR API) - WITH RN FILE FIX
// // =========================================================================
// // const createAPIFormData = (pageData, pageName, currentProductId) => {
// //   const formData = new FormData();
// //   formData.append('pageName', pageName);

// //   if (currentProductId) {
// //     formData.append('productId', String(currentProductId)); // Ensure it's a string
// //   }

// //   // --- Logic for Basic, Details, Compliance Pages ---
// //   if (pageName !== 'Ecommerce_Product_Variant') {
// //     let fieldIndex = 0;

// //     pageData.forEach(field => {
// //       const base = `fields[${fieldIndex}]`;
// //       formData.append(`${base}.fieldName`, field.fieldName);

// //       if (field.fieldType === 'File' || field.fieldType === 'imgpicker') {
// //         (field.value || []).forEach(uri => {
// //           const fileExtension = uri.split('.').pop();

// //           // CRITICAL RN FILE FIX: Strip 'file://' on iOS
// //           const fileUri =
// //             Platform.OS === 'android' ? uri : uri.replace('file://', '');

// //           formData.append(`${base}.file`, {
// //             uri: fileUri,
// //             name: `${field.fieldName}-${Date.now()}.${fileExtension}`,
// //             type: `image/${fileExtension === 'jpg' ? 'jpeg' : fileExtension}`,
// //           });
// //         });
// //       } else {
// //         formData.append(`${base}.value`, String(field.value));
// //       }
// //       fieldIndex++;
// //     });
// //   }
// //   // --- Logic for Variant Page ---
// //   else {
// //     const variantEntry = pageData.find(d => d.fieldName === 'variants');
// //     const variants = variantEntry ? variantEntry.value : [];

// //     variants.forEach((variant, vIndex) => {
// //       const base = `variants[${vIndex}].pageData`;
// //       formData.append(`${base}.pageName`, pageName);

// //       variant.fields.forEach((field, fIndex) => {
// //         formData.append(`${base}.fields[${fIndex}].fieldName`, field.fieldName);
// //         formData.append(`${base}.fields[${fIndex}].value`, String(field.value));
// //       });

// //       // Handle variant images/documents
// //       (variant.documents || []).forEach((doc, dIndex) => {
// //         const fileUri =
// //           Platform.OS === 'android'
// //             ? doc.file
// //             : doc.file.replace('file://', '');
// //         const fileExtension = doc.file.split('.').pop();

// //         formData.append(
// //           `${base}.documents[${dIndex}].fieldName`,
// //           doc.fieldName,
// //         );

// //         formData.append(`${base}.documents[${dIndex}].file`, {
// //           uri: fileUri,
// //           name: `${doc.fieldName}-${Date.now()}.${fileExtension}`,
// //           type: `image/${fileExtension === 'jpg' ? 'jpeg' : fileExtension}`,
// //         });
// //       });
// //     });
// //   }

// //   return formData;
// // };

// function createProductFormData(payload) {
//   const formData = new FormData();

//   // Basic product fields
//   formData.append('productId', payload.productId);
//   formData.append('name', payload.name);
//   formData.append('category', payload.category);
//   formData.append('description', payload.description);
//   formData.append('brand', payload.brand);
//   formData.append('gst_number', payload.gst_number);
//   formData.append('country_of_origin', payload.country_of_origin);

//   // Variants
//   payload.variants.forEach((variant, index) => {
//     formData.append(`variants[${index}][size]`, variant.size);
//     formData.append(`variants[${index}][color]`, variant.color);
//     formData.append(`variants[${index}][price]`, variant.price);

//     if (variant.variant_image) {
//       formData.append(`variants[${index}][variant_image]`, {
//         uri: variant.variant_image.uri,
//         type: variant.variant_image.type,
//         name: variant.variant_image.name,
//       });
//     }
//   });

//   return formData;
// }

// // =========================================================================
// // 2. MAIN COMPONENT - USING REACT QUERY MUTATIONS
// // =========================================================================
// const AddNewProduct = () => {
//   const [subcategories, setSubcategories] = useState([]);
//   const [VariantUI, setVariantUI] = useState(null);

//   console.log(JSON.stringify(VariantUI, null, 2), '*******************');
//   // Destructure individual mutations and the overall loading state from the hook
//   const {
//     getAllProductModal,
//     basicInformation,
//     productVariantApi,
//     productDetailapi,
//     ProductsCompliance,
//     getCategory,
//     loadingCategory,
//     isLoadinAllModal,
//     isLoading: isSubmitting, // Use the combined loading state from the hook
//   } = useProductModal(); // Assuming the hook name is useProductModal

//   const [formData, setFormData] = useState({});
//   const [productVariants, setProductVariants] = useState([]);
//   const [currentProductId, setCurrentProductId] = useState(null);
//   // console.log(getCategory?.items, 'getCategorygetCategory');

//   //temparory commented data
//   // const structuredForm = useMemo(() => {
//   //   const rawPages = getAllProductModal?.pages || [];
//   //   const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);
//   //   return sortedPages.map(page => {
//   //     const sortedSections = page.sections
//   //       ? [...page.sections].sort((a, b) => a.order - b.order)
//   //       : [];
//   //     const sectionsWithSortedFields = sortedSections.map(section => ({
//   //       ...section,
//   //       fields: section.fields
//   //         ? [...section.fields].sort((a, b) => a.displayOrder - b.displayOrder)
//   //         : [],
//   //     }));
//   //     return {...page, sections: sectionsWithSortedFields};
//   //   });
//   // }, [getAllProductModal]);

//   // const structuredForm = useMemo(() => {
//   //   // Define the new field object to be conditionally injected
//   //   const newFieldObject = {
//   //     id: 1040,
//   //     fieldName: 'attributes',
//   //     fieldType: 'Page',
//   //     isRequired: true,
//   //     isReadOnly: false,
//   //     displayOrder: 1,
//   //     isVisible: true,
//   //     label: 'Product Title*',
//   //     placeholder: 'Enter product title',
//   //     helpText: 'Title of the product',
//   //     displayName: '',
//   //     regexPattern: "^[A-Za-z0-9\\s\\-\\&'\\.,()]{2,200}$",
//   //     defaultValue: null,
//   //     maxLength: null,
//   //     minLength: null,
//   //     otpLength: null,
//   //     options: null,
//   //     fileConfig: null,
//   //     endpoint:
//   //       'https://dev-backend.nextgenedus.com/api/v1/Products/variant-page-with-attributes',
//   //     fieldMetadata: null,
//   //     localization: {
//   //       languageCode: 'en',
//   //       countryCode: 'AE',
//   //       localizedText: 'Product Title',
//   //       localizedPlaceholder: null,
//   //       localizedHelpText: null,
//   //     },
//   //     isDefault: false,
//   //     isOpenView: false,
//   //   };

//   //   const rawPages = getAllProductModal?.pages || [];
//   //   const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);

//   //   return sortedPages.map(page => {
//   //     // 1. Check the page name condition
//   //     const isTargetPage = page.pageName === 'Ecommerce_Product_Variant';

//   //     // 2. Conditionally add isCollection: true (from previous request)
//   //     const isCollectionKey = isTargetPage ? {isCollection: true} : {};

//   //     const sortedSections = page.sections
//   //       ? [...page.sections].sort((a, b) => a.order - b.order)
//   //       : [];

//   //     const sectionsWithSortedFields = sortedSections.map(section => {
//   //       const existingFields = section.fields || [];

//   //       // 3. Conditionally add the new field to the array if it's the target page
//   //       const fieldsToInsert = isTargetPage ? [newFieldObject] : [];

//   //       // 4. Combine existing fields and the conditionally inserted field(s)
//   //       const combinedFields = [...existingFields, ...fieldsToInsert];

//   //       // 5. Sort the combined fields array by displayOrder
//   //       const sortedFields = combinedFields.sort(
//   //         (a, b) => a.displayOrder - b.displayOrder,
//   //       );

//   //       return {
//   //         ...section,
//   //         fields: sortedFields,
//   //       };
//   //     });

//   //     // Combine the page, the conditional key, and the updated sections
//   //     return {
//   //       ...page,
//   //       ...isCollectionKey,
//   //       sections: sectionsWithSortedFields,
//   //     };
//   //   });
//   // }, [getAllProductModal]);

//   const structuredForm = useMemo(() => {
//     // Define the new field object to be conditionally injected
//     const newFieldObject = {
//       id: 1040,
//       fieldName: 'attributes',
//       fieldType: 'Page',
//       isRequired: true,
//       isReadOnly: false,
//       displayOrder: 1, // This displayOrder will place it first after sorting
//       isVisible: true,
//       label: 'Product Title*',
//       placeholder: 'Enter product title',
//       helpText: 'Title of the product',
//       displayName: '',
//       regexPattern: "^[A-Za-z0-9\\s\\-\\&'\\.,()]{2,200}$",
//       defaultValue: null,
//       maxLength: null,
//       minLength: null,
//       otpLength: null,
//       options: null,
//       fileConfig: null,
//       endpoint:
//         'https://dev-backend.nextgenedus.com/api/v1/Products/variant-page-with-attributes',
//       fieldMetadata: null,
//       localization: {
//         languageCode: 'en',
//         countryCode: 'AE',
//         localizedText: 'Product Title',
//         localizedPlaceholder: null,
//         localizedHelpText: null,
//       },
//       isDefault: false,
//       isOpenView: false,
//     };

//     const rawPages = getAllProductModal?.pages || [];
//     const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);

//     return sortedPages.map(page => {
//       const isTargetPage = page.pageName === 'Ecommerce_Product_Variant';
//       const isCollectionKey = isTargetPage ? {isCollection: true} : {};

//       const sortedSections = page.sections
//         ? [...page.sections].sort((a, b) => a.order - b.order)
//         : [];

//       // Check if the target page condition is met AND the first section exists
//       if (isTargetPage && sortedSections.length > 0) {
//         // 🎯 TARGETING THE FIRST SECTION [0]
//         const targetSection = sortedSections[0];

//         // Ensure fields array exists before modifying
//         const existingFields = targetSection.fields || [];

//         // Prepend the new field object to the fields array
//         const combinedFields = [newFieldObject, ...existingFields];

//         // Sort the entire combined array by displayOrder (This handles the new field's position)
//         const sortedFields = combinedFields.sort(
//           (a, b) => a.displayOrder - b.displayOrder,
//         );

//         // Update the fields array of the first section in the sortedSections array
//         sortedSections[0] = {
//           ...targetSection,
//           fields: sortedFields,
//         };
//       }

//       // Combine the page, the conditional key, and the potentially modified sections
//       return {
//         ...page,
//         ...isCollectionKey,
//         sections: sortedSections,
//       };
//     });
//   }, [getAllProductModal]);

//   // const dataGroupedByPage = useMemo(() => {
//   //   const groupedData = {};
//   //   const rawPages = getAllProductModal?.pages || [];

//   //   rawPages.forEach(page => {
//   //     const pageName = page.pageName;
//   //     groupedData[pageName] = [];

//   //     page.sections.forEach(section => {
//   //       section.fields.forEach(field => {
//   //         const fieldValue = formData[field.fieldName];

//   //         if (
//   //           fieldValue !== null &&
//   //           fieldValue !== undefined &&
//   //           fieldValue !== ''
//   //         ) {
//   //           groupedData[pageName].push({
//   //             fieldName: field.fieldName,
//   //             value: fieldValue,
//   //             fieldType: field.fieldType,
//   //           });
//   //         }
//   //       });
//   //     });
//   //   });

//   //   if (productVariants.length > 0) {
//   //     groupedData['Ecommerce_Product_Variant'].push({
//   //       fieldName: 'variants',
//   //       value: productVariants,
//   //       fieldType: 'Array',
//   //     });
//   //   }

//   //   return groupedData;
//   // }, [formData, productVariants, getAllProductModal]);

//   const handleFieldChange = (fieldName, value) => {
//     setFormData(prev => ({...prev, [fieldName]: value}));
//   };

//   const renderField = field => {
//     const commonProps = {
//       key: field.id,
//       label: field.label,
//       placeholder: field.placeholder,
//       isRequired: field.isRequired,
//       value: formData[field.fieldName] || field.defaultValue,
//       onChange: value => handleFieldChange(field.fieldName, value),
//       onChangeText: text => handleFieldChange(field.fieldName, text),
//     };

//     switch (field.fieldType) {
//       case 'Text':
//         return <InputGroup {...commonProps} />;
//       case 'Number':
//         return <NumberInputGroup {...commonProps} />;
//       case 'Checkbox':
//         return (
//           <CheckboxGroup {...commonProps} onChange={commonProps.onChange} />
//         );
//       case 'TextArea':
//         return <DescriptionInput {...commonProps} />;

//       case 'Page':
//         return <Text>{field.endpoint}</Text>;
//       case 'Select':
//         // --- Data Mapping (For the initial parent category dropdown) ---
//         const rawCategoryItems = getCategory?.items ?? [];

//         // console.log(rawCategoryItems, 'rawCategoryItems****');
//         const mappedCategoryOptions = rawCategoryItems
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- Handler to Fetch Children and Update State ---
//         const handleCategorySelect = async selectedId => {
//           // console.log(selectedId, '********** Selected Parent ID');

//           // 1. Update the form state for the currently selected dropdown (Category ID)
//           commonProps.onChange(selectedId);

//           try {
//             // 2. Fetch the child data
//             const response = await fetchChildCategories(
//               'Category',
//               selectedId,
//               'parentId',
//             );

//             const categoryData = await fetchChildCategories(
//               'Products/variant-page-with-attributes',
//               '1',
//               'categoryId',
//             );
//             setVariantUI(categoryData?.data);

//             const subcategoryItems = response?.data?.items ?? [];
//             setSubcategories(subcategoryItems);
//           } catch (error) {
//             console.error('Failed to fetch subcategories:', error);
//             setSubcategories([]); // Clear options on failure
//           }
//         };

//         // --- Subcategory Options Mapping (Applies the same transformation to the new state data) ---
//         const mappedSubcategoryOptions = subcategories
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // console.log(mappedSubcategoryOptions, 'mappedSubcategoryOptions');

//         // --- RENDERING LOGIC ---

//         // Check if this is the Category dropdown
//         if (field?.fieldName === 'category_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedCategoryOptions}
//               onSelect={handleCategorySelect} // Triggers fetch of subcategories
//               onChangeText={() => {}}
//             />
//           );
//         }

//         // Check if this is the Subcategory dropdown
//         else if (field?.fieldName === 'subcategory_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               // 🚀 Use the mapped subcategory data from state
//               options={mappedSubcategoryOptions}
//               onSelect={commonProps.onChange} // Updates the form state for subcategory_id
//               onChangeText={() => {}}
//             />
//           );
//         }

//         // For all other 'Select' fields
//         return (
//           <DropdownGroup
//             {...commonProps}
//             options={field.options ?? []}
//             onSelect={commonProps.onChange}
//             onChangeText={() => {}}
//           />
//         );

//       case 'File':
//         return (
//           <ProductImagePicker
//             {...commonProps}
//             key={field.id}
//             images={formData[field.fieldName] || []}
//             setImages={commonProps.onChange}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // --- 3. SEQUENTIAL SUBMISSION HANDLER ---
//   const handleSubmit = async () => {
//     try {
//       const formData = createProductFormData(payload);
//       const response = await basicInformation(formData);

//       if (response) {
//         console.log('✅ Product submitted successfully:', response);
//       } else {
//         console.warn('⚠️ Failed to submit product:', response);
//       }
//     } catch (error) {
//       console.error('❌ Error submitting product:', error);
//     }
//   };

//   return (
//     <ScrollView contentContainerStyle={styles.contentContainer}>
//       {/* <Text style={styles.header}>Add New Product</Text> */}
//       <Header title={'Add New Product'} onBackPress={true} />
//       <Loader visible={isLoadinAllModal} />
//       {/* 2. RENDERING: Map over the sorted structured data */}
//       {structuredForm.map(page => {
//         // console.log(page, 'pagepagepagepage****');
//         return (
//           <View key={page.pageId}>
//             <View
//               style={{flexDirection: 'row', justifyContent: 'space-between'}}>
//               <Text style={styles.pageTitle}>{page.title}</Text>
//               {page.isCollection == true && (
//                 <TouchableOpacity
//                   style={styles.addButton}
//                   onPress={() => {
//                     // Implement your navigation or modal logic here
//                     console.log(
//                       'Add New button pressed for collection:',
//                       page.title,
//                     );
//                   }}>
//                   <Text style={styles.addButtonText}>+ Add New</Text>
//                 </TouchableOpacity>
//               )}
//             </View>

//             {page.sections.map(section => (
//               <View key={section.id} style={styles.sectionContainer}>
//                 <Text style={styles.sectionTitle}>{section.title}</Text>
//                 {section.description && (
//                   <Text style={styles.sectionDescription}>
//                     {section.description}
//                   </Text>
//                 )}

//                 {/* Render sorted fields within the section */}
//                 {section.fields.map(
//                   field => field.isVisible !== false && renderField(field),
//                 )}
//               </View>
//             ))}
//           </View>
//         );
//       })}

//       {/* Fixed Components (outside the dynamic sections) */}
//       {/* <Text style={styles.sectionTitle}>Price & Variants</Text>
//       <PriceVariantGroup onVariantsChange={setProductVariants} /> */}

//       <TouchableOpacity
//         style={[
//           styles.submitButton,
//           isSubmitting && styles.submitButtonDisabled,
//         ]}
//         onPress={handleSubmit}
//         disabled={isSubmitting}>
//         <Text style={styles.submitButtonText}>
//           {isSubmitting ? 'SAVING...' : 'SAVE PRODUCT'}
//         </Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// export default AddNewProduct;

// const styles = StyleSheet.create({
//   contentContainer: {
//     padding: 20,
//     backgroundColor: '#fff',
//     minHeight: '100%',
//   },
//   header: {
//     fontSize: 24,
//     fontWeight: '800',
//     marginBottom: 20,
//     color: '#333',
//   },
//   addButtonText: {
//     color: '#FFFFFF',
//     fontSize: 14,
//     fontWeight: '600',
//   },

//   addButton: {
//     backgroundColor: '#F89941',
//     // paddingVertical: 6,
//     // paddingHorizontal: 12,
//     borderRadius: 5,
//     width: 100,
//     height: 40,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },

//   pageTitle: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     marginTop: 10,
//     marginBottom: 15,
//     borderBottomWidth: 2,
//     borderBottomColor: '#F89941',
//     paddingBottom: 5,
//     color: '#333',
//   },
//   sectionContainer: {
//     marginBottom: 25,
//     paddingBottom: 15,
//     borderBottomWidth: StyleSheet.hairlineWidth,
//     borderBottomColor: '#ccc',
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '700',
//     color: '#333',
//     marginBottom: 4,
//   },
//   sectionDescription: {
//     fontSize: 14,
//     color: '#888',
//     marginBottom: 15,
//   },
//   submitButton: {
//     backgroundColor: '#F89941',
//     padding: 15,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 30,
//     marginBottom: 50,
//   },
//   submitButtonDisabled: {
//     backgroundColor: '#FFA07A',
//     opacity: 0.7,
//   },
//   submitButtonText: {
//     color: '#FFFFFF',
//     fontSize: 16,
//     fontWeight: '700',
//   },
// });

//working code product page last time complte working

//
//
//code written by rajan

// import {
//   StyleSheet,
//   Text,
//   View,
//   ScrollView,
//   TouchableOpacity,
//   Alert,
//   Platform,
// } from 'react-native';
// import FormData from 'form-data';
// import React, {useState, useMemo, useEffect} from 'react';
// // Assuming these paths are correct in your React Native project
// import PriceVariantGroup from '../../components/PriceVariantGroup';
// import ProductImagePicker from '../../components/ProductImagePicker';
// import useProductModal from '../../../hooks/useProduct';
// import InputGroup from '../../components/InputGroup';
// import DescriptionInput from '../../components/DescriptionInput';
// import DropdownGroup from '../../components/DropdownGroup';
// import CheckboxGroup from '../../components/CheckBoxGroup';
// import NumberInputGroup from '../../components/NumberInputGroup';
// import {baseURL} from '../../../config/constant';
// import {fetchChildCategories} from '../../../utils/apiFunction';
// import Header from '../../components/Header';
// import Loader from '../../components/Loader';

// // dymmy data api respnose

// const transformFormDataForSubmission = (formData, apiMap) => {
//   console.log('--- Transformation Started ---');
//   console.log('Received formData:', formData);
//   const submissionBody = {};
//   const variantData = formData.Ecommerce_Product_Variant || [];

//   // 1. Process Non-Variant Pages (Standard Fields)
//   for (const pageConfig of apiMap) {
//     // Check if this is the variant template page
//     const isVariantPage = pageConfig.pageName === 'Ecommerce_Product_Variant';

//     if (isVariantPage) {
//       // We process variant data separately later (Step 2)
//       continue;
//     }

//     // Now, iterate through all sections within the current page
//     // The sections array is pageConfig.sections
//     for (const sectionConfig of pageConfig.sections) {
//       // The fields array is sectionConfig.fields
//       for (const fieldConfig of sectionConfig.fields) {
//         const fieldName = fieldConfig.fieldName;
//         const value = formData[fieldName];

//         // Only include the field if the value exists in the formData
//         if (value !== undefined) {
//           // Construct key: PageName.SectionName.fieldName
//           const key = `${pageConfig.pageName}.${sectionConfig.name}.${fieldName}`;

//           // Handle boolean values (true/false) by converting them to strings 'true'/'false'
//           submissionBody[key] =
//             typeof value === 'boolean' ? String(value) : value;
//         }
//       }
//     }
//   }

//   // 2. Process Variant Pages (Array of Objects)
//   // Find the single variant page template
//   const variantPageConfig = apiMap.find(
//     config => config.pageName === 'Ecommerce_Product_Variant',
//   );

//   // Safety check: ensure variant config was found
//   if (!variantPageConfig || variantPageConfig.sections.length === 0) {
//     console.warn('Variant page or sections not found in apiMap.');
//   } else {
//     // We assume the variant fields are primarily in the first section (DefaultSection)
//     // We will collect all unique fieldNames from all variant sections to create a complete list.
//     let staticVariantFieldNames = [];
//     variantPageConfig.sections.forEach(section => {
//       section.fields.forEach(field => {
//         staticVariantFieldNames.push(field.fieldName);
//       });
//     });

//     const VARIANT_KEY = variantPageConfig.pageName; // 'Ecommerce_Product_Variant'
//     const SECTION_KEY = variantPageConfig.sections[0].name; // e.g., 'DefaultSection'

//     variantData.forEach((variant, index) => {
//       // Collect all field names present in the current variant object (including dynamic ones like 'color')
//       // merged with the static ones from the API map.
//       const allVariantFieldNames = new Set([
//         ...staticVariantFieldNames,
//         ...Object.keys(variant),
//       ]);

//       for (const fieldName of allVariantFieldNames) {
//         const value = variant[fieldName];

//         // Skip the main variant array key and fields that don't exist in the current variant object
//         if (fieldName === VARIANT_KEY || value === undefined) continue;

//         // Construct the final key: PageName[index].SectionName.fieldName
//         const key = `${VARIANT_KEY}[${index}].${SECTION_KEY}.${fieldName}`;

//         // Handle boolean values
//         submissionBody[key] =
//           typeof value === 'boolean' ? String(value) : value;
//       }
//     });
//   }

//   console.log(
//     '✅ Final API Submission Body (Prettified JSON):\n',
//     JSON.stringify(submissionBody, null, 2),
//   );
//   return submissionBody;
// };

// const AddNewProduct = () => {
//   const [subcategories, setSubcategories] = useState([]);
//   const [VariantUI, setVariantUI] = useState(null);

//   const {
//     // getAllProductModal,
//     basicInformation,
//     getCategory,
//     isLoadinAllModal,
//     isLoading: isSubmitting,
//   } = useProductModal();

//   const [formData, setFormData] = useState({});

//   const [productVariants, setProductVariants] = useState([]);

//   // State to manage dynamically added variant pages
//   const [variantPages, setVariantPages] = useState([]);

//   // Field object to be conditionally injected
//   const newFieldObject = {
//     id: 1040,
//     fieldName: 'attributes',
//     fieldType: 'Page', // This is the placeholder that triggers VariantUI rendering
//     isRequired: true,
//     isReadOnly: false,
//     displayOrder: 1,
//     isVisible: true,
//     label: 'Product Attributes*',
//     placeholder: 'Enter product attributes',
//     helpText: 'Attributes of the product',
//     displayName: '',
//     regexPattern: "^[A-Za-z0-9\\s\\-\\&'\\.,()]{2,200}$",
//     defaultValue: null,
//     maxLength: null,
//     minLength: null,
//     otpLength: null,
//     options: null,
//     fileConfig: null,
//     endpoint:
//       'https://dev-backend.nextgenedus.com/api/v1/Products/variant-page-with-attributes',
//     fieldMetadata: null,
//     localization: {
//       languageCode: 'en',
//       countryCode: 'AE',
//       localizedText: 'Product Attributes',
//       localizedPlaceholder: null,
//       localizedHelpText: null,
//     },
//     isDefault: false,
//     isOpenView: false,
//   };

//   // 1. Refactor useMemo to extract the page template and all other non-variant pages
//   const {nonVariantPages, variantPageTemplate} = useMemo(() => {
//     const rawPages = getAllProductModal?.pages || [];
//     const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);

//     const nonVariantPages = [];
//     let variantTemplate = null;

//     sortedPages.forEach(page => {
//       // Deep copy to ensure safe manipulation
//       const pageCopy = JSON.parse(JSON.stringify(page));

//       const isTargetPage = pageCopy.pageName === 'Ecommerce_Product_Variant';

//       if (isTargetPage) {
//         // Inject the 'attributes' field into the first section of the template
//         if (pageCopy.sections && pageCopy.sections.length > 0) {
//           const targetSection = pageCopy.sections[0];
//           const existingFields = targetSection.fields || [];

//           // Prepend the new field object
//           const combinedFields = [newFieldObject, ...existingFields];

//           // Sort the entire combined array by displayOrder
//           const sortedFields = combinedFields.sort(
//             (a, b) => a.displayOrder - b.displayOrder,
//           );

//           // Update the fields array of the first section
//           pageCopy.sections[0].fields = sortedFields;
//         }

//         variantTemplate = pageCopy;
//       } else {
//         // Standard non-variant page
//         nonVariantPages.push(pageCopy);
//       }
//     });

//     return {
//       nonVariantPages,
//       variantPageTemplate: variantTemplate,
//     };
//   }, [getAllProductModal]);

//   // 2. Initialize the dynamic pages when the template is ready
//   useEffect(() => {
//     if (variantPageTemplate && variantPages.length === 0) {
//       // Add the first instance of the variant page with a unique ID
//       setVariantPages([{...variantPageTemplate, uniqueId: Date.now()}]);
//     }
//   }, [variantPageTemplate, variantPages.length]);

//   // 3. Handler to add a new variant page instance
//   const handleAddNewVariantPage = () => {
//     if (!variantPageTemplate) {
//       Alert.alert('Error', 'Variant page template not loaded.');
//       return;
//     }

//     // Create a new unique instance of the template page
//     const newPageInstance = {
//       ...JSON.parse(JSON.stringify(variantPageTemplate)), // Deep copy sections and fields
//       uniqueId: Date.now() + Math.random(), // Ensure a unique key
//     };

//     setVariantPages(prev => [...prev, newPageInstance]);
//   };

//   const handleFieldChange = (
//     fieldName,
//     value,
//     pageName = null,
//     pageIndex = null,
//   ) => {
//     const VARIANT_KEY = 'Ecommerce_Product_Variant';

//     // Check if the field belongs to a dynamic variant page
//     if (pageName === VARIANT_KEY && pageIndex !== null) {
//       setFormData(prev => {
//         // 1. Get the existing array or initialize it
//         const currentVariants = prev[VARIANT_KEY] || [];

//         // 2. Deep copy the specific variant object we are modifying, or create an empty one
//         const targetVariant = {...(currentVariants[pageIndex] || {})};

//         // 3. Update the specific field within the variant object
//         targetVariant[fieldName] = value;

//         // 4. Create a new array with the updated variant object at the correct index
//         const newVariants = [...currentVariants];
//         newVariants[pageIndex] = targetVariant;

//         // 5. Return the new state
//         return {
//           ...prev,
//           [VARIANT_KEY]: newVariants,
//         };
//       });
//     } else {
//       // Handle non-variant pages (basic information)
//       setFormData(prev => ({...prev, [fieldName]: value}));
//     }
//   };

//   const renderField = (field, pageName = null, pageIndex = null) => {
//     const VARIANT_KEY = 'Ecommerce_Product_Variant';
//     let fieldValue;

//     // Determine the field value based on context (variant page or basic page)
//     if (pageName === VARIANT_KEY && pageIndex !== null) {
//       // Look up value in the nested array
//       fieldValue = formData[VARIANT_KEY]?.[pageIndex]?.[field.fieldName];
//     } else {
//       // Look up value in the flat formData structure
//       fieldValue = formData[field.fieldName];
//     }

//     // Fallback to default value
//     fieldValue = fieldValue || field.defaultValue;

//     const commonProps = {
//       key: field.id,
//       label: field.label,
//       placeholder: field.placeholder,
//       isRequired: field.isRequired,
//       value: fieldValue,
//       // Pass pageName and pageIndex to handleFieldChange
//       onChange: value =>
//         handleFieldChange(field.fieldName, value, pageName, pageIndex),
//       onChangeText: text =>
//         handleFieldChange(field.fieldName, text, pageName, pageIndex),
//     };

//     switch (field.fieldType) {
//       case 'Text':
//         return <InputGroup {...commonProps} />;
//       case 'Number':
//         return <NumberInputGroup {...commonProps} />;
//       case 'Checkbox':
//         return (
//           <CheckboxGroup {...commonProps} onChange={commonProps.onChange} />
//         );
//       case 'TextArea':
//         return <DescriptionInput {...commonProps} />;
//       case 'Page':
//         if (field.fieldName === 'attributes') {
//           // Renders the entire VariantUI block (sections + fields) here
//           return VariantUI?.sections ? (
//             <View key={field.id} style={styles.variantAttributesBlock}>
//               <Text style={styles.variantBlockTitle}>
//                 {VariantUI.title || field.label}
//               </Text>

//               {VariantUI.sections.map(section => (
//                 <View key={section.id} style={styles.sectionContainer}>
//                   <Text style={styles.sectionTitle}>{section.title}</Text>

//                   {/* Recursively reuse renderField for the variant attribute fields */}
//                   {/* FIX: Pass the current pageName and pageIndex context to nested fields */}
//                   {section.fields.map(
//                     attributeField =>
//                       attributeField.isVisible !== false &&
//                       renderField(attributeField, pageName, pageIndex),
//                   )}
//                 </View>
//               ))}
//             </View>
//           ) : (
//             <Text style={styles.loadingText}>Loading Variant UI...</Text>
//           );
//         }
//         return null;

// case 'Select':
//   // --- Data Mapping (For the initial parent category dropdown) ---
//   const rawCategoryItems = getCategory?.items ?? [];
//   const mappedCategoryOptions = rawCategoryItems
//     .filter(item => item && item.id && item.name)
//     .map(item => ({
//       value: String(item.id),
//       label: item.name,
//     }));

//   // --- Handler to Fetch Children and Update State ---
//   const handleCategorySelect = async selectedId => {
//     // 1. Update the form state for the currently selected dropdown (Category ID)
//     // Use the commonProps.onChange, which already includes the variant context if applicable
//     commonProps.onChange(selectedId);

//     try {
//       // 2. Fetch the child data (Subcategories)
//       const response = await fetchChildCategories(
//         'Category',
//         selectedId,
//         'parentId', // Query key is 'parentId'
//       );

//       // 3. Fetch Variant UI data (Assuming 'categoryId' is the key here)
//       const categoryData = await fetchChildCategories(
//         'Products/variant-page-with-attributes',
//         selectedId, // Use the actual selectedId here
//         'categoryId',
//       );
//       setVariantUI(categoryData?.data);

//       const subcategoryItems = response?.data?.items ?? [];
//       setSubcategories(subcategoryItems);
//     } catch (error) {
//       console.error('Failed to fetch data:', error);
//       setSubcategories([]);
//     }
//   };

//   // --- Subcategory Options Mapping ---
//   const mappedSubcategoryOptions = subcategories
//     .filter(item => item && item.id && item.name)
//     .map(item => ({
//       value: String(item.id),
//       label: item.name,
//     }));

//   // --- RENDERING LOGIC ---
//   if (field?.fieldName === 'category_id') {
//     return (
//       <DropdownGroup
//         {...commonProps}
//         options={mappedCategoryOptions}
//         onSelect={handleCategorySelect} // Triggers fetch
//         onChangeText={() => {}}
//       />
//     );
//   } else if (field?.fieldName === 'subcategory_id') {
//     return (
//       <DropdownGroup
//         {...commonProps}
//         options={mappedSubcategoryOptions}
//         onSelect={commonProps.onChange}
//         onChangeText={() => {}}
//       />
//     );
//   }

//   // For all other 'Select' fields
//   return (
//     <DropdownGroup
//       {...commonProps}
//       options={field.options ?? []}
//       onSelect={commonProps.onChange}
//       onChangeText={() => {}}
//     />
//   );

//       case 'File':
//         return (
//           <ProductImagePicker
//             {...commonProps}
//             key={field.id}
//             images={formData[field.fieldName] || []}
//             setImages={commonProps.onChange}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // --- 4. SUBMISSION HANDLER ---
//   const handleSubmit = async () => {
//     // 1. Transform the formData into the API's required structure
//     const submissionData = transformFormDataForSubmission(
//       formData,
//       getAllProductModal?.pages,
//     );
//     // 2. Create a FormData object (required for multipart/form-data)

//     const formPayload = new FormData(); //issue from here below

//     // Append all key-value pairs to FormData
//     for (const key in submissionData) {
//       if (Object.prototype.hasOwnProperty.call(submissionData, key)) {
//         const value = submissionData[key];

//         formPayload.append(key, value);
//       }
//     }

//     // 3. Log the payload (for debugging) and submit
//     console.log('Final FormData Keys:', formPayload);
//     console.log('Final Submission Payload:', submissionData); // Showing the intermediate object structure

//     try {
//       // You'll need to use your API function here, e.g.,
//       // const response = await submitProductData(formPayload);
//       Alert.alert('Success', 'Product submitted successfully!');
//     } catch (error) {
//       console.error('Submission failed:', error);
//       Alert.alert('Error', 'Failed to submit product data.');
//     }
//   };

//   return (
//     <ScrollView contentContainerStyle={styles.contentContainer}>
//       <Header title={'Add New Product'} onBackPress={true} />
//       <Loader visible={isLoadinAllModal || isSubmitting} />

//       {/* 2. RENDERING: Map over the non-variant pages */}
//       {nonVariantPages.map(page => (
//         <View key={page.pageId}>
//           <View style={styles.headerContainer}>
//             <Text style={styles.pageTitle}>{page.title}</Text>
//           </View>

//           {page.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>
//               {section.description && (
//                 <Text style={styles.sectionDescription}>
//                   {section.description}
//                 </Text>
//               )}

//               {/* Render fields within the section (No pageName/index passed here) */}
//               {section.fields.map(
//                 field => field.isVisible !== false && renderField(field),
//               )}
//             </View>
//           ))}
//         </View>
//       ))}

//       {/* 3. RENDERING: Dynamic Variant Pages (The page that can be cloned) */}
//       {variantPages.map((page, index) => (
//         <View key={page.uniqueId} style={styles.variantPageWrapper}>
//           <View style={styles.headerContainer}>
//             <Text style={styles.pageTitle}>
//               {page.title} {index > 0 ? `(Instance ${index + 1})` : ''}
//             </Text>

//             {/* Conditional "Add New" button ONLY on the first instance */}
//             {index === 0 && (
//               <TouchableOpacity
//                 style={styles.addButton}
//                 onPress={handleAddNewVariantPage}>
//                 <Text style={styles.addButtonText}>+ Add New</Text>
//               </TouchableOpacity>
//             )}
//           </View>

//           {page.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>
//               {section.description && (
//                 <Text style={styles.sectionDescription}>
//                   {section.description}
//                 </Text>
//               )}

//               {/* Render sorted fields within the section (Page name and index passed here) */}
//               {section.fields.map(
//                 field =>
//                   field.isVisible !== false &&
//                   renderField(field, page.pageName, index),
//               )}
//             </View>
//           ))}
//         </View>
//       ))}

//       <TouchableOpacity
//         style={[
//           styles.submitButton,
//           isSubmitting && styles.submitButtonDisabled,
//         ]}
//         onPress={handleSubmit}
//         disabled={isSubmitting}>
//         <Text style={styles.submitButtonText}>
//           {isSubmitting ? 'SAVING...' : 'SAVE PRODUCT'}
//         </Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// export default AddNewProduct;

// // =========================================================================
// // STYLES
// // =========================================================================
// const styles = StyleSheet.create({
//   contentContainer: {
//     padding: 20,
//     backgroundColor: '#fff',
//     minHeight: '100%',
//   },
//   variantPageWrapper: {
//     marginBottom: 30, // Space between dynamically added pages
//   },
//   headerContainer: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: 15,
//   },
//   addButtonText: {
//     color: '#FFFFFF',
//     fontSize: 14,
//     fontWeight: '600',
//   },
//   addButton: {
//     backgroundColor: '#F89941',
//     borderRadius: 5,
//     width: 100,
//     height: 40,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   pageTitle: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     marginTop: 10,
//     paddingBottom: 5,
//     color: '#333',
//   },
//   sectionContainer: {
//     marginBottom: 25,
//     paddingBottom: 15,
//     borderBottomWidth: StyleSheet.hairlineWidth,
//     borderBottomColor: '#ccc',
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '700',
//     color: '#333',
//     marginBottom: 4,
//   },
//   sectionDescription: {
//     fontSize: 14,
//     color: '#888',
//     marginBottom: 15,
//   },
//   submitButton: {
//     backgroundColor: '#F89941',
//     padding: 15,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 30,
//     marginBottom: 50,
//   },
//   submitButtonDisabled: {
//     backgroundColor: '#FFA07A',
//     opacity: 0.7,
//   },
//   submitButtonText: {
//     color: '#FFFFFF',
//     fontSize: 16,
//     fontWeight: '700',
//   },
//   // Styles for Variant Attributes Block
//   variantAttributesBlock: {
//     marginTop: 20,
//     padding: 15,
//     borderRadius: 8,
//     backgroundColor: '#F9FAFB', // Light gray background
//     borderWidth: 1,
//     borderColor: '#E0E0E0',
//   },
//   variantBlockTitle: {
//     fontSize: 18,
//     fontWeight: '800',
//     color: '#333',
//     marginBottom: 15,
//   },
//   loadingText: {
//     fontSize: 14,
//     color: '#999',
//     padding: 10,
//     backgroundColor: '#f0f0f0',
//     borderRadius: 5,
//     textAlign: 'center',
//   },
// });

//final working at 12-11

// //machine written code

// import {
//   StyleSheet,
//   Text,
//   View,
//   ScrollView,
//   TouchableOpacity,
//   Alert,
//   Platform,
// } from 'react-native';
// import FormData from 'form-data';
// import React, {useState, useMemo, useEffect} from 'react';
// // Assuming these paths are correct in your React Native project
// import PriceVariantGroup from '../../components/PriceVariantGroup';
// import ProductImagePicker from '../../components/ProductImagePicker';
// import useProductModal from '../../../hooks/useProduct'; // Assuming this provides getCategory/fetchChildCategories
// import InputGroup from '../../components/InputGroup';
// import DescriptionInput from '../../components/DescriptionInput';
// import DropdownGroup from '../../components/DropdownGroup';
// import CheckboxGroup from '../../components/CheckBoxGroup';
// import NumberInputGroup from '../../components/NumberInputGroup';
// import {baseURL} from '../../../config/constant';
// // Assuming fetchChildCategories is defined and imported
// // import {fetchChildCategories} from '../../../utils/apiFunction';
// import Header from '../../components/Header';
// import Loader from '../../components/Loader';
// import {fetchChildCategories} from '../../../utils/apiFunction';

// // =========================================================================
// // 🧩 STATIC MOCK JSON DATA (Simulating API response)
// // =========================================================================
// const mockGetAllProductModal = {
//   pageGroupName: 'Ecommerce_Product',
//   title: 'Ecommerce_Product',
//   description: 'Product creation workflow for merchants (UAE-first)',
//   pages: [
//     {
//       pageId: 151,
//       pageName: 'Ecommerce_Product_Basic',
//       title: 'New Product — Basic Information',
//       subtitle: '',
//       description: '',
//       order: 1,
//       sections: [
//         {
//           id: 260,
//           name: 'BasicInformation',
//           title: 'Basic Information',
//           description: 'Title, description, category, brand and subcategory',
//           order: 1,
//           fields: [
//             {
//               id: 1040,
//               fieldName: 'product_title',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Product Title*',
//               placeholder: 'Enter product title',
//               helpText: 'Title of the product',
//               displayName: '',
//               regexPattern: "^[A-Za-z0-9\\s\\-\\&'\\.,()]{2,200}$",
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Product Title',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1041,
//               fieldName: 'description',
//               fieldType: 'TextArea',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 2,
//               isVisible: true,
//               label: 'Description*',
//               placeholder: 'Enter product description',
//               helpText: 'Product description',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Description',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1042,
//               fieldName: 'category_id',
//               fieldType: 'Select',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 3,
//               isVisible: true,
//               label: 'Category*',
//               placeholder: 'Select category',
//               helpText: 'Filter products by category',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: [
//                 {
//                   value: 'electronics',
//                   label: 'Electronics',
//                   localizations: null,
//                 },
//                 {
//                   value: 'clothing',
//                   label: 'Clothing',
//                   localizations: null,
//                 },
//                 {
//                   value: 'books',
//                   label: 'Books',
//                   localizations: null,
//                 },
//                 {
//                   value: 'home',
//                   label: 'Home & Garden',
//                   localizations: null,
//                 },
//                 {
//                   value: 'sports',
//                   label: 'Sports & Outdoors',
//                   localizations: null,
//                 },
//                 {
//                   value: 'toys',
//                   label: 'Toys & Games',
//                   localizations: null,
//                 },
//                 {
//                   value: 'beauty',
//                   label: 'Beauty & Personal Care',
//                   localizations: null,
//                 },
//                 {
//                   value: 'automotive',
//                   label: 'Automotive',
//                   localizations: null,
//                 },
//                 {
//                   value: 'stationery',
//                   label: 'Stationery',
//                   localizations: null,
//                 },
//               ],
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Category',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1043,
//               fieldName: 'brand',
//               fieldType: 'Select',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 4,
//               isVisible: true,
//               label: 'Brand*',
//               placeholder: 'Select brand',
//               helpText: 'Filter products by brand',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Brand',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1044,
//               fieldName: 'subcategory_id',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 5,
//               isVisible: true,
//               label: 'Subcategory*',
//               placeholder: 'Enter subcategory ID',
//               helpText: 'Product subcategory',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: [
//                 {
//                   value: 'smartphones',
//                   label: 'Smartphones',
//                   localizations: null,
//                 },
//                 {
//                   value: 'laptops',
//                   label: 'Laptops',
//                   localizations: null,
//                 },
//                 {
//                   value: 'tablets',
//                   label: 'Tablets',
//                   localizations: null,
//                 },
//                 {
//                   value: 'headphones',
//                   label: 'Headphones',
//                   localizations: null,
//                 },
//                 {
//                   value: 'cameras',
//                   label: 'Cameras',
//                   localizations: null,
//                 },
//                 {
//                   value: 'mens_clothing',
//                   label: "Men's Clothing",
//                   localizations: null,
//                 },
//                 {
//                   value: 'womens_clothing',
//                   label: "Women's Clothing",
//                   localizations: null,
//                 },
//                 {
//                   value: 'kids_clothing',
//                   label: "Kids' Clothing",
//                   localizations: null,
//                 },
//                 {
//                   value: 'shoes',
//                   label: 'Shoes',
//                   localizations: null,
//                 },
//                 {
//                   value: 'accessories',
//                   label: 'Accessories',
//                   localizations: null,
//                 },
//               ],
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Subcategory',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [
//             {
//               id: 'discard',
//               buttonId: 'discard',
//               label: 'Discard',
//               type: 'secondary',
//               layout: 'default layout',
//               apiCallRequired: false,
//               method: 'GET',
//               endpoint: '',
//               submitSectionId: null,
//               navigateTo: '',
//               params: '{}',
//             },
//             {
//               id: 'next',
//               buttonId: 'next',
//               label: 'Next',
//               type: 'primary',
//               layout: 'default layout',
//               apiCallRequired: false,
//               method: 'POST',
//               endpoint: '/api/v1/Product/basic',
//               submitSectionId: null,
//               navigateTo: '',
//               params: '{}',
//             },
//           ],
//         },
//       ],
//       data: null,
//     },
//     {
//       pageId: 152,
//       pageName: 'Ecommerce_Product_Details',
//       title: 'New Product — Additional Details',
//       subtitle: '',
//       description: '',
//       order: 2,
//       sections: [
//         {
//           id: 261,
//           name: 'Policies',
//           title: 'Policies',
//           description: 'Default Section Description',
//           order: 1,
//           fields: [
//             {
//               id: 1045,
//               fieldName: 'is_returnable',
//               fieldType: 'Checkbox',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Returnable*',
//               placeholder: '',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Returnable',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1046,
//               fieldName: 'return_window_days',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Return Window (days)*',
//               placeholder: 'e.g., 7',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Return Window (days)',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1047,
//               fieldName: 'has_variants',
//               fieldType: 'Checkbox',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 2,
//               isVisible: true,
//               label: 'Products with Variants*',
//               placeholder: '',
//               helpText: 'Show only products with variants',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Products with Variants',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1048,
//               fieldName: 'variation_theme',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 3,
//               isVisible: true,
//               label: 'Variation Theme*',
//               placeholder: 'Select variation theme',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Variation Theme',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [],
//         },
//         {
//           id: 262,
//           name: 'ProductAttributes',
//           title: 'Product Attributes',
//           description: 'Default Section Description',
//           order: 2,
//           fields: [
//             {
//               id: 1049,
//               fieldName: 'gender',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Gender*',
//               placeholder: 'Select gender',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Gender',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [],
//         },
//         {
//           id: 263,
//           name: 'IdentifiersSEO',
//           title: 'Identifiers & SEO',
//           description: 'Default Section Description',
//           order: 3,
//           fields: [
//             {
//               id: 1050,
//               fieldName: 'external_product_type',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'External Product Type*',
//               placeholder: 'Select external product type',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'External Product Type',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1051,
//               fieldName: 'external_product_id',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'External Product ID*',
//               placeholder: 'Enter external product ID',
//               helpText: '8–14 digits',
//               displayName: '',
//               regexPattern: '^[0-9]{8,14}$',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'External Product ID',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1052,
//               fieldName: 'mpn',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 2,
//               isVisible: true,
//               label: 'MPN*',
//               placeholder: 'Enter MPN',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'MPN',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1053,
//               fieldName: 'model_number',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 3,
//               isVisible: true,
//               label: 'Model Number*',
//               placeholder: 'Enter model number',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Model Number',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1054,
//               fieldName: 'country_of_origin',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 4,
//               isVisible: true,
//               label: 'Country of Origin*',
//               placeholder: 'Select country',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Country of Origin',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1055,
//               fieldName: 'is_searchable',
//               fieldType: 'Checkbox',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 5,
//               isVisible: true,
//               label: 'Searchable*',
//               placeholder: '',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Searchable',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1056,
//               fieldName: 'slug',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 6,
//               isVisible: true,
//               label: 'Brand Slug*',
//               placeholder: 'brand-slug (auto-generated)',
//               helpText:
//                 'URL-friendly identifier (auto-generated from name if empty)',
//               displayName: '',
//               regexPattern: '^[a-z0-9]+(?:-[a-z0-9]+)*$',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Brand Slug',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [
//             {
//               id: 'default_button',
//               buttonId: 'default_button',
//               label: 'Back',
//               type: 'secondary',
//               layout: 'default layout',
//               apiCallRequired: false,
//               method: 'GET',
//               endpoint: '',
//               submitSectionId: null,
//               navigateTo: '',
//               params: '{}',
//             },
//             {
//               id: 'default_button',
//               buttonId: 'default_button',
//               label: 'Next',
//               type: 'primary',
//               layout: 'default layout',
//               apiCallRequired: false,
//               method: 'POST',
//               endpoint: '/api/v1/Product/details',
//               submitSectionId: null,
//               navigateTo: '',
//               params: '{}',
//             },
//           ],
//         },
//       ],
//       data: null,
//     },
//     {
//       pageId: 153,
//       pageName: 'Ecommerce_Product_Variant',
//       title: 'Variant Configuration',
//       subtitle: '',
//       description: '',
//       isCollection: true,
//       order: 3,
//       sections: [
//         {
//           id: 264,
//           name: 'VariantDetails',
//           title: 'Variant Details',
//           description: 'Default Section Description',
//           order: 1,
//           fields: [
//             {
//               id: 1040,
//               fieldName: 'attributes',
//               fieldType: 'Page', // This is the placeholder that triggers VariantUI rendering
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Product Attributes*',
//               placeholder: 'Enter product attributes',
//               helpText: 'Attributes of the product',
//               displayName: '',
//               regexPattern: "^[A-Za-z0-9\\s\\-\\&'\\.,()]{2,200}$",
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               endpoint:
//                 'https://dev-backend.nextgenedus.com/api/v1/Products/variant-page-with-attributes',
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Product Attributes',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1057,
//               fieldName: 'sku',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'SKU*',
//               placeholder: 'Enter SKU',
//               helpText: 'Stock keeping unit identifier',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'SKU',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1058,
//               fieldName: 'serial_number',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Serial Number*',
//               placeholder: 'Enter serial number',
//               helpText: 'Unique serial number for this variant',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Serial Number',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1059,
//               fieldName: 'add_category_attributes',
//               fieldType: 'Button',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 4,
//               isVisible: true,
//               label: 'Add Category Attributes*',
//               placeholder: '',
//               helpText:
//                 'Load dynamic category attributes based on selected category',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [
//                 {
//                   id: 'get_variant_page_with_attributes',
//                   label: 'Get Variant Page with Attributes',
//                   type: 'api_call',
//                   apiCallRequired: true,
//                   method: 'GET',
//                   endpoint: '/api/v1/Product/variant-page-with-attributes',
//                   params: '{"categoryId":"{category_id}"}',
//                   chainedActions: null,
//                   mapResponseToFields: '{}',
//                 },
//               ],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Add Category Attributes',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1060,
//               fieldName: 'is_active',
//               fieldType: 'Checkbox',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 5,
//               isVisible: true,
//               label: 'Active*',
//               placeholder: 'Default Placeholder',
//               helpText: 'Enable to activate deal immediately',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Active',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [],
//         },
//         {
//           id: 265,
//           name: 'PhysicalSpecifications',
//           title: 'Physical Specifications',
//           description: 'Default Section Description',
//           order: 2,
//           fields: [
//             {
//               id: 1061,
//               fieldName: 'dimension_unit',
//               fieldType: 'Select',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Dimension Unit*',
//               placeholder: 'Select unit',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Dimension Unit',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1062,
//               fieldName: 'width',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Width*',
//               placeholder: 'Enter width',
//               helpText: 'Variant-specific width dimension',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Width',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1063,
//               fieldName: 'height',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 2,
//               isVisible: true,
//               label: 'Height*',
//               placeholder: 'Enter height',
//               helpText: 'Variant-specific height dimension',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Height',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1064,
//               fieldName: 'length',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 3,
//               isVisible: true,
//               label: 'Length*',
//               placeholder: 'Enter length',
//               helpText: 'Variant-specific length dimension',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Length',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1065,
//               fieldName: 'weight_unit',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 4,
//               isVisible: true,
//               label: 'Weight Unit*',
//               placeholder: 'Enter weight unit (e.g., Gm, Kg)',
//               helpText: 'Unit of weight measurement',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Weight Unit',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1066,
//               fieldName: 'weight',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 5,
//               isVisible: true,
//               label: 'Weight*',
//               placeholder: 'Enter weight',
//               helpText: 'Product weight',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Weight',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [],
//         },
//         {
//           id: 266,
//           name: 'PackageDimensions',
//           title: 'Package Dimensions',
//           description: 'Default Section Description',
//           order: 3,
//           fields: [
//             {
//               id: 1067,
//               fieldName: 'package_dimension_unit',
//               fieldType: 'Select',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Package Dimension Unit*',
//               placeholder: 'Select unit',
//               helpText: 'Unit for package measurements',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Package Dimension Unit',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1068,
//               fieldName: 'package_width',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Package Width*',
//               placeholder: 'Enter package width',
//               helpText: 'Shipping package width',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Package Width',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1069,
//               fieldName: 'package_height',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 2,
//               isVisible: true,
//               label: 'Package Height*',
//               placeholder: 'Enter package height',
//               helpText: 'Shipping package height',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Package Height',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1070,
//               fieldName: 'package_length',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 3,
//               isVisible: true,
//               label: 'Package Length*',
//               placeholder: 'Enter package length',
//               helpText: 'Shipping package length',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Package Length',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1071,
//               fieldName: 'package_weight',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 4,
//               isVisible: true,
//               label: 'Package Weight*',
//               placeholder: 'Enter package weight',
//               helpText: 'Total shipping package weight',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Package Weight',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [],
//         },
//         {
//           id: 267,
//           name: 'VariantPrice',
//           title: 'Variant Price',
//           description: 'Default Section Description',
//           order: 4,
//           fields: [
//             {
//               id: 1072,
//               fieldName: 'variant_price',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Variant Price*',
//               placeholder: 'Enter variant price (optional)',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Variant Price',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1073,
//               fieldName: 'variant_currency_code',
//               fieldType: 'Select',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Currency*',
//               placeholder: 'Select currency',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Currency',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1074,
//               fieldName: 'variant_quantity',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 2,
//               isVisible: true,
//               label: 'Quantity*',
//               placeholder: 'Enter stock quantity',
//               helpText: '',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Quantity',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [],
//         },
//         {
//           id: 268,
//           name: 'VariantImages',
//           title: 'Variant Images',
//           description: 'Default Section Description',
//           order: 5,
//           fields: [
//             {
//               id: 1075,
//               fieldName: 'variant_images',
//               fieldType: 'File',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Variant Images*',
//               placeholder: 'Upload images',
//               helpText: 'JPG/PNG up to 6 files, 5 MB each',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: {
//                 maxFiles: 1,
//                 allowedExtensions: ['.jpg', '.jpeg', '.png'],
//                 minFileSize: 1024,
//                 maxFilesPerField: 6,
//                 allowMultipleFiles: true,
//                 requireFileExtension: true,
//                 validateFileContent: true,
//                 required: true,
//                 fileType: ['image/jpeg', 'image/png'],
//                 maxFileSize: 5242880,
//                 maxFileSizeMB: '5',
//                 validation: '',
//               },
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Variant Images',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [
//             {
//               id: 'default_button',
//               buttonId: 'default_button',
//               label: 'Back',
//               type: 'secondary',
//               layout: 'default layout',
//               apiCallRequired: false,
//               method: 'GET',
//               endpoint: '',
//               submitSectionId: null,
//               navigateTo: '',
//               params: '{}',
//             },
//             {
//               id: 'default_button',
//               buttonId: 'default_button',
//               label: 'Save Variant',
//               type: 'primary',
//               layout: 'default layout',
//               apiCallRequired: false,
//               method: 'POST',
//               endpoint: '/api/v1/Product/variants',
//               submitSectionId: null,
//               navigateTo: '',
//               params: '{}',
//             },
//           ],
//         },
//       ],
//       data: null,
//     },
//     {
//       pageId: 154,
//       pageName: 'Ecommerce_Product_Compliance',
//       title: 'New Product — Safety & Compliance',
//       subtitle: '',
//       description: '',
//       order: 4,
//       sections: [
//         {
//           id: 269,
//           name: 'hazmat',
//           title: 'Hazardous Materials',
//           description: 'Dangerous goods and hazmat classification',
//           order: 1,
//           fields: [
//             {
//               id: 1076,
//               fieldName: 'is_hazmat',
//               fieldType: 'Checkbox',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Contains hazardous materials*',
//               placeholder: '',
//               helpText: 'Check if product contains dangerous goods or hazmat',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Contains hazardous materials',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [],
//         },
//         {
//           id: 270,
//           name: 'batteries',
//           title: 'Battery Information',
//           description: 'Battery content and specifications',
//           order: 2,
//           fields: [
//             {
//               id: 1077,
//               fieldName: 'contains_batteries',
//               fieldType: 'Checkbox',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Contains batteries*',
//               placeholder: '',
//               helpText: 'Check if product contains or requires batteries',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Contains batteries',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1078,
//               fieldName: 'battery_type',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Battery Type*',
//               placeholder: 'Select battery type',
//               helpText: 'Type of battery included or required',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: [
//                 {
//                   value: 'AAA',
//                   label: 'AAA',
//                   localizations: null,
//                 },
//                 {
//                   value: 'AA',
//                   label: 'AA',
//                   localizations: null,
//                 },
//                 {
//                   value: 'C',
//                   label: 'C',
//                   localizations: null,
//                 },
//                 {
//                   value: 'D',
//                   label: 'D',
//                   localizations: null,
//                 },
//                 {
//                   value: '9V',
//                   label: '9V',
//                   localizations: null,
//                 },
//                 {
//                   value: 'CR2032',
//                   label: 'CR2032 (Coin)',
//                   localizations: null,
//                 },
//                 {
//                   value: 'Lithium',
//                   label: 'Lithium Ion',
//                   localizations: null,
//                 },
//                 {
//                   value: 'LiPo',
//                   label: 'Lithium Polymer',
//                   localizations: null,
//                 },
//                 {
//                   value: 'NiMH',
//                   label: 'NiMH',
//                   localizations: null,
//                 },
//                 {
//                   value: 'Other',
//                   label: 'Other',
//                   localizations: null,
//                 },
//               ],
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Battery Type',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [],
//         },
//         {
//           id: 271,
//           name: 'ageRestrictions',
//           title: 'Age Restrictions',
//           description: 'Minimum and maximum age recommendations',
//           order: 3,
//           fields: [
//             {
//               id: 1079,
//               fieldName: 'age_min',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Minimum Age*',
//               placeholder: 'Enter minimum age',
//               helpText: 'Minimum recommended age in years (e.g., 3)',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Minimum Age',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1080,
//               fieldName: 'age_max',
//               fieldType: 'Number',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Maximum Age*',
//               placeholder: 'Enter maximum age',
//               helpText: 'Maximum recommended age in years (e.g., 12)',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Maximum Age',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [],
//         },
//         {
//           id: 272,
//           name: 'certifications',
//           title: 'Certifications & Safety',
//           description: 'Safety certifications and compliance notes',
//           order: 4,
//           fields: [
//             {
//               id: 1081,
//               fieldName: 'certification_codes',
//               fieldType: 'Text',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 0,
//               isVisible: true,
//               label: 'Certification Codes*',
//               placeholder: 'e.g., CE, FCC, UL, ASTM F963',
//               helpText:
//                 'Safety and quality certification codes (comma-separated)',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Certification Codes',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//             {
//               id: 1082,
//               fieldName: 'safety_notes',
//               fieldType: 'TextArea',
//               isRequired: true,
//               isReadOnly: false,
//               displayOrder: 1,
//               isVisible: true,
//               label: 'Safety Notes*',
//               placeholder:
//                 'Enter safety warnings, precautions, or instructions',
//               helpText:
//                 'Important safety information, warnings, and precautions',
//               displayName: '',
//               regexPattern: '',
//               defaultValue: null,
//               maxLength: null,
//               minLength: null,
//               otpLength: null,
//               options: null,
//               fileConfig: null,
//               actions: [],
//               fieldMetadata: null,
//               localization: {
//                 languageCode: 'en',
//                 countryCode: 'AE',
//                 localizedText: 'Safety Notes',
//                 localizedPlaceholder: null,
//                 localizedHelpText: null,
//               },
//               isDefault: false,
//               isOpenView: false,
//             },
//           ],
//           buttons: [
//             {
//               id: 'back',
//               buttonId: 'back',
//               label: 'Back',
//               type: 'secondary',
//               layout: 'default layout',
//               apiCallRequired: false,
//               method: 'GET',
//               endpoint: '',
//               submitSectionId: null,
//               navigateTo: '',
//               params: '{}',
//             },
//             {
//               id: 'next',
//               buttonId: 'next',
//               label: 'Next',
//               type: 'secondary',
//               layout: 'default layout',
//               apiCallRequired: false,
//               method: 'POST',
//               endpoint: '/api/v1/Product/compliance',
//               submitSectionId: null,
//               navigateTo: '',
//               params: '{}',
//             },
//             {
//               id: 'fullSubmit',
//               buttonId: 'fullSubmit',
//               label: 'Submit Complete Product',
//               type: 'primary',
//               layout: 'default layout',
//               apiCallRequired: true,
//               method: 'POST',
//               endpoint: '/api/v1/Product/complete',
//               submitSectionId: null,
//               navigateTo: '',
//               params: '{}',
//             },
//           ],
//         },
//       ],
//       data: null,
//     },
//   ],
// };

// // =========================================================================
// // 🔄 TRANSFORMATION LOGIC (Kept largely the same for submission structure)
// // =========================================================================
// const transformFormDataForSubmission = (formData, apiMap) => {
//   // console.log('--- Transformation Started ---');
//   const submissionBody = {};
//   const variantData = formData.Ecommerce_Product_Variant || [];

//   // 1. Process Non-Variant Pages (Standard Fields)
//   for (const pageConfig of apiMap) {
//     const isVariantPage = pageConfig.pageName === 'Ecommerce_Product_Variant';

//     if (isVariantPage) {
//       continue;
//     }

//     // Now, iterate through all sections within the current page
//     for (const sectionConfig of pageConfig.sections) {
//       // The fields array is sectionConfig.fields
//       for (const fieldConfig of sectionConfig.fields) {
//         const fieldName = fieldConfig.fieldName;
//         const value = formData[fieldName];

//         if (value !== undefined) {
//           // Construct key: PageName.SectionName.fieldName
//           const key = `${pageConfig.pageName}.${sectionConfig.name}.${fieldName}`;

//           submissionBody[key] =
//             typeof value === 'boolean' ? String(value) : value;
//         }
//       }
//     }
//   }

//   // 2. Process Variant Pages (Array of Objects)
//   const variantPageConfig = apiMap.find(
//     config => config.pageName === 'Ecommerce_Product_Variant',
//   );

//   if (!variantPageConfig || variantPageConfig.sections.length === 0) {
//     console.warn('Variant page or sections not found in apiMap.');
//   } else {
//     // Collect all static fieldNames from all variant sections
//     let staticVariantFieldNames = [];
//     variantPageConfig.sections.forEach(section => {
//       section.fields.forEach(field => {
//         staticVariantFieldNames.push(field.fieldName);
//       });
//     });

//     const VARIANT_KEY = variantPageConfig.pageName; // 'Ecommerce_Product_Variant'
//     const SECTION_KEY = variantPageConfig.sections[0].name; // e.g., 'VariantDetails'

//     variantData.forEach((variant, index) => {
//       // Combine static fields with dynamically added fields (like 'color' or 'size')
//       const allVariantFieldNames = new Set([
//         ...staticVariantFieldNames,
//         ...Object.keys(variant),
//       ]);

//       for (const fieldName of allVariantFieldNames) {
//         const value = variant[fieldName];

//         if (fieldName === VARIANT_KEY || value === undefined) continue;

//         // Construct the final key: PageName[index].SectionName.fieldName
//         const key = `${VARIANT_KEY}[${index}].${SECTION_KEY}.${fieldName}`;

//         submissionBody[key] =
//           typeof value === 'boolean' ? String(value) : value;
//       }
//     });
//   }

//   console.log('✅ Final API Submission Body (Object):', submissionBody);
//   return submissionBody;
// };

// // =========================================================================
// // 💻 ADD NEW PRODUCT COMPONENT (Dynamic Rendering Logic)
// // =========================================================================
// const AddNewProduct = () => {
//   const [subcategories, setSubcategories] = useState([]);
//   const [VariantUI, setVariantUI] = useState(null); // Dynamic attributes UI

//   // console.log(VariantUI, '**********');

//   // Mocking the useProductModal hook with the static JSON data
//   const {
//     // getAllProductModal, // We are overriding this with mock data
//     basicInformation,
//     getCategory,
//     isLoadinAllModal,
//     isLoading: isSubmitting,
//   } = useProductModal();

//   // Use the static mock JSON data
//   const getAllProductModal = mockGetAllProductModal;

//   const [formData, setFormData] = useState({});
//   const [productVariants, setProductVariants] = useState([]); // Not used, but kept for context
//   console.log(formData, '**********');
//   // State to manage dynamically added variant pages
//   const [variantPages, setVariantPages] = useState([]);

//   console.log(variantPages, 'varient pages');

//   // 1. Refactor useMemo to perform all **sorting** and page extraction
//   const {nonVariantPages, variantPageTemplate} = useMemo(() => {
//     const rawPages = getAllProductModal?.pages || [];
//     // 1. Sort pages by 'order'
//     const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);

//     const nonVariantPages = [];
//     let variantTemplate = null;

//     sortedPages.forEach(page => {
//       // Deep copy to ensure safe manipulation
//       const pageCopy = JSON.parse(JSON.stringify(page));

//       // 2. Sort sections within each page by 'order'
//       pageCopy.sections.sort((a, b) => a.order - b.order);

//       pageCopy.sections.forEach(section => {
//         // 3. Sort fields within each section by 'displayOrder'
//         if (section.fields) {
//           section.fields.sort((a, b) => a.displayOrder - b.displayOrder);
//         }
//       });
//       // End sorting logic

//       const isTargetPage = pageCopy.pageName === 'Ecommerce_Product_Variant';

//       if (isTargetPage) {
//         // The 'attributes' field (id: 1040) is now loaded dynamically and sorted correctly.
//         variantTemplate = pageCopy;
//       } else {
//         // Standard non-variant page
//         nonVariantPages.push(pageCopy);
//       }
//     });

//     return {
//       nonVariantPages,
//       variantPageTemplate: variantTemplate,
//     };
//   }, [getAllProductModal]);

//   // 2. Initialize the dynamic pages when the template is ready
//   useEffect(() => {
//     if (variantPageTemplate && variantPages.length === 0) {
//       // Add the first instance of the variant page with a unique ID
//       setVariantPages([{...variantPageTemplate, uniqueId: Date.now()}]);
//     }
//   }, [variantPageTemplate, variantPages.length]);

//   // 3. Handler to add a new variant page instance (used when isCollection=true)
//   const handleAddNewVariantPage = () => {
//     if (!variantPageTemplate) {
//       Alert.alert('Error', 'Variant page template not loaded.');
//       return;
//     }

//     // Create a new unique instance of the template page
//     const newPageInstance = {
//       ...JSON.parse(JSON.stringify(variantPageTemplate)), // Deep copy sections and fields
//       uniqueId: Date.now() + Math.random(), // Ensure a unique key
//     };

//     setVariantPages(prev => [...prev, newPageInstance]);
//   };

//   const handleFieldChange = (
//     fieldName,
//     value,
//     pageName = null,
//     pageIndex = null,
//   ) => {
//     const VARIANT_KEY = 'Ecommerce_Product_Variant';

//     // Check if the field belongs to a dynamic variant page
//     if (pageName === VARIANT_KEY && pageIndex !== null) {
//       setFormData(prev => {
//         const currentVariants = prev[VARIANT_KEY] || [];
//         const targetVariant = {...(currentVariants[pageIndex] || {})};

//         targetVariant[fieldName] = value;

//         const newVariants = [...currentVariants];
//         newVariants[pageIndex] = targetVariant;

//         return {
//           ...prev,
//           [VARIANT_KEY]: newVariants,
//         };
//       });
//     } else {
//       // Handle non-variant pages (basic information)
//       setFormData(prev => ({...prev, [fieldName]: value}));
//     }
//   };

//   const renderField = (field, pageName = null, pageIndex = null) => {
//     const VARIANT_KEY = 'Ecommerce_Product_Variant';
//     let fieldValue;

//     if (pageName === VARIANT_KEY && pageIndex !== null) {
//       fieldValue = formData[VARIANT_KEY]?.[pageIndex]?.[field.fieldName];
//     } else {
//       fieldValue = formData[field.fieldName];
//     }

//     fieldValue = fieldValue ?? field.defaultValue;

//     const commonProps = {
//       key: field.id,
//       label: field.label,
//       placeholder: field.placeholder,
//       isRequired: field.isRequired,
//       value: fieldValue,
//       onChange: value =>
//         handleFieldChange(field.fieldName, value, pageName, pageIndex),
//       onChangeText: text =>
//         handleFieldChange(field.fieldName, text, pageName, pageIndex),
//     };

//     switch (field.fieldType) {
//       case 'Text':
//         return <InputGroup {...commonProps} />;
//       case 'Number':
//         return <NumberInputGroup {...commonProps} />;
//       case 'Checkbox':
//         return (
//           <CheckboxGroup {...commonProps} onChange={commonProps.onChange} />
//         );
//       case 'TextArea':
//         return <DescriptionInput {...commonProps} />;
//       case 'Page':
//         if (field.fieldName === 'attributes') {
//           // Renders the entire VariantUI block (sections + fields) here
//           // We assume VariantUI structure also follows pages/sections/fields
//           return VariantUI?.sections ? (
//             <View key={field.id} style={styles.variantAttributesBlock}>
//               <Text style={styles.variantBlockTitle}>
//                 {VariantUI.title || field.label}
//               </Text>

//               {VariantUI.sections.map(section => (
//                 <View key={section.id} style={styles.sectionContainer}>
//                   <Text style={styles.sectionTitle}>{section.title}</Text>
//                   {/* Fields within the VariantUI section are rendered here */}
//                   {section.fields
//                     .sort((a, b) => a.displayOrder - b.displayOrder) // Ensure dynamic attributes are sorted
//                     .map(
//                       attributeField =>
//                         attributeField.isVisible !== false &&
//                         // IMPORTANT: Pass the context of the main variant page instance
//                         renderField(attributeField, pageName, pageIndex),
//                     )}
//                 </View>
//               ))}
//             </View>
//           ) : (
//             <Text style={styles.loadingText}>
//               Select a Category to load dynamic attributes...
//             </Text>
//           );
//         }
//         return null;

//       case 'Select':
//         // --- Data Mapping (For the initial parent category dropdown) ---
//         const rawCategoryItems = getCategory?.items ?? [];
//         const mappedCategoryOptions = rawCategoryItems
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- Handler to Fetch Children and Update State ---
//         const handleCategorySelect = async selectedId => {
//           // 1. Update the form state for the currently selected dropdown (Category ID)
//           // Use the commonProps.onChange, which already includes the variant context if applicable
//           commonProps.onChange(selectedId);

//           try {
//             // 2. Fetch the child data (Subcategories)
//             const response = await fetchChildCategories(
//               'Category',
//               selectedId,
//               'parentId', // Query key is 'parentId'
//             );

//             // 3. Fetch Variant UI data (Assuming 'categoryId' is the key here)
//             const categoryData = await fetchChildCategories(
//               'Products/variant-page-with-attributes',
//               selectedId, // Use the actual selectedId here
//               'categoryId',
//             );
//             setVariantUI(categoryData?.data);

//             const subcategoryItems = response?.data?.items ?? [];
//             setSubcategories(subcategoryItems);
//           } catch (error) {
//             console.error('Failed to fetch data:', error);
//             setSubcategories([]);
//           }
//         };

//         // --- Subcategory Options Mapping ---
//         const mappedSubcategoryOptions = subcategories
//           .filter(item => item && item.id && item.name)
//           .map(item => ({
//             value: String(item.id),
//             label: item.name,
//           }));

//         // --- RENDERING LOGIC ---
//         if (field?.fieldName === 'category_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedCategoryOptions}
//               onSelect={handleCategorySelect} // Triggers fetch
//               onChangeText={() => {}}
//             />
//           );
//         } else if (field?.fieldName === 'subcategory_id') {
//           return (
//             <DropdownGroup
//               {...commonProps}
//               options={mappedSubcategoryOptions}
//               onSelect={commonProps.onChange}
//               onChangeText={() => {}}
//             />
//           );
//         }

//         // For all other 'Select' fields
//         return (
//           <DropdownGroup
//             {...commonProps}
//             options={field.options ?? []}
//             onSelect={commonProps.onChange}
//             onChangeText={() => {}}
//           />
//         );

//       case 'File':
//         return (
//           <ProductImagePicker
//             {...commonProps}
//             key={field.id}
//             images={formData[field.fieldName] || []}
//             setImages={commonProps.onChange}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // --- 4. SUBMISSION HANDLER ---
//   const handleSubmit = async () => {
//     // 1. Transform the formData into the API's required structure
//     const submissionData = transformFormDataForSubmission(
//       formData,
//       getAllProductModal?.pages,
//     );
//     // 2. Create a FormData object (required for multipart/form-data)

//     const formPayload = new FormData();

//     // Append all key-value pairs to FormData
//     for (const key in submissionData) {
//       if (Object.prototype.hasOwnProperty.call(submissionData, key)) {
//         const value = submissionData[key];

//         // IMPORTANT: For React Native FormData, simple strings are appended directly.
//         // File handling needs to be done here if you use the 'File' field type.
//         // File field logic for RN is complex (blob/uri) and is omitted here for brevity
//         // but this logic correctly appends all text/number/boolean data.
//         formPayload.append(key, value);
//       }
//     }

//     // 3. Log the payload (for debugging) and submit
//     console.log('Final Submission Payload (Object):', formPayload);

//     try {
//       // API call goes here: e.g., await submitProductData(formPayload);
//       Alert.alert('Success', 'Product submitted successfully!');
//     } catch (error) {
//       console.error('Submission failed:', error);
//       Alert.alert('Error', 'Failed to submit product data.');
//     }
//   };

//   return (
//     <ScrollView contentContainerStyle={styles.contentContainer}>
//       <Header title={'Add New Product'} onBackPress={true} />
//       {/* <Loader visible={isLoadinAllModal || isSubmitting} /> */}

//       {/* 2. RENDERING: Map over the non-variant pages */}
//       {nonVariantPages.map(page => (
//         <View key={page.pageId}>
//           <View style={styles.headerContainer}>
//             <Text style={styles.pageTitle}>{page.title}</Text>
//           </View>

//           {/* Sections are already sorted by 'order' in useMemo */}
//           {page.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>
//               {section.description && (
//                 <Text style={styles.sectionDescription}>
//                   {section.description}
//                 </Text>
//               )}

//               {/* Fields are already sorted by 'displayOrder' in useMemo */}
//               {section.fields.map(
//                 field => field.isVisible !== false && renderField(field),
//               )}
//             </View>
//           ))}
//         </View>
//       ))}

//       {/* 3. RENDERING: Dynamic Variant Pages (The page that can be cloned) */}
//       {variantPages.map((page, index) => {
//         const titleSuffix = index > 0 ? ` (Instance ${index + 1})` : '';
//         const isFirstInstance = index === 0;
//         return (
//           <View key={page.uniqueId} style={styles.variantPageWrapper}>
//             <View style={styles.headerContainer}>
//               <Text style={styles.pageTitle}>
//                 {page.title}
//                 {titleSuffix}
//               </Text>

//               {/* Conditional "Add New" button using isCollection=true logic */}
//               {isFirstInstance && page.isCollection === true && (
//                 <TouchableOpacity
//                   style={styles.addButton}
//                   onPress={handleAddNewVariantPage}>
//                   <Text style={styles.addButtonText}>+ Add New</Text>
//                 </TouchableOpacity>
//               )}
//             </View>

//             {/* Sections are already sorted by 'order' in useMemo */}
//             {page.sections.map(section => (
//               <View key={section.id} style={styles.sectionContainer}>
//                 <Text style={styles.sectionTitle}>{section.title}</Text>
//                 {section.description && (
//                   <Text style={styles.sectionDescription}>
//                     {section.description}
//                   </Text>
//                 )}

//                 {/* Fields are already sorted by 'displayOrder' in useMemo */}
//                 {section.fields.map(
//                   field =>
//                     field.isVisible !== false &&
//                     renderField(field, page.pageName, index),
//                 )}
//               </View>
//             ))}
//           </View>
//         );
//       })}

//       <TouchableOpacity
//         style={[
//           styles.submitButton,
//           isSubmitting && styles.submitButtonDisabled,
//         ]}
//         onPress={handleSubmit}
//         disabled={isSubmitting}>
//         <Text style={styles.submitButtonText}>
//           {isSubmitting ? 'Loading...' : 'SAVE PRODUCT'}
//         </Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// export default AddNewProduct;

// // =========================================================================
// // STYLES
// // =========================================================================
// const styles = StyleSheet.create({
//   contentContainer: {
//     padding: 20,
//     backgroundColor: '#fff',
//     minHeight: '100%',
//   },
//   variantPageWrapper: {
//     marginBottom: 30, // Space between dynamically added pages
//   },
//   headerContainer: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: 15,
//   },
//   addButtonText: {
//     color: '#FFFFFF',
//     fontSize: 14,
//     fontWeight: '600',
//   },
//   addButton: {
//     backgroundColor: '#F89941',
//     borderRadius: 5,
//     width: 100, // Slightly wider to fit "Add New Variant"
//     height: 40,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   pageTitle: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     marginTop: 10,
//     paddingBottom: 5,
//     color: '#333',
//   },
//   sectionContainer: {
//     marginBottom: 25,
//     paddingBottom: 15,
//     borderBottomWidth: StyleSheet.hairlineWidth,
//     borderBottomColor: '#ccc',
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '700',
//     color: '#333',
//     marginBottom: 4,
//   },
//   sectionDescription: {
//     fontSize: 14,
//     color: '#888',
//     marginBottom: 15,
//   },
//   submitButton: {
//     backgroundColor: '#F89941',
//     padding: 15,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 30,
//     marginBottom: 50,
//   },
//   submitButtonDisabled: {
//     backgroundColor: '#FFA07A',
//     opacity: 0.7,
//   },
//   submitButtonText: {
//     color: '#FFFFFF',
//     fontSize: 16,
//     fontWeight: '700',
//   },
//   // Styles for Variant Attributes Block
//   variantAttributesBlock: {
//     marginTop: 20,
//     padding: 15,
//     borderRadius: 8,
//     backgroundColor: '#F9FAFB', // Light gray background
//     borderWidth: 1,
//     borderColor: '#E0E0E0',
//   },
//   variantBlockTitle: {
//     fontSize: 18,
//     fontWeight: '800',
//     color: '#333',
//     marginBottom: 15,
//   },
//   loadingText: {
//     fontSize: 14,
//     color: '#999',
//     padding: 10,
//     backgroundColor: '#f0f0f0',
//     borderRadius: 5,
//     textAlign: 'center',
//   },
// });
