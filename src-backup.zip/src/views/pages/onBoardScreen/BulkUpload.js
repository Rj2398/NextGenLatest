import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Platform,
    ScrollView,
    Image,
    ProgressBarAndroid, // For Android progress bar
} from 'react-native';

// REQUIRED IMPORTS for Icons
import Ionicons from 'react-native-vector-icons/Ionicons';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import AntDesign from 'react-native-vector-icons/AntDesign'; // For Upload icon


// --- Centralized Color Palette ---
const Colors = {
    // Primary & CTA Colors
    primaryOrange: '#F89941', 
    lightOrangeBg: '#FF8719', 
    
    // Text Colors
    darkText: '#161B25', 
    mediumText: '#AEAEAE',
    lightText: '#B1B1B1',
    labelGray: '#858D9D', 
    errorRed: '#dc3545',
    uploadLink: '#F89941', // Orange-ish link color
    black:'#000000',
    
    // Backgrounds & Borders
    white: '#fff',
    lightBg: '#f5f5f5',
    borderColor: '#ddd',
    
    // Upload Colors
    uploadBorder: '#E6E6E6', // Light orange border for drag/drop area
    uploadBg: '#fff',
};

// Dummy data for the currently uploading file
const initialFile = {
    fileName: 'Orders July 2025',
    sizeMB: 2,
    totalMB: 12,
    progress: 0.15, // 15% uploaded
    isUploading: true,
};


// --- Reusable Component for the File Upload Area ---
const FileUploadArea = ({ onUploadPress }) => {
    return (
        <TouchableOpacity style={bulkStyles.uploadBox} onPress={onUploadPress}>
            {/* <AntDesign name="cloudupload" size={40} color={Colors.primaryOrange} /> */}
            <Image
         source={require('../../../assets/upload_bulk.png')}
         style={{ width: 40, height: 40 }}
         resizeMode="contain"
       />
        <Text style={{ fontSize: 12, color: Colors.darkText }}>
                {'Upload Files'}
            </Text>
            <Text style={bulkStyles.uploadText}>
                <Text style={bulkStyles.uploadLinkText}>Click to upload</Text> 
                {' or drag and drop CSV files to upload'}
            </Text>
            <Text style={bulkStyles.uploadLimit}>
                {'Max size Limit: 50 MB, Single File only'}
            </Text>
        </TouchableOpacity>
    );
};

// --- Reusable Component for File Progress/Status ---
const FileProgressItem = ({ file, onRemove }) => {
    // Calculate progress as a ratio (0.0 to 1.0)
    const progressRatio = file.sizeMB / file.totalMB;
    
    return (
        <View style={bulkStyles.fileItemContainer}>
            {/* <MaterialCommunityIcons name="file-document-outline" size={30} color="#4CAF50" /> */}
            <Image
         source={require('../../../assets/csv_icon.png')}
         style={{ width: 37, height: 37 }}
         resizeMode="contain"
              />
            <View style={bulkStyles.fileInfo}>
                <Text style={bulkStyles.fileName}>{file.fileName}</Text>
                {/* Status/Size Text */}
                <View style={bulkStyles.fileStatusRow}>
                    <Text style={bulkStyles.fileSizeText}>
                        {`${file.sizeMB} MB of ${file.totalMB} MB`}
                    </Text>
                    {file.isUploading && (
                         <Text style={bulkStyles.fileStatusText}>
                            Uploading...
                        </Text>
                    )}
                </View>
                {/* Progress Bar (Platform specific) */}
                <View style={bulkStyles.progressBarContainer}>
                    {Platform.OS === 'ios' ? (
                        <View style={bulkStyles.iosProgressTrack}>
                            <View style={[bulkStyles.iosProgressFill, { width: `${progressRatio * 100}%` }]} />
                        </View>
                    ) : (
                        <ProgressBarAndroid
                            style={bulkStyles.androidProgressBar}
                            styleAttr="Horizontal"
                            indeterminate={false}
                            progress={progressRatio}
                            color={Colors.primaryOrange}
                        />
                    )}
                </View>
                
                
            </View>
            
            {/* Remove/Cancel Button */}
            <TouchableOpacity onPress={onRemove}>
            <Image
         source={require('../../../assets/upload_cross.png')}
         style={{ width: 7, height: 7,marginBottom:45 }}
         resizeMode="contain"
       />
            </TouchableOpacity>
        </View>
    );
};


// --- Main Component: BulkUpload ---
const BulkUpload = () => {
    const [uploadedFile, setUploadedFile] = useState(initialFile);
    
    const handleUploadPress= async () => {
        try {
            // DocumentPicker.pick({ ... })
            const result = await DocumentPicker.pick({
                type: [types.csv, types.plainText], 
                allowMultiSelection: false, 
            });

            const file = result[0];
            
            console.log('Selected File:', file);
            
        
            setUploadedFile({
                fileName: file.name,
                sizeMB: (file.size / (1024 * 1024)).toFixed(2), // Byte to MB conversion
                totalMB: (file.size / (1024 * 1024)).toFixed(2), // Initial size is total size
                progress: 0.05, // Start progress
                isUploading: true,
                uri: file.uri,
            });

        } catch (err) {
            if (DocumentPicker.isCancel(err)) {
                // User cancelled the picker
                console.log('User cancelled file picker');
            } else {
                // Unknown error
                console.error('DocumentPicker Error:', err);
            }
        }
    };
    
    const handleRemoveFile = () => {
        console.log(`Removing file: ${uploadedFile.fileName}`);
        setUploadedFile(null);
    };
    
    const handleDownloadTemplate = () => {
        console.log('Downloading template...');
        // Logic to initiate file download
    };
    
    const handleCancel = () => {
        console.log('Bulk Upload Cancelled');
        // Logic to dismiss the screen
    };

    return (
        <View style={bulkStyles.container}>
            {/* --- App Header (Back and Title) --- */}
            <View style={bulkStyles.appHeader}>
                <Ionicons name="arrow-back" size={24} color={Colors.darkText} />
                <Text style={bulkStyles.screenTitle}>Bulk Upload</Text>
                {/* Placeholder for alignment */}
                <View style={{ width: 24 }} /> 
            </View>

            <ScrollView contentContainerStyle={bulkStyles.scrollViewContent} showsVerticalScrollIndicator={false}>
                <View style={bulkStyles.card}>
                    
                    {/* 1. Upload Area */}
                    <FileUploadArea onUploadPress={handleUploadPress} />

                    {/* 2. Uploading File Status */}
                    {uploadedFile && (
                        <FileProgressItem 
                            file={uploadedFile} 
                            onRemove={handleRemoveFile} 
                        />
                    )}

                </View>

                {/* 3. Action Buttons */}
                <View style={bulkStyles.buttonContainer}>
                    <TouchableOpacity style={bulkStyles.downloadButton} onPress={handleDownloadTemplate}>
                        <Feather name="download" size={20} color={Colors.white} style={{ marginRight: 8 }} />
                        {/* <Image
                        source={require('../../../assets/doc_icon.png')}
                        style={{ width: 20, height: 20 }}
                        resizeMode="contain"
                        /> */}
                        <Text style={bulkStyles.downloadButtonText}>Download Template</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={bulkStyles.cancelButton} onPress={handleCancel}>
                        <Text style={bulkStyles.cancelButtonText}>Cancel</Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    );
};

// --- Stylesheet for BulkUpload Component ---
const bulkStyles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.lightBg,
    },
    scrollViewContent: {
        paddingHorizontal: 20,
        paddingBottom: 40,
        paddingTop: 10,
    },

    // --- Header Styles ---
    appHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingTop: Platform.OS === 'android' ? 40 : 50, 
        paddingHorizontal: 20,
        paddingBottom: 15,
        backgroundColor: Colors.white,
        borderBottomWidth: 1,
        borderBottomColor: Colors.borderColor,
    },
    screenTitle: {
        fontSize: 18,
        fontWeight: '500',
        color: Colors.darkText,
    },

    // --- Card Styles ---
    card: {
        backgroundColor: Colors.white,
        borderRadius: 12,
        padding: 20,
        ...Platform.select({
            ios: {
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
            },
            android: {
                elevation: 3,
            },
        }),
    },
    
    // --- Upload Box Styles ---
    uploadBox: {
        borderWidth: 1,
        borderStyle: 'dashed',
        borderColor: Colors.uploadBorder,
        backgroundColor: Colors.uploadBg,
        borderRadius: 8,
        padding: 30,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 20,
    },
    uploadText: {
        fontSize: 14,
        color: Colors.mediumText,
        marginTop: 10,
        textAlign: 'center',
    },
    uploadLinkText: {
        color: Colors.uploadLink,
        fontWeight: '600',
    },
    uploadLimit: {
        fontSize: 12,
        color: Colors.lightText,
        marginTop: 5,
    },
    
    // --- File Item Styles ---
    fileItemContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.white,
        borderWidth: 1,
        borderColor: Colors.borderColor,
        borderRadius: 8,
        padding: 15,
        marginBottom: 10,
        justifyContent: 'space-between',
    },
    fileInfo: {
        flex: 1,
        marginLeft: 10,
        marginRight: 10,
    },
    fileName: {
        fontSize: 14,
        fontWeight: '500',
        color: Colors.black,
        marginBottom: 5,
    },
    fileStatusRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom:5,
    },
    fileSizeText: {
        fontSize: 12,
        color: Colors.mediumText,
    },
    fileStatusText: {
        fontSize: 12,
        fontWeight: '600',
        color: Colors.mediumText,
    },
    
    // Progress Bar Styles
    progressBarContainer: {
        height: 5,
        borderRadius: 2,
        overflow: 'hidden', // Required for iOS progress bar
    },
    // iOS custom progress bar styles
    iosProgressTrack: {
        backgroundColor: Colors.inactiveGray,
        height: '100%',
        borderRadius: 2,
    },
    iosProgressFill: {
        backgroundColor: Colors.primaryOrange,
        height: '100%',
        borderRadius: 2,
    },
    // Android progress bar style
    androidProgressBar: {
        height: 5,
    },

    // --- Button Styles ---
    buttonContainer: {
        marginTop: 30,
    },
    downloadButton: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.primaryOrange,
        paddingVertical: 14,
        borderRadius: 8,
        marginBottom: 15,
    },
    downloadButtonText: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.white,
    },
    cancelButton: {
        backgroundColor: Colors.white,
        paddingVertical: 14,
        borderRadius: 8,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.borderColor,
    },
    cancelButtonText: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.mediumText,
    },
});

export default BulkUpload;