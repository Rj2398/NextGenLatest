import React ,{useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Platform,
  Image,
  Modal, // 🟢 Added Modal for the Filter Window
} from 'react-native';
// 🟢 REQUIRED IMPORTS for Icons (Assuming react-native-vector-icons is used)
import Ionicons from 'react-native-vector-icons/Ionicons';
import Feather from 'react-native-vector-icons/Feather';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';


// --- Centralized Color Palette ---
const Colors = {
  // Primary & CTA Colors
  primaryOrange: '#ff9933', 
  lightOrangeBg: '#fbe2c8', 
  
  // Text Colors
  darkText: '#3D3A3A',
  mediumText: '#555',
  lightText: '#999',
  
  // Backgrounds & Borders
  white: '#fff',           
  lightBg: '#f5f5f5',  
  borderColor: '#ddd',
  
  // Status Colors
  activeGreen: '#4CAF50', // Used for Active Tag text/border
  activeBg: '#E8F5E9', // Pale background for Active tag 
  inactiveGray: '#eee', // Used for Inactive Tag background
  inputBorder: '#ccc', // Lighter border for inputs in the modal
};

// --- Reusable Component for Deal Card ---
const DealCard = ({ title, type, offer, validity, status, isChecked }) => {
    // Determine status colors based on the design
    const statusBg = status === 'Active' ? Colors.activeBg : Colors.inactiveGray; // Pale green/Gray background
    const statusColor = status === 'Active' ? Colors.activeGreen : Colors.darkText; // Darker text/Active green text

    // Define the style for the active checkbox background (Orange if checked, White if not)
    const checkboxBg = isChecked ? Colors.primaryOrange : Colors.white;

    // State to control the visibility of the action menu
    const [isMenuVisible, setIsMenuVisible] = useState(false);

    // Action handler (placeholder)
    const handleAction = (action) => {
        console.log(`Action selected: ${action} for deal: ${title}`);
        // Close the menu after action
        setIsMenuVisible(false); 
        // Implement actual navigation/API call here
    }; 

    // --- Action Menu Component ---
    const ActionMenu = () => (
        <View style={styles.actionMenu}>
            <TouchableOpacity style={styles.menuItem} onPress={() => handleAction('Edit')}>
                <Text style={styles.menuText}>Edit</Text>
            </TouchableOpacity>
            <View style={styles.menuDivider} />
            <TouchableOpacity style={styles.menuItem} onPress={() => handleAction('Assign Product')}>
                <Text style={styles.menuText}>Assign Product</Text>
            </TouchableOpacity>
            <View style={styles.menuDivider} />
            <TouchableOpacity style={styles.menuItem} onPress={() => handleAction('Delete')}>
                <Text style={[styles.menuText, styles.deleteText]}>Delete</Text>
            </TouchableOpacity>
        </View>
    );

    return (
      <View style={[styles.card, {position: 'relative'}]}> {/* Added position: 'relative' for the absolute menu */}
        <View style={styles.cardHeader}>
          <Text style={styles.dealTitle}>{title}</Text>
          {/* --- More Options / Settings Icon --- */}
                <TouchableOpacity onPress={() => setIsMenuVisible(!isMenuVisible)}>
                    <Feather name="more-vertical" size={24} color={Colors.mediumText} />
                </TouchableOpacity>

                {/* Render Menu only if visible */}
                {isMenuVisible && <ActionMenu />}
        </View>

        <Text style={styles.dealType}>{type}</Text>

        {/* Offer and Min/Max Row */}
        <View style={styles.offerRow}>
          <View style={styles.offerBadge}>
            <Text style={styles.offerText}>{offer}</Text>
          </View>
          <Text style={styles.offerDetailsText}>
            {/* Display minimum detail only if the deal is Active */}
            {status === 'Active' ? 'Min: 1 PC/Product/Item' : ''}
          </Text>
        </View>
        
        {/* Validity and Checkbox Row */}
        <View style={styles.statusRow}>
          
          {/* 1. Validity Container (Two-line structure) */}
          <View style={styles.validityContainerNew}>
            
            {/* 🟢 TOP ROW: Validity Label and Status Badge (Horizontal) */}
            <View style={styles.validityHeaderRow}>
                <Text style={styles.validityLabel}>Validity</Text>
                
                {/* Status Badge right next to the Validity label */}
                <View style={[
                    styles.statusBadgeNew, 
                    { backgroundColor: statusBg }
                ]}>
                    <Text style={[styles.statusText, { color: statusColor }]}>
                        {status}
                    </Text>
                </View>
            </View>
            
            {/* 🟢 BOTTOM ROW: Date Text (Vertical) */}
            <Text style={styles.validityDateText}>{validity}</Text>
            
          </View>

          {/* 2. Checkbox Implementation (Aligned to bottom-right) */}
          <View style={[styles.checkboxNew, { backgroundColor: checkboxBg }]}>
            {/* Check icon is WHITE when checked, background is orange */}
            {isChecked && <AntDesign name="check" size={16} color={Colors.white} />}
          </View>
        </View>
      </View>
    );
  };


// --- Filter Modal Component ---
const FilterModal = ({ isVisible, onClose, onApply, onReset }) => {
    return (
        <Modal
            animationType="fade"
            transparent={true}
            visible={isVisible}
            onRequestClose={onClose}
        >
            <View style={styles.modalOverlay}>
                <View style={styles.modalContent}>
                    
                    {/* Header */}
                    <View style={styles.modalHeader}>
                        <Text style={styles.modalTitle}>Filters</Text>
                        <TouchableOpacity onPress={onReset}>
                            <Text style={styles.resetText}>Reset all</Text>
                        </TouchableOpacity>
                    </View>

                    <ScrollView showsVerticalScrollIndicator={false}>
                        
                        {/* Category Filter */}
                        <Text style={styles.filterSectionTitle}>Category</Text>
                        <View style={styles.filterInputContainer}>
                            <Text style={styles.filterPlaceholderText}>All Categories</Text>
                            <Feather name="chevron-down" size={20} color={Colors.darkText} />
                        </View>
                        
                        {/* Suppliers Filter */}
                        <Text style={styles.filterSectionTitle}>Suppliers</Text>
                        <View style={styles.filterInputContainer}>
                            <Text style={styles.filterPlaceholderText}>Suppliers</Text>
                            <Feather name="chevron-down" size={20} color={Colors.darkText} />
                        </View>

                        {/* Price Row */}
                        <View style={styles.priceRow}>
                            <View style={{ flex: 1, marginRight: 10 }}>
                                <Text style={styles.filterSectionTitle}>Min. Price</Text>
                                <View style={styles.filterInputContainer}>
                                    <Text style={styles.filterPlaceholderText}>Min. Price</Text>
                                    <Feather name="chevron-down" size={20} color={Colors.darkText} />
                                </View>
                            </View>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.filterSectionTitle}>Max. Price</Text>
                                <View style={styles.filterInputContainer}>
                                    <Text style={styles.filterPlaceholderText}>Max. Price</Text>
                                    <Feather name="chevron-down" size={20} color={Colors.darkText} />
                                </View>
                            </View>
                        </View>
                        
                        {/* Date Filter */}
                        <Text style={styles.filterSectionTitle}>Select Date</Text>
                        <View style={styles.filterInputContainer}>
                            <Text style={styles.filterPlaceholderText}>Select Date</Text>
                            <Feather name="chevron-down" size={20} color={Colors.darkText} />
                        </View>
                        {/* Extra space to push the Apply button up */}
                        <View style={{ height: 100 }} /> 
                    </ScrollView>

                    {/* Apply Button (Positioned at the bottom) */}
                    <TouchableOpacity style={styles.applyButton} onPress={onApply}>
                        <Text style={styles.applyButtonText}>Apply Filters</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </Modal>
    );
};
  
  
  // --- Main Deals and Discount Screen ---
  const DealsDiscountScreen = () => {
    const [isFilterVisible, setIsFilterVisible] = useState(false); // 🟢 State for Filter Modal visibility

    // Sample Data (data representing the list items)
    const dealsData = [
      { title: 'Summer Sale', type: 'Percentage Discount', offer: '20% OFF', validity: 'From: Jan 1, 2025 - To Jan 31, 2025', status: 'Active', isChecked: true },
      { title: 'Fall Sale', type: 'Amount Discount', offer: '10 INR OFF', validity: 'From: Feb 1, 2025 - To Jan 7, 2025', status: 'Inactive', isChecked: false },
      { title: 'Winter Discount', type: 'Bogo discount', offer: '50% OFF', validity: 'From: Feb 1, 2025 - To Jan 7, 2025', status: 'Inactive', isChecked: false },
    ];

    const handleApplyFilters = () => {
        // Implement filter application logic here
        setIsFilterVisible(false);
    };

    const handleResetFilters = () => {
        // Implement filter reset logic here
        console.log("Filters Reset!");
    };
      const navigation = useNavigation();
    return (
      <View style={styles.container}>
        {/* --- App Header (Back, Title, Menu) --- */}
        <View style={styles.appHeader}>
          <Ionicons name="arrow-back" size={24} color={Colors.darkText} />
          <Text style={styles.screenTitle}>Deals</Text>
          <Feather name="menu" size={24} color={Colors.darkText} />
        </View>
  
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          
          {/* --- Search and Filter Row --- */}
          <View style={styles.searchRow}>
            <View style={styles.searchBox}>
              <Feather name="search" size={20} color={Colors.lightText} />
              <TextInput 
                placeholder="Search Deals"
                placeholderTextColor={Colors.lightText}
                style={styles.searchInput}
              />
            </View>
            {/* 🟢 Filter Button opens the Modal */}
            <TouchableOpacity style={styles.filterButton} onPress={() => setIsFilterVisible(true)}>
              <Feather name="filter" size={24} color={Colors.darkText} />
            </TouchableOpacity>
          </View>
  
          {/* --- Section Title and CTA Button --- */}
          <View style={styles.sectionHeader}>
            {/* Placeholder for the image icon */}
            <Image
         source={require('../../../assets/cuppons_icon.png')}
         style={styles.searchImage}
         resizeMode="contain"
       />
            <Text style={styles.sectionTitle}>Deals & Discount</Text>
          </View>
              <TouchableOpacity
            style={styles.createButton}
            onPress={() => navigation.navigate('CreateDeal')}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Image
            source={require('../../../assets/discount_icon.png')}
            style={{ width: 20, height: 20, marginRight: 8 }}
            resizeMode="contain"
            />
            <Text style={styles.createButtonText}>Create Deals</Text>
            </View>
            </TouchableOpacity>
  
          {/* --- Deals List --- */}
          <View style={styles.dealsList}>
            {dealsData.map((deal, index) => (
              <DealCard 
                key={index} 
                {...deal} 
              />
            ))}
          </View>
  
        </ScrollView>
        
        {/* 🟢 Filter Modal Implementation */}
        {/* <FilterModal
            isVisible={isFilterVisible}
            onClose={() => setIsFilterVisible(false)}
            onApply={handleApplyFilters}
            onReset={handleResetFilters}
        /> */}
      </View>
    );
  };
  
  
  // --- Stylesheet ---
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: Colors.lightBg,
    },
    scrollView: {
      paddingHorizontal: 20,
    },
  
    // --- Header Styles ---
    appHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingTop: Platform.OS === 'android' ? 40 : 50, // Safe area padding
      paddingHorizontal: 20,
      paddingBottom: 15,
      backgroundColor: Colors.white,
      borderBottomWidth: 1,
      borderBottomColor: Colors.borderColor,
    },
    screenTitle: {
      fontSize: 18,
      fontWeight: '500',
      color: Colors.darkText,
    },
  
    // --- Search Row Styles ---
    searchRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 15,
      marginBottom: 15,
    },
    searchBox: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: Colors.white,
      borderRadius: 8,
      paddingHorizontal: 15,
      paddingVertical: Platform.OS === 'android' ? 5 : 10,
      marginRight: 10,
      borderWidth: 1,
      borderColor: Colors.borderColor,
    },
    searchInput: {
      flex: 1,
      marginLeft: 10,
      fontSize: 16,
      fontWeight: '400',
      color: Colors.darkText,
    },
    filterButton: {
      padding: 10,
      backgroundColor: Colors.white,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: Colors.borderColor,
    },
    searchImage: {
        width: 24, 
        height: 24,
    },
  
    // --- Section Title and CTA ---
    sectionHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: '700',
      color: '#000000',
      marginLeft: 8,
    },
    createButton: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: Colors.primaryOrange,
      paddingVertical: 12,
      borderRadius: 8,
      marginBottom: 20,
    },
    createButtonText: {
      fontSize: 16,
      fontWeight: '600',
      color: Colors.white,
      marginLeft: 8,
    },
  
    // --- Deal Card Styles ---
    dealsList: {
      paddingBottom: 30, // Extra space at the bottom of the list
    },
    card: {
      position: 'relative', // IMPORTANT for actionMenu
      backgroundColor: Colors.white,
      borderRadius: 12,
      padding: 15,
      marginBottom: 15,
      // Unified shadow for iOS and Android
      ...Platform.select({
        ios: {
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
        },
        android: {
          elevation: 3,
        },
      }),
    },
    cardHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 5,
    },
    dealTitle: {
      fontSize: 18,
      fontWeight: '700',
      color: Colors.darkText,
    },
    dealType: {
      fontSize: 14,
      color: Colors.mediumText,
      marginBottom: 10,
    },
    offerRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
    },
    offerBadge: {
      backgroundColor: Colors.lightOrangeBg,
      borderRadius: 4,
      paddingHorizontal: 6,
      paddingVertical: 3,
      marginRight: 10,
    },
    offerText: {
      fontSize: 14,
      fontWeight: '700',
      color: Colors.primaryOrange,
    },
    offerDetailsText: {
      fontSize: 12,
      color: Colors.mediumText,
    },
    
    // --- Deal Card Menu Styles ---
    actionMenu: {
        position: 'absolute',
        top: 35,
        right: 15,
        zIndex: 10,
        width: 150,
        backgroundColor: Colors.white,
        borderRadius: 8,
        paddingVertical: 5,
        ...Platform.select({
            ios: {
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.15,
                shadowRadius: 5,
            },
            android: {
                elevation: 6,
            },
        }),
    },
    menuItem: {
        paddingVertical: 10,
        paddingHorizontal: 15,
    },
    menuText: {
        fontSize: 14,
        color: Colors.darkText,
    },
    deleteText: {
        color: 'red',
        fontWeight: '600',
    },
    menuDivider: {
        height: 1,
        backgroundColor: Colors.borderColor,
        marginHorizontal: 10,
    },
    
    // *** CORRECTED VALIDITY/CHECKBOX STYLES ***
    statusRow: {
        // Main row holding the validity block (left) and checkbox (right)
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-end', // Aligns items to the bottom, pushing checkbox to the corner
        marginTop: 10,
        borderTopWidth: 1,
        borderTopColor: Colors.borderColor,
        paddingTop: 10,
    },
    validityContainerNew: {
        flex: 1, // Allows it to take the necessary space
        flexDirection: 'column', // Stacks the header row and date text
    },
    validityHeaderRow: {
        flexDirection: 'row', // KEY: Puts Validity label and Active tag horizontally
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginBottom: 8, // Space between header row and date text
    },
    validityLabel: {
        fontSize: 14,
        fontWeight: '500',
        color: Colors.darkText, // Changed to dark text for better visibility
        marginRight: 10, // Space between 'Validity' and the Status Badge
    },
    validityDateText: {
        fontSize: 14,
        fontWeight: '500',
        color: Colors.darkText,
    },
    statusBadgeNew: {
        borderRadius: 4, // More square look for the tag
        paddingVertical: 6,
        // Background color is handled in the component logic (pale green/gray)
    },
    statusText: {
        fontSize: 12,
        fontWeight: '600',
    },
    checkboxNew: {
        width: 24,
        height: 24,
        borderRadius: 4,
        borderWidth: 1,
        borderColor: Colors.primaryOrange, // Border is always orange
        justifyContent: 'center',
        alignItems: 'center',
    },
    
    // --- MODAL (Filter Window) STYLES ---
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        alignItems: 'flex-end', // Aligns modal to the right (common for filters)
        justifyContent: 'flex-start', // Starts from the top
    },
    modalContent: {
        width: '85%', // Width of the modal window
        height: '100%', // Full height
        backgroundColor: Colors.white,
        padding: 20,
        paddingTop: Platform.OS === 'android' ? 40 : 50,
    },
    modalHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
    },
    modalTitle: {
        fontSize: 20,
        fontWeight: '700',
        color: Colors.darkText,
    },
    resetText: {
        fontSize: 14,
        color: Colors.mediumText,
        fontWeight: '500',
    },
    filterSectionTitle: {
        fontSize: 14,
        color: Colors.darkText, // Changed to darkText for section title
        fontWeight: '500',
        marginBottom: 8,
        marginTop: 18,
    },
    filterInputContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.borderColor,
        borderRadius: 8,
        paddingHorizontal: 15,
        paddingVertical: 12,
        backgroundColor: Colors.white,
    },
    filterPlaceholderText: {
        fontSize: 14,
        color: Colors.mediumText, // Placeholder text color
    },
    priceRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    applyButton: {
        backgroundColor: Colors.primaryOrange,
        paddingVertical: 15,
        borderRadius: 8,
        alignItems: 'center',
        // Pushes the button to the bottom using position: 'absolute'
        position: 'absolute',
        bottom: 0,
        left: 20,
        right: 20,
        marginBottom: Platform.OS === 'android' ? 20 : 40,
    },
    applyButtonText: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.white,
    },
  });
  
  export default DealsDiscountScreen;