import React, { useState, useMemo, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Platform,
    ScrollView,
    ActivityIndicator,
    Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import useDealForm from '../../../hooks/useDealForm';


// --- Centralized Color Palette ---
const Colors = {
    primaryOrange: '#FF8719', 
    lightOrangeBg: '#fbe2c8', 
    darkText: '#3D3A3A', 
    mediumText: '#858D9D',
    labelGray: '#858D9D', 
    white: '#fff', 
    lightBg: '#f5f5f5', 
    borderColor: '#ddd',
    activeGreen: '#D1FAE5', 
    activeGreenText: '#2B947D', 
    offerHighlight: '#FEEAD7', 
    title:'#161B25',
    black:'#000000',
    inactiveGray: '#eee',
};

// --- Reusable Component for Variant Selector (Adjusted for MultiSelect) ---
const VariantSelector = ({ label, selectedVariants, onPress }) => {
    return (
        <View style={assignStyles.inputContainer}>
            <Text style={assignStyles.label}>{label}</Text>
            <TouchableOpacity style={assignStyles.variantDropdownContainer} onPress={onPress}>
                <View style={assignStyles.variantTagsWrapper}>
                    {selectedVariants.length > 0 ? selectedVariants.map((variant, index) => (
                        <View key={index} style={assignStyles.variantTag}>
                            <Text style={assignStyles.variantTagText}>{variant.text}</Text>
                            <Feather name="x" size={14} color="#48505E" style={{marginLeft: 4}} />
                        </View>
                    )) : (
                        <Text style={[assignStyles.dropdownText, {color: Colors.mediumText}]}>Select Products (MultiSelect)</Text>
                    )}
                </View>
                <Feather name="chevron-down" size={20} color={Colors.mediumText} />
            </TouchableOpacity>
        </View>
    );
};


// --- Reusable Component for the Deal Summary Card ---
const DealSummaryCard = ({ dealName, discountType, offer, validity, status }) => {
    const getStatusStyle = useMemo(() => {
        const is_Active = status === 'Active';
        return {
            badge: {
                backgroundColor: is_Active ? Colors.activeGreen : Colors.inactiveGray,
                paddingHorizontal: 8,
                paddingVertical: 4,
                borderRadius: 6,
                alignSelf: 'flex-start',
                marginRight: 15,
            },
            text: {
                fontSize: 12,
                fontWeight: '600',
                color: is_Active ? Colors.activeGreenText : Colors.darkText,
            }
        };
    }, [status]);
    
    return (
        <View style={assignStyles.card}>
            <View style={assignStyles.cardHeader}>
                <View>
                    <Text style={assignStyles.dealName}>{dealName}</Text>
                    <Text style={assignStyles.discountType}>{discountType}</Text>
                </View>
                <TouchableOpacity>
                    <MaterialCommunityIcons name="dots-vertical" size={24} color={Colors.darkText} />
                </TouchableOpacity>
            </View>

            <View style={assignStyles.cardBody}>
                <Text style={assignStyles.discountType}>Offer</Text>
                <View style={assignStyles.offerTag}>
                    <Text style={assignStyles.offerText}>{offer}</Text>
                </View>
                
                <View style={assignStyles.validityRow}>
                    <View style={{ flex: 1 }}>
                        <Text style={assignStyles.validityLabel}>Validity</Text>
                        <Text style={assignStyles.validityDates}>{validity}</Text>
                    </View>

                    <View style={getStatusStyle.badge}>
                        <Text style={getStatusStyle.text}>{status}</Text>
                    </View>
                    
                    <MaterialCommunityIcons 
                        name="checkbox-marked" 
                        size={24} 
                        color={Colors.primaryOrange} 
                        style={{ marginLeft: 15 }}
                    />
                </View>
            </View>
        </View>
    );
};


// --- Main Component: AssignProducts ---
const AssignProducts = ({ route }) => { 
    const navigation = useNavigation();
    const { dealFormData, isLoading: isLoadingFormSchema, createNewDeal, getPageData } = useDealForm();

    const { dealDetails } = route.params || {};

    // 1. Dynamic Data Extraction using the utility function
    const productPageData = useMemo(() => {
        // We look for 'Deal_ProductAssignment' page and 'ProductSelection' section
        return getPageData(dealFormData, 'Deal_ProductAssignment', 'ProductSelection');
    }, [dealFormData, getPageData]);
    
    // 2. Prepare data for Summary Card 
    const dealName = dealDetails?.deal_name || 'New Deal';
    const discountValue = dealDetails?.discount_value || '0';
    const rawDiscountType = dealDetails?.discount_type === 'percentage' ? '%' : (dealDetails?.currency_code || 'Flat');
    const displayDiscountType = dealDetails?.discount_type === 'percentage' ? 'Percentage Discount' : 'Fixed Discount';

    const offer = `${discountValue} ${rawDiscountType} OFF`;
    const validity = `From: ${dealDetails?.start_date || 'N/A'} - To ${dealDetails?.end_date || 'N/A'}`;
    const status = dealDetails?.is_active ? 'Active' : 'Inactive';
    
    // 3. Local State initialization based on API schema
    const initialState = useMemo(() => {
        return productPageData.fields.reduce((acc, field) => {
            // Initialize MultiSelect field (selected_products) as an empty array
            acc[field.fieldName] = field.fieldType === 'MultiSelect' ? [] : (field.defaultValue !== null ? String(field.defaultValue) : '');
            return acc;
        }, {});
    }, [productPageData.fields]);

    const [formData, setFormData] = useState(initialState);
    
    // Mock state for MultiSelect/Variant assignment.
    const [selectedVariants, setSelectedVariants] = useState([
        { id: 'prod-123', text: 'T-Shirt (SKU: 101)' },
        { id: 'prod-456', text: 'Cap (SKU: 202)' },
    ]);

    useEffect(() => { 
        if (Object.keys(initialState).length > 0) {
            setFormData(initialState);
        }
    }, [initialState]);

    const handleChange = (fieldName, value) => setFormData(prev => ({ ...prev, [fieldName]: value }));

    // 4. Action Handlers (Submitting the form data)
    const handleActionClick = async (action) => {
        if (!action) return;

        // Handle navigation actions (like 'Back' or 'Cancel')
        if (action.buttonId === 'btn_cancel' || action.buttonId === 'btn_back' || action.method === 'GET' || action.method === 'NONE') {
            navigation.goBack();
            return;
        }

        // Handle submission actions (like 'Save as Draft' or 'Create Deal')
        if (action.apiCallRequired && action.method === 'POST' && action.endpoint) {
            
            // --- Define Field Mappings and Exclusions for the API Payload ---
            // Maps internal snake_case keys (like deal_name) to external API CamelCase keys (like dealName)
            const API_FIELD_MAPPING = {
                deal_name: 'dealName',
                deal_description: 'dealDescription',
                discount_type: 'discountType',
                discount_value: 'discountValue',
                currency_code: 'currencyCode',
                start_date: 'startDate',
                end_date: 'endDate',
                is_active: 'isActive',
                selected_products: 'productIds', // Custom mapping for products
            };
            // 'action_button' is explicitly excluded from the 'fields' array as requested.
            const EXCLUDED_FIELDS = ['action_button']; 
            // ----------------------------------------------------------------
            
            // 1. Combine all deal data (Basic Info + Product Assignment)
            const combinedData = {
                ...dealDetails, 
                // Convert array of selected variant objects to an array of IDs for API payload
                selected_products: selectedVariants.map(v => v.id), 
                // Add the fields from the current form (though only selected_products is active here)
                ...formData, 
                action_button: action.buttonId // Send which button was clicked (will be excluded from fields array below)
            };
            
            // 2. Map combined data to the required fields[n].fieldName/value format
            const fieldData = [];
            
            for (const key in combinedData) {
                if (Object.hasOwnProperty.call(combinedData, key)) {
                    
                    // Skip the explicitly excluded fields (e.g., action_button) as requested by the user
                    if (EXCLUDED_FIELDS.includes(key)) {
                        continue;
                    }
                    
                    let value = combinedData[key];

                    // a) Map internal key (snake_case) to external API key (CamelCase or productIds)
                    let apiFieldName = API_FIELD_MAPPING[key] || key;
                    
                    // b) Handle Arrays (like product IDs) -> convert array to comma-separated string
                    if (Array.isArray(value)) {
                        value = value.join(',');
                    }
                    
                    // c) Handle Booleans (true/false) -> convert to string 'true'/'false'
                    if (typeof value === 'boolean') {
                        value = value ? 'true' : 'false';
                    }

                    // d) Push to fieldData array if value is not null/undefined/empty string
                    if (value !== null && value !== undefined && String(value).length > 0) {
                         fieldData.push({
                             fieldName: apiFieldName,
                             value: String(value), // Must be a string for form-data
                         });
                    }
                }
            }
            
            // 3. Create the Final Payload object
            const payload = {
                pageName: "Deal_Creation", 
                fields: fieldData,          
            };
            
            // 4. Call the mutation using the dynamic endpoint from the button
            try {
                const result = await createNewDeal({
                    payload: payload, 
                    endpoint: action.endpoint // <--- Use the dynamic endpoint here!
                }); 
                
                Alert.alert("Success", result.message || `${action.label} successful.`);
                navigation.navigate('DealReview', {dealDetails: combinedData}); 
            } catch (error) {
                Alert.alert("Error", error.message || `Failed to perform ${action.label}. Please check the console.`);
                console.error("API Submission Error:", error);
            }
        } else {
             Alert.alert(action.label, `Action ${action.label} triggered. Endpoint: ${action.endpoint}`);
        }
    };
    

    // 5. Dynamic Field Renderer 
    const renderProductFields = () => {
        if (!productPageData.fields || productPageData.fields.length === 0) {
            return (
                <View style={assignStyles.infoBox}>
                    <Text style={assignStyles.infoText}>
                        <Ionicons name="alert-circle-outline" size={16} color={Colors.darkText} /> 
                        No product selection fields found in the 'ProductSelection' section.
                    </Text>
                </View>
            );
        }

        return productPageData.fields.map((field) => {
            const fieldLabel = field.localization?.localizedText || field.label;
            
            // Render MultiSelect field (which is the only expected field here)
            if (field.fieldName === 'selected_products' && field.fieldType === 'MultiSelect') {
                return (
                    <VariantSelector
                        key={field.fieldName}
                        label={fieldLabel}
                        selectedVariants={selectedVariants} // Using mock state for visualization
                        onPress={() => Alert.alert("Product Selector", "Opening product selection modal.")}
                    />
                );
            } 
            return null;
        });
    };

    // 6. Loading UI
    if (isLoadingFormSchema) {
        return (
            <View style={assignStyles.centerContainer}>
                <ActivityIndicator size="large" color={Colors.primaryOrange} />
                <Text style={assignStyles.loadingText}>Loading Product Assignment Form...</Text>
            </View>
        );
    }
    
    // --- 7. Find dynamic buttons (with robust fallbacks for Create Deal) ---
    
    // Default Create Deal action (used if API doesn't provide one)
    const defaultCreateDealAction = { 
        buttonId: 'btn_create_deal', 
        label: 'Create Deal', 
        type: 'primary', 
        apiCallRequired: true, 
        method: 'POST', 
        endpoint: '/api/v1/deal' // Default endpoint based on user's curl
    };
    
    // Find dynamic buttons
    const primaryAction = productPageData.actions.find(a => a.type === 'primary') || defaultCreateDealAction;
    const secondaryAction = productPageData.actions.find(a => a.buttonId === 'btn_save_draft') || { buttonId: 'btn_save_draft', label: 'Save Draft', type: 'secondary', apiCallRequired: true, method: 'POST', endpoint: '/api/v1/deal/draft' };
    const backAction = productPageData.actions.find(a => a.buttonId === 'btn_back') || { buttonId: 'btn_back', label: 'Back', type: 'secondary', method: 'GET' };


    return (
        <View style={assignStyles.container}>
            
            {/* --- App Header --- */}
            <View style={assignStyles.appHeader}>
                {/* Use backAction for the header back button */}
                <TouchableOpacity onPress={() => handleActionClick(backAction)}> 
                    <Ionicons name="arrow-back" size={24} color={Colors.darkText} />
                </TouchableOpacity>
                <Text style={assignStyles.screenTitle}>{productPageData.pageTitle}</Text>
                <View style={{ width: 24 }} /> 
            </View>

            <ScrollView contentContainerStyle={assignStyles.scrollViewContent} showsVerticalScrollIndicator={false}>
                
                {/* 1. Deal Summary Card */}
                <DealSummaryCard
                    dealName={dealName}
                    discountType={displayDiscountType}
                    offer={offer}
                    validity={validity}
                    status={status}
                />

                {/* 2. Product Selection Area (Dynamic Fields) */}
                <View style={assignStyles.selectionCard}>
                    <Text style={assignStyles.sectionTitle}>Product Selection</Text>
                    {renderProductFields()}
                </View>

                {/* 3. Action Buttons (Dynamically generated from API actions) */}
                <View style={assignStyles.buttonRow}>
                    
                    {/* Secondary/Back Button */}
                    <TouchableOpacity 
                        style={assignStyles.cancelButton} 
                        onPress={() => handleActionClick(backAction)}
                    >
                        <Text style={assignStyles.cancelButtonText}>{backAction.label}</Text>
                    </TouchableOpacity>
                    
                    {/* Save Draft Button (Middle) */}
                    <TouchableOpacity 
                        style={[assignStyles.cancelButton, {flex: 1.2, marginHorizontal: 10}]} 
                        onPress={() => handleActionClick(secondaryAction)}
                    >
                        <Text style={assignStyles.cancelButtonText}>{secondaryAction.label}</Text>
                    </TouchableOpacity>

                    {/* Primary/Create Deal Button (Always present due to fallback) */}
                    <TouchableOpacity 
                        style={[assignStyles.saveButton, {flex: 1.5, marginLeft: 0}]} 
                        onPress={() => handleActionClick(primaryAction)}
                    >
                        <Text style={assignStyles.saveButtonText}>{primaryAction.label}</Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </View>
    );
};

// --- Stylesheet ---
const assignStyles = StyleSheet.create({
    container: { flex: 1, backgroundColor: Colors.lightBg },
    centerContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.lightBg },
    loadingText: { marginTop: 10, fontSize: 16, color: Colors.darkText },
    scrollViewContent: { paddingHorizontal: 20, paddingBottom: 40, paddingTop: 10 },

    // Header Styles
    appHeader: { 
        flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', 
        paddingTop: Platform.OS === 'android' ? 40 : 50, paddingHorizontal: 20, paddingBottom: 15, 
        backgroundColor: Colors.white, borderBottomWidth: 1, borderBottomColor: Colors.borderColor, 
    },
    screenTitle: { fontSize: 18, fontWeight: '500', color: Colors.title },

    // Card Styles
    card: { 
        backgroundColor: Colors.white, borderRadius: 12, padding: 20, marginBottom: 15, 
        elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, 
    },
    selectionCard: { 
        backgroundColor: Colors.white, borderRadius: 12, padding: 20, 
        elevation: 3, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, 
    },
    sectionTitle: { fontSize: 16, fontWeight: '600', color: Colors.darkText, marginBottom: 15 },
    infoBox: {
        backgroundColor: Colors.lightOrangeBg,
        padding: 15,
        borderRadius: 8,
        marginVertical: 10,
    },
    infoText: {
        color: Colors.darkText,
        fontSize: 14,
        fontWeight: '500',
    },
    cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
    dealName: { fontSize: 18, fontWeight: '600', color: Colors.darkText },
    discountType: { fontSize: 14, color: Colors.mediumText, marginBottom: 10 },
    cardBody: { marginTop: 10 },
    offerTag: { 
        backgroundColor: Colors.offerHighlight, paddingHorizontal: 8, paddingVertical: 4, 
        borderRadius: 6, alignSelf: 'flex-start', marginBottom: 10, 
    },
    offerText: { fontSize: 14, fontWeight: '600', color: '#FF7A00' },
    validityRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    validityLabel: { fontSize: 12, color: Colors.mediumText },
    validityDates: { fontSize: 14, fontWeight: '500', color: '#5D6679', marginTop: 2 },
    
    // Variant/MultiSelect Selector Styles
    inputContainer: { marginBottom: 15 },
    label: { fontSize: 14, fontWeight: '500', color: Colors.labelGray, marginBottom: 5 },
    dropdownText: { fontSize: 16, color: Colors.black, fontWeight: '400' },
    variantDropdownContainer: { 
        flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', 
        borderWidth: 1, borderColor: Colors.borderColor, borderRadius: 8, 
        paddingHorizontal: 10, paddingVertical: Platform.OS === 'android' ? 5 : 10, 
        backgroundColor: Colors.white, minHeight: 50, 
    },
    variantTagsWrapper: { flexDirection: 'row', flexWrap: 'wrap', flex: 1, alignItems: 'center' },
    variantTag: { 
        flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.lightBg, 
        borderWidth: 1, borderColor: Colors.borderColor, borderRadius: 20, 
        paddingVertical: 4, paddingHorizontal: 8, marginRight: 8, marginVertical: 4, 
    },
    variantTagText: { fontSize: 13, color: '#48505E' },

    // Button Styles
    buttonRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 20 },
    saveButton: { 
        flex: 1, backgroundColor: Colors.primaryOrange, paddingVertical: 14, 
        borderRadius: 8, alignItems: 'center', marginLeft: 10, 
    },
    saveButtonText: { fontSize: 16, fontWeight: '700', color: Colors.white },
    cancelButton: { 
        flex: 1, backgroundColor: '#FFFAF5', paddingVertical: 14, 
        borderRadius: 8, alignItems: 'center', marginRight: 10, 
        borderWidth: 1, borderColor: Colors.borderColor, 
    },
    cancelButtonText: { fontSize: 16, fontWeight: '700', color: Colors.black },
});

export default AssignProducts;