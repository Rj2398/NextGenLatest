import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import React, {useState, useMemo} from 'react';
import BottomSheetFilter from './BottomSheetFilter';
import DealsDiscountScreen from './DealsDiscountScreen';

const FilterIcon = require('../../../assets/filter_icon.png');
const ActiveFilterIcon = require('../../../assets/filter_fill.png');
import {useNavigation} from '@react-navigation/native';
import useDashboard from '../../../hooks/useDashboard';
import InventoryList from '../../components/InventoryList';

// --- Dimensions for Card Width Calculation ---
const {width} = Dimensions.get('window');
const CARD_MARGIN = 8;

// --- Utility to convert a readable name to a machine key (e.g., "Low Stock" -> "low_stock") ---
const toKpiKey = name => {
  if (!name) return '';
  return name.toLowerCase().replace(/\s/g, '_');
};

// --- KPI Value Formatting Function (Updated to use kpi_name/kpi_value) ---
function formatKpiValue(kpi) {
  const value = kpi.kpi_value;
  const kpiKey = toKpiKey(kpi.kpi_name);

  // Since explicit type metadata is missing, we infer currency for these keys
  if (kpiKey === 'revenue' || kpiKey === 'cost') {
    const formattedValue = parseFloat(value).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    // Assuming AED as per typical context, or you can use '$'
    const currencySymbol = 'AED';
    return `${currencySymbol} ${formattedValue}`;
  } else if (!isNaN(parseFloat(value))) {
    const formattedValue = parseFloat(value).toLocaleString(undefined, {
      maximumFractionDigits: 0,
    });
    return formattedValue;
  }
  return value;
}

// --- KpiCard Component Definition (Updated to use kpi_name/kpi_value) ---
const KpiCard = ({item}) => {
  // Derive kpiKey from kpi_name for styling logic
  const kpiKey = toKpiKey(item.kpi_name);

  // Use the derived kpiKey for secondary styling
  const isSecondaryStyle =
    kpiKey === 'low_stock' || kpiKey === 'out_of_stock' || kpiKey === 'cost';

  // Pass the entire item object (with kpi_value) to formatter
  const formattedValue = formatKpiValue(item);
  const cardStyle = isSecondaryStyle ? styles.card2 : styles.card;
  const titleStyle = isSecondaryStyle ? styles.card2Title : styles.cardTitle;

  // Use kpi_period or fallback to kpi_description
  const subText = item.kpi_period || item.kpi_description || 'Overall';

  return (
    <View
      style={[
        cardStyle,
        {width: width / 2 - 24, marginHorizontal: CARD_MARGIN / 2},
      ]}>
      <Text style={titleStyle} numberOfLines={1}>
        {item.kpi_name} {/* 👈 Reading kpi_name */}
      </Text>
      <Text style={styles.cardValue}>{formattedValue}</Text>
      <Text style={styles.cardSub} numberOfLines={1}>
        {subText} {/* 👈 Reading kpi_period/kpi_description */}
      </Text>
    </View>
  );
};
// --- END KpiCard Component ---

const InventoryListScreen = () => {
  const {
    getDashboardList,
    isLoadingDashboard,
    getStuctDashboard,
    isLoadignStuctDashboard,
  } = useDashboard();

  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterVisible, setIsFilterVisible] = useState(false);

  const navigation = useNavigation();

  // 🔄 RESTORED: Using the original data structure provided by the user
  // Note: If you are using real data from useDashboard(), you should use:
  const dashboardData = getDashboardList?.items || [];

  // 2. Filtering Logic (Updated to use kpi_name)
  const filteredData = useMemo(() => {
    if (!searchQuery) {
      return dashboardData;
    }
    const lowerCaseQuery = searchQuery.toLowerCase();

    return dashboardData.filter(kpi => {
      // Search by kpi_name, as kpiKey is not available in the raw data
      const nameMatches = kpi.kpi_name?.toLowerCase().includes(lowerCaseQuery);

      return nameMatches;
    });
  }, [dashboardData, searchQuery]);

  const openFilters = () => setIsFilterVisible(true);
  const closeFilters = () => setIsFilterVisible(false);

  const handlePressBulk = () => {
    navigation.navigate('BulkUpload');
  };
  const handlePressAddProduct = () => {
    navigation.navigate('AddNewProduct', {});
  };
  const handlePressDeals = () => {
    navigation.navigate('DealsDiscountScreen');
  };

  const renderKpiItem = ({item}) => <KpiCard item={item} />;

  return (
    <View style={styles.container}>
      {/* Search */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <Image
            source={require('../../../assets/search_icon.png')}
            style={styles.searchImage}
            resizeMode="contain"
          />
          <TextInput
            placeholder="Search Product or orders"
            placeholderTextColor="#888"
            style={styles.searchInput}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <TouchableOpacity onPress={openFilters}>
          <Image
            source={isFilterVisible ? ActiveFilterIcon : FilterIcon}
            style={styles.filterImage}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>

      <BottomSheetFilter isVisible={isFilterVisible} onClose={closeFilters} />

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>Overall Inventory</Text>

        {/* Cards Grid - FlatList Implementation */}
        <FlatList
          data={filteredData} // Using the FILTERED data
          keyExtractor={item => item.kpi_name} // 👈 Using kpi_name for key
          renderItem={renderKpiItem}
          numColumns={2}
          scrollEnabled={false}
          columnWrapperStyle={styles.cardRow}
          ListEmptyComponent={() =>
            !isLoadingDashboard &&
            filteredData.length === 0 && (
              <Text style={styles.emptyText}>
                {searchQuery
                  ? `No results found for "${searchQuery}".`
                  : 'No inventory data available.'}
              </Text>
            )
          }
        />

        {isLoadingDashboard && (
          <ActivityIndicator
            size="large"
            color="#FF8719"
            style={{marginTop: 20}}
          />
        )}

        {/* Buttons and Deals Card... (rest of the component) */}
        <TouchableOpacity
          style={styles.orangeBtn}
          onPress={handlePressAddProduct}>
          <Image
            source={require('../../../assets/plus_icon.png')}
            style={styles.uploadImage}
            resizeMode="contain"
          />
          <Text style={[styles.btnText, {marginStart: 5}]}>
            Add New Products
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.orangeBtnLight}>
          <Text style={styles.btnText}>View all Products</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.uploadBtn} onPress={handlePressBulk}>
          <Image
            source={require('../../../assets/upload_icon.png')}
            style={styles.uploadImage}
            resizeMode="contain"
          />
          <Text style={[styles.btnText, {marginLeft: 6}]}>Bulk Upload</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.dealCard} onPress={handlePressDeals}>
          <Image
            source={require('../../../assets/cuppons_icon.png')}
            style={styles.discountImage}
            resizeMode="contain"
          />
          <Text style={styles.dealText}>Deals & Discount</Text>
          <Image
            source={require('../../../assets/arrow_icon.png')}
            style={styles.arrowImage}
            resizeMode="contain"
          />
        </TouchableOpacity>

        <InventoryList />
      </ScrollView>
    </View>
  );
};

export default InventoryListScreen;

// --- Stylesheet (Kept for completeness) ---
const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#fff', paddingHorizontal: 16},
  scrollContent: {
    paddingBottom: 100,
  },

  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffff',
    borderRadius: 8,
    borderColor: '#D7D7D7',
    borderWidth: 1,
    paddingHorizontal: 10,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    color: '#000',
    fontSize: 12,
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginVertical: 10,
    color: '#000',
  },

  cardRow: {
    justifyContent: 'space-between',
    marginBottom: 12,
  },

  card: {
    backgroundColor: '#fff7f0',
    borderColor: '#F89941',
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    height: 100,
    justifyContent: 'space-around',
  },
  card2: {
    backgroundColor: '#ffedee',
    borderColor: '#D24648',
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    height: 100,
    justifyContent: 'space-around',
  },
  cardTitle: {
    fontSize: 13,
    color: '#FF7A00',
    fontWeight: '500',
  },
  card2Title: {
    fontSize: 13,
    color: '#D24648',
    fontWeight: '500',
  },
  cardValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
    marginVertical: 4,
  },
  cardSub: {
    fontSize: 10,
    color: '#5F6368',
    fontWeight: '500',
  },

  orangeBtn: {
    backgroundColor: '#FF8719',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  orangeBtnLight: {
    backgroundColor: '#FFAF66',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  uploadBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFAF66',
    padding: 14,
    borderRadius: 10,
    marginTop: 10,
  },
  btnText: {color: '#fff', fontWeight: '600', fontSize: 14},

  dealCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFF',
    padding: 14,
    borderRadius: 10,
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#E2E2E2',
  },
  dealText: {fontWeight: '600', color: '#000', marginStart: 10},
  emptyText: {
    textAlign: 'center',
    color: '#888',
    marginTop: 20,
  },
  filterImage: {width: 50, height: 50, marginStart: 5, marginTop: 5},
  searchImage: {width: 25, height: 25, marginStart: 5},
  uploadImage: {width: 15, height: 15},
  discountImage: {width: 15, height: 15},
  arrowImage: {width: 15, height: 15, marginStart: 25, marginTop: 3},
});

// import {useNavigation} from '@react-navigation/native';
// import React, {useState, useMemo} from 'react';
// import {
//   View,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
//   Image,
//   StatusBar,
//   TextInput,
//   FlatList,
//   Alert,
// } from 'react-native';

// import {SafeAreaView} from 'react-native-safe-area-context';
// // import useProductModal from '../../../hooks/useProduct'; // 🗑️ External hook not accessible

// // --- 1. 🚀 Dynamic Product Data (Added isActive field for filtering demo) ---
// const rawProductData = [
//   {
//     id: '1',
//     producttitle: 'iPhone 15 Pro Max 256GB Titanium Natural',
//     description:
//       'The most advanced iPhone with titanium design, A17 Pro chip, and professional camera system.',
//     categoryid: '1',
//     brand: 'Apple',
//     isActive: true, // 🚀 Added isActive: true
//     subcategoryid: '1',
//     isreturnable: true,
//     returnwindowdays: 14,
//     hasvariants: true,
//     variationtheme: 'Color',
//     gender: 'Unisex',
//     variants: [
//       {
//         sku: 'IPHONE15PM-256-TN',
//         color: 'Titanium Natural',
//         variantPrice: 4499.0,
//         variantQuantity: 25,
//         weightUnit: 'g',
//         weight: 221,
//       },
//     ],
//   },
//   {
//     id: '2',
//     producttitle: 'Samsung Galaxy S24 Ultra 512GB',
//     description: 'Flagship Android phone with S Pen and 200MP camera.',
//     categoryid: '1',
//     brand: 'Samsung',
//     isActive: false, // 🚀 Added isActive: false (This item will be filtered out)
//     subcategoryid: '1',
//     isreturnable: true,
//     returnwindowdays: 14,
//     hasvariants: true,
//     variationtheme: 'Color',
//     gender: 'Unisex',
//     variants: [
//       {
//         sku: 'S24U-512-BL',
//         color: 'Black',
//         variantPrice: 4999.0,
//         variantQuantity: 10,
//         weightUnit: 'g',
//         weight: 232,
//       },
//     ],
//   },
//   {
//     id: '3',
//     producttitle: 'Nike Air Max 90 White Leather Running Shoes',
//     description:
//       'Classic running shoe with Air Max cushioning and timeless design.',
//     categoryid: '2',
//     brand: 'Nike',
//     isActive: true, // 🚀 Added isActive: true
//     subcategoryid: '3',
//     variants: [
//       {
//         sku: 'NIKE-AM90-WHITE-40',
//         size: '40',
//         variantPrice: 439.0,
//         variantQuantity: 8,
//         weightUnit: 'g',
//         weight: 350,
//       },
//     ],
//   },
// ];

// const InventoryListScreen = () => {
//   const navigation = useNavigation();

//   // 🗑️ COMMENTED OUT: External hook not accessible and not necessary for the data display requirement.
//   // const {getCategory, isLoadingProducts} = useProductModal();

//   const [searchQuery, setSearchQuery] = useState('');
//   const [expandedItems, setExpandedItems] = useState(new Set());

//   // 🚀 2. Use useMemo to filter raw data and then transform it
//   const inventoryItems = useMemo(() => {
//     // 🚀 STEP 1: Filter the raw data to include ONLY products where isActive is true
//     const activeProducts = rawProductData.filter(
//       product => product.isActive === true,
//     );

//     // 🚀 STEP 2: Map the filtered data to the InventoryCard format
//     return activeProducts.map(product => {
//       const totalQuantity = product.variants.reduce(
//         (sum, variant) => sum + variant.variantQuantity,
//         0,
//       );
//       const firstVariant = product.variants[0] || {};

//       return {
//         id: product.id,
//         name: product.producttitle,
//         description: product.description,
//         // Stock metrics mapped from product data
//         openStock: totalQuantity,
//         remainingStock: totalQuantity,
//         thresholdValue: 10, // Static placeholder
//         onTheWay: 0, // Static placeholder
//         sellingPrice: firstVariant.variantPrice || 0,
//         weight: `${firstVariant.weight || ''}${firstVariant.weightUnit || ''}`,
//         // NOTE: You need a dynamic image URL in your JSON to make this dynamic
//         imageUrl: 'https://placehold.co/60x60/DBEAFE/FFFFFF/png',
//       };
//     });
//   }, []);

//   // --- Utility functions (Unchanged) ---
//   const toggleExpanded = itemId => {
//     setExpandedItems(prev => {
//       const newSet = new Set(prev);
//       if (newSet.has(itemId)) {
//         newSet.delete(itemId);
//       } else {
//         newSet.add(itemId);
//       }
//       return newSet;
//     });
//   };

//   const handleEdit = itemId => {
//     Alert.alert('Edit Item', `Edit item ${itemId}`);
//   };

//   const handleDelete = (itemId, itemName) => {
//     Alert.alert(
//       'Delete Item',
//       `Are you sure you want to delete "${itemName}"?`,
//       [
//         {text: 'Cancel', style: 'cancel'},
//         {
//           text: 'Delete',
//           style: 'destructive',
//           onPress: () => console.log('Item deleted'),
//         },
//       ],
//     );
//   };

//   const handleViewDetails = itemData => {
//     // Pass the full dynamic data object
//     navigation.navigate('ItemDetailsScreen', {item: itemData});
//   };

//   const handleFilter = () => {
//     Alert.alert('Filter', 'Filter functionality will be implemented here');
//   };

//   const handleMenu = () => {
//     Alert.alert('Menu', 'Menu functionality will be implemented here');
//   };

//   const handleSearchImageClick = () => {
//     Alert.alert('Searching here', `Search for the text ${searchQuery}`);
//   };

//   const renderInventoryCard = ({item}) => (
//     <InventoryCard
//       key={item.id}
//       item={item}
//       isExpanded={expandedItems.has(item.id)}
//       onToggleExpand={() => toggleExpanded(item.id)}
//       onEdit={() => handleEdit(item.id)}
//       onDelete={() => handleDelete(item.id, item.name)}
//       onViewDetails={() => handleViewDetails(item)}
//     />
//   );

//   return (
//     <SafeAreaView style={styles.container}>
//       <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />

//       {/* Header (Unchanged) */}
//       <View style={styles.header}>
//         <Image
//           source={require('../../../assets/images/nextgenlogo.png')}
//           style={styles.logo}
//           resizeMode="contain"
//         />
//         <Text style={styles.headerTitle}>Inventory</Text>
//         <TouchableOpacity onPress={handleMenu}>
//           <Image
//             source={require('../../../assets/images/slider_icon.png')}
//             style={{width: 20, height: 20}}
//             resizeMode="contain"
//           />
//         </TouchableOpacity>
//       </View>

//       {/* Search Bar (Unchanged) */}
//       <View style={styles.searchContainer}>
//         <View style={styles.searchInputWrapper}>
//           <TouchableOpacity onPress={handleSearchImageClick}>
//             <Image
//               source={require('../../../assets/images/ic_search_icon.png')}
//               style={{width: 23, height: 23}}
//               resizeMode="contain"
//             />
//           </TouchableOpacity>

//           <TextInput
//             style={styles.searchInput}
//             placeholder="Search Inventory"
//             placeholderTextColor="#9CA3AF"
//             value={searchQuery}
//             onChangeText={setSearchQuery}
//           />
//         </View>
//         <TouchableOpacity onPress={handleFilter}>
//           <Image
//             source={require('../../../assets/images/ic_filter_icon.png')}
//             style={styles.filterButton}
//             resizeMode="cover"></Image>
//         </TouchableOpacity>
//       </View>

//       <View style={{flex: 1}}>
//         {/* FlatList uses the filtered inventoryItems */}
//         <FlatList
//           data={inventoryItems}
//           keyExtractor={item => item.id}
//           renderItem={renderInventoryCard}
//           showsVerticalScrollIndicator={false}
//           contentContainerStyle={styles.scrollContent}
//         />
//       </View>
//     </SafeAreaView>
//   );
// };

// // --- InventoryCard Component (Unchanged) ---

// const InventoryCard = ({
//   item,
//   isExpanded,
//   onToggleExpand,
//   onEdit,
//   onDelete,
//   onViewDetails,
// }) => {
//   return (
//     <View style={styles.card}>
//       {/* Card Header */}
//       <View style={styles.cardHeader}>
//         <Text style={styles.itemName}>{item.name}</Text>
//         <Image
//           style={styles.itemImage}
//           resizeMode="contain"
//           source={require('../../../assets/images/ic_maggi.png')}
//         />
//       </View>

//       {/* Metrics Grid */}
//       <View style={styles.metricsGrid}>
//         <View style={styles.metricItem}>
//           <Text style={styles.metricLabel}>Open Stock</Text>
//           <Text style={styles.metricValue}>{item.openStock}</Text>
//         </View>
//         <View style={styles.metricItem}>
//           <Text style={styles.metricLabel}>Rem. Stock</Text>
//           <Text style={styles.metricValue}>{item.remainingStock}</Text>
//         </View>
//         <View style={styles.metricItem}>
//           <Text style={styles.metricLabel}>Threshold value</Text>
//           <Text style={styles.metricValue}>{item.thresholdValue}</Text>
//         </View>
//       </View>

//       <View style={styles.metricsGrid}>
//         <View style={styles.metricItem}>
//           <Text style={styles.metricLabel}>On the way</Text>
//           <Text style={styles.metricValue}>{item.onTheWay}</Text>
//         </View>
//         <View style={styles.metricItem}>
//           <Text style={styles.metricLabel}>SP</Text>
//           <Text style={styles.metricValue}>AED {item.sellingPrice}</Text>
//         </View>
//         <View style={styles.metricItem}>
//           <Text style={styles.metricLabel}>Weight</Text>
//           <Text style={styles.metricValue}>{item.weight}</Text>
//         </View>
//       </View>

//       {/* Action Buttons */}
//       <View style={styles.actionButtons}>
//         <TouchableOpacity
//           style={styles.editButton}
//           onPress={onEdit}
//           activeOpacity={0.8}>
//           <Image
//             source={require('../../../assets/images/ic_edit_button.png')}
//             style={{width: 20, height: 20}}
//             resizeMode="contain"
//           />
//           <Text style={styles.editButtonText}>Edit Item</Text>
//         </TouchableOpacity>

//         <TouchableOpacity
//           style={styles.deleteButton}
//           onPress={onDelete}
//           activeOpacity={0.8}>
//           <Image
//             source={require('../../../assets/images/ic_delete_icon.png')}
//             style={{width: 20, height: 20}}
//             resizeMode="contain"
//           />
//           <Text style={styles.deleteButtonText}>Delete Item</Text>
//         </TouchableOpacity>
//       </View>

//       {/* View More Details Button */}
//       <TouchableOpacity
//         style={styles.viewMoreButton}
//         onPress={onViewDetails}
//         activeOpacity={0.8}>
//         <Text style={styles.viewMoreText}>View More Details</Text>
//         <Image
//           source={require('../../../assets/images/ic_drop_down_white.png')}
//           style={{width: 12, height: 11}}
//           resizeMode="contain"
//         />
//       </TouchableOpacity>
//     </View>
//   );
// };

// // --- STYLES (Unchanged) ---
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#F3F4F6',
//   },
//   header: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     paddingHorizontal: 16,
//     paddingVertical: 12,
//     backgroundColor: '#FFFFFF',
//     borderBottomWidth: 1,
//     borderBottomColor: '#E5E7EB',
//   },
//   logo: {
//     width: 80,
//     height: 32,
//   },
//   headerTitle: {
//     position: 'absolute',
//     left: 0,
//     right: 0,
//     textAlign: 'center',
//     fontSize: 18,
//     fontWeight: '600',
//     color: '#111827',
//   },

//   menuButton: {
//     padding: 8,
//   },
//   iconText: {
//     fontSize: 20,
//     color: '#111827',
//   },
//   searchContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     paddingHorizontal: 16,
//     paddingVertical: 12,
//     backgroundColor: '#FFFFFF',
//     gap: 9,
//   },
//   searchInputWrapper: {
//     flex: 1,
//     flexDirection: 'row',
//     alignItems: 'center',
//     backgroundColor: '#F9FAFB',
//     borderRadius: 8,
//     paddingHorizontal: 12,
//     paddingVertical: 10,
//     borderWidth: 1,
//     borderColor: '#E5E7EB',
//     height: 60,
//   },
//   searchInput: {
//     flex: 1,
//     marginLeft: 8,
//     fontSize: 14,
//     color: '#111827',
//   },
//   filterButton: {
//     width: 55,
//     height: 60,
//     borderRadius: 8,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   scrollView: {
//     flex: 1,
//   },
//   scrollContent: {
//     padding: 16,
//     gap: 16,
//   },
//   card: {
//     backgroundColor: '#FFFFFF',
//     borderRadius: 12,
//     padding: 16,
//     shadowColor: '#000',
//     shadowOffset: {width: 0, height: 2},
//     shadowOpacity: 0.1,
//     shadowRadius: 4,
//     elevation: 3,
//     marginBottom: 16,
//   },
//   cardHeader: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: 16,
//   },
//   itemName: {
//     fontSize: 18,
//     fontWeight: '600',
//     color: '#111827',
//     flex: 1,
//   },
//   itemImage: {
//     width: 60,
//     height: 60,
//     backgroundColor: '#FEF3C7',
//     borderRadius: 8,
//   },
//   metricsGrid: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     marginBottom: 12,
//   },
//   metricItem: {
//     flex: 1,
//   },
//   metricLabel: {
//     fontSize: 12,
//     color: '#6B7280',
//     marginBottom: 4,
//   },
//   metricValue: {
//     fontSize: 16,
//     fontWeight: '600',
//     color: '#111827',
//   },
//   actionButtons: {
//     flexDirection: 'row',
//     gap: 12,
//     marginTop: 16,
//     marginBottom: 12,
//   },
//   editButton: {
//     flex: 1,
//     backgroundColor: '#FDB462',
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'center',
//     paddingVertical: 12,
//     borderRadius: 8,
//     gap: 6,
//   },
//   editButtonText: {
//     color: '#FFFFFF',
//     fontSize: 14,
//     fontWeight: '600',
//   },
//   deleteButton: {
//     flex: 1,
//     backgroundColor: '#FFFFFF',
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'center',
//     paddingVertical: 12,
//     borderRadius: 8,
//     borderWidth: 1,
//     borderColor: '#E5E7EB',
//     gap: 6,
//   },
//   deleteButtonText: {
//     color: '#111827',
//     fontSize: 14,
//     fontWeight: '600',
//   },
//   viewMoreButton: {
//     backgroundColor: '#FF8C00',
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'center',
//     paddingVertical: 14,
//     borderRadius: 8,
//     gap: 8,
//   },
//   viewMoreText: {
//     color: '#FFFFFF',
//     fontSize: 16,
//     fontWeight: 'bold',
//   },
//   sectionTitle: {
//     fontSize: 16,
//     fontWeight: '600',
//     color: '#111827',
//     paddingHorizontal: 16,
//     paddingVertical: 8,
//   },
// });

// export default InventoryListScreen;
