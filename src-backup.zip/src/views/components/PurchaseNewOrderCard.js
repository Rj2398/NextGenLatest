import React from 'react';
import {View, Text, Image, StyleSheet, Dimensions} from 'react-native';
import {formatDisplayFields} from '../../utils/modal/customCodeModal';

const {width} = Dimensions.get('window');

const CARD_BG = '#ffffff';
const SECONDARY_COLOR = '#f3f4f6';
const DARK_TEXT = '#1f2937';
const GRAY_TEXT = '#000000';

const PurchaseNewOrderCard = ({item, fieldLabelMap}) => {
  console.log(fieldLabelMap, '***********maplabel');
  console.log(item, '***********complete item***');
  const lastFourDigits =
    item?.payment_method?.replace(/\D/g, '').slice(-4) || '';

  const formattedDate = item?.order_date
    ? new Date(item.order_date).toLocaleDateString('en-GB')
    : '';

  // ✅ Use global helper
  const displayFields = formatDisplayFields(item, fieldLabelMap);

  return (
    <View style={styles.purchaseCard}>
      <View style={styles.purchaseCardContent}>
        {/* Product Image */}
        <Image
          source={
            item?.product_image
              ? {uri: item.product_image}
              : require('../../assets/images/ic_maggi.png')
          }
          style={styles.purchaseProductImage}
          resizeMode="contain"
        />

        {/* Left Section: dynamic fields */}
        <View style={styles.purchaseDetails}>
          {displayFields.map((field, index) => (
            <Text key={index} style={styles.purchaseDetailText}>
              <Text style={{fontWeight: 'bold'}}>{field.label}: </Text>
              {field.value}
            </Text>
          ))}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  purchaseCard: {
    backgroundColor: CARD_BG,
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  purchaseCardContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  purchaseProductImage: {
    width: 70,
    height: 80,
    borderRadius: 6,
    marginRight: 12,
    borderWidth: 1,
    borderColor: SECONDARY_COLOR,
  },
  purchaseDetails: {
    flex: 1,
    marginRight: 10,
  },
  purchaseRightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
  purchaseDetailText: {
    fontSize: 13,
    color: GRAY_TEXT,
    marginBottom: 2,
  },
  purchaseOrderDate: {
    fontSize: 13,
    color: GRAY_TEXT,
    marginBottom: 4,
  },
  purchasePayment: {
    fontSize: 13,
    color: GRAY_TEXT,
    marginBottom: 4,
  },
  purchaseAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: DARK_TEXT,
  },
});

export default PurchaseNewOrderCard;
