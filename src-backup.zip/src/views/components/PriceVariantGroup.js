// import React, {useState} from 'react';
// import {View, Text, StyleSheet, TouchableOpacity, Alert} from 'react-native';
// import Feather from 'react-native-vector-icons/Feather';

// // --- Colors and Constants ---
// const colors = {
//   white: '#FFFFFF',
//   black: '#000000',
//   textPrimary: '#161B25',
//   textSecondary: '#6B7280',
//   border: '#E0E0E0',
//   lightGray: '#F9FBF9',
//   // Tag Colors (Your static colors for internal use)
//   tagLightGreen: '#CAECC5',
//   tagLightRed: '#FFD0E0',
//   tagLightBlue: '#E2EAF6',
//   tagLightYellow: '#FFFACD',
//   tagLightPurple: '#E6E6FA',
//   tagDefault: '#EBEBEB',
// };

// // --- Static Size to Color Mapping (Internal to the component) ---
// // This map ensures visual consistency for common sizes, regardless of whether
// // the 'color' property is present in the API options array.
// const SIZE_COLOR_MAP = {
//   S: colors.tagLightBlue,
//   M: colors.tagLightGreen,
//   L: colors.tagLightRed,
//   XL: colors.tagLightYellow,
//   XXL: colors.tagLightPurple,
//   // Fallback for any other ID/size not listed
//   default: colors.tagDefault,
// };

// // --- Sub-Component: Interactive Variant Chip (Tag) ---
// const VariantChip = ({variant, onRemove}) => {
//   // Use size/id for color lookup
//   const sizeKey = (variant.size || variant.id)?.toUpperCase();

//   // Determine color: Check map, fallback to variant.color (if provided by API/previous logic), then default
//   const chipColor =
//     SIZE_COLOR_MAP[sizeKey] || variant.color || SIZE_COLOR_MAP.default;

//   return (
//     <View style={[tagStyles.chipContainer, {backgroundColor: chipColor}]}>
//       <Text style={tagStyles.chipText}>{variant.label}</Text>
//       <TouchableOpacity
//         onPress={() => onRemove(variant.id)}
//         style={tagStyles.deleteIcon}>
//         <Feather name="x" size={12} color={colors.textPrimary} />
//       </TouchableOpacity>
//     </View>
//   );
// };

// // ------------------------------------------------------------------
// // Main Component: PriceVariantGroup (Controlled Component)
// // ------------------------------------------------------------------
// const PriceVariantGroup = ({
//   value,
//   onChange,
//   options, // <-- This is the definitive source of selectable items
//   label,
//   placeholder,
// }) => {
//   const variants = value || [];
//   const [isOpen, setIsOpen] = useState(false);

//   // The definitive source of options is the 'options' prop.
//   const AVAILABLE_OPTIONS = options || [];

//   // Function to vari a single variant tag by its ID
//   const handleRemoveVariant = idToRemove => {
//     const updatedVariants = variants.filter(v => v.id !== idToRemove);
//     onChange(updatedVariants);
//   };

//   // Function to add a new variant (simulated selection)
//   const handleAddVariant = selectedItem => {
//     // Determine the key for duplication check (use 'size' if present, otherwise 'id')
//     const uniqueKey = selectedItem.id;

//     const alreadyExists = variants.some(v => v.id === uniqueKey);

//     if (alreadyExists) {
//       Alert.alert('Duplicate', `${selectedItem.label} is already added.`);
//       return;
//     }

//     // Create the new variant object that will be stored in state and submitted.
//     const newVariant = {
//       // 🎯 FIX: Use the uniqueKey (e.g., 'S', 'M', '1', '2') as the ID.
//       // This ID is used for both the React key and for reliable serialization.
//       id: uniqueKey,

//       size: uniqueKey,
//       label: `${selectedItem.label} Q - 100`,
//       value: Math.floor(Math.random() * 100),

//     };

//     const updatedVariants = [...variants, newVariant];

//     // As per your previous instruction, if you need to send the serialized string now:
//     const serializedValue = updatedVariants
//       .map(item => item.size || item.id)
//       .join(',');
//     console.log(serializedValue, '*****idddd*********');
//     // Send the serialized string (e.g., 'S,M,L') to update the parent state
//     onChange(serializedValue); // <-- This sends the string to formData

//     setIsOpen(false);
//   };

//   // Function to clear all variants
//   const handleDeleteGroup = () => {
//     onChange([]);
//   };

//   return (
//     <View style={styles.container}>
//       {/* Header Row: Label and Delete Icon */}
//       <View style={styles.header}>
//         <Text style={styles.headerTitle}>{label || 'Price Variants'}</Text>
//         {variants.length > 0 && (
//           <TouchableOpacity onPress={handleDeleteGroup}>
//             <Feather name="trash-2" size={18} color={colors.textSecondary} />
//           </TouchableOpacity>
//         )}
//       </View>

//       {/* 1. Dropdown/Input Area to add variants */}
//       <TouchableOpacity
//         style={styles.dropdown}
//         onPress={() => setIsOpen(!isOpen)}>
//         <Text style={styles.dropdownText}>
//           {variants.length > 0
//             ? `${variants.length} items selected`
//             : placeholder || 'Add Options...'}
//         </Text>
//         <Feather
//           name={isOpen ? 'chevron-up' : 'chevron-down'}
//           size={20}
//           color={colors.textSecondary}
//         />
//       </TouchableOpacity>

//       {/* Option Selection List (Conditional Rendering) */}
//       {isOpen && (
//         <View style={styles.optionsContainer}>
//           {AVAILABLE_OPTIONS.map(item => (
//             <TouchableOpacity
//               key={item.id}
//               style={styles.optionItem}
//               onPress={() => handleAddVariant(item)}>
//               <Text style={styles.optionText}>
//                 {item.label} ({item.size || item.id})
//               </Text>
//             </TouchableOpacity>
//           ))}
//         </View>
//       )}

//       {/* 2. Variant Chips/Tags Display */}
//       <View style={styles.chipsContainer}>
//         {variants.map(variant => (
//           <VariantChip
//             key={variant.id}
//             variant={variant}
//             onRemove={handleRemoveVariant}
//           />
//         ))}
//       </View>
//     </View>
//   );
// };

// export default PriceVariantGroup;

// // --- Stylesheets (Unchanged) ---
// const styles = StyleSheet.create({
//   container: {
//     backgroundColor: colors.white,
//     padding: 16,
//     borderRadius: 8,
//     shadowColor: '#000',
//     shadowOpacity: 0.05,
//     shadowRadius: 5,
//     elevation: 2,
//     margin: 10,
//   },
//   header: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: 10,
//   },
//   headerTitle: {
//     fontSize: 16,
//     fontWeight: '500',
//     color: colors.black,
//   },

//   // Dropdown Styles
//   dropdown: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     borderWidth: 1,
//     borderColor: colors.border,
//     paddingHorizontal: 12,
//     paddingVertical: 10,
//     borderRadius: 6,
//     backgroundColor: colors.white,
//     marginBottom: 15,
//   },
//   dropdownText: {
//     fontSize: 16,
//     color: colors.black,
//     fontWeight: '600',
//   },

//   // Dropdown Options List
//   optionsContainer: {
//     borderWidth: 1,
//     borderColor: colors.border,
//     borderRadius: 6,
//     marginBottom: 10,
//     maxHeight: 150,
//     overflow: 'hidden',
//   },
//   optionItem: {
//     padding: 12,
//     borderBottomWidth: 1,
//     borderBottomColor: colors.border,
//     backgroundColor: colors.lightGray,
//   },
//   optionText: {
//     fontSize: 14,
//     color: colors.textPrimary,
//   },

//   // Variant Chips Container
//   chipsContainer: {
//     flexDirection: 'row',
//     flexWrap: 'wrap',
//   },
// });

// const tagStyles = StyleSheet.create({
//   chipContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     paddingHorizontal: 10,
//     paddingVertical: 6,
//     borderRadius: 15,
//     marginRight: 8,
//     marginBottom: 8,
//     shadowColor: '#000',
//     shadowOpacity: 0.05,
//     shadowRadius: 2,
//     elevation: 1,
//   },
//   chipText: {
//     fontSize: 14,
//     fontWeight: '500',
//     color: colors.black,
//     marginRight: 5,
//   },
//   deleteIcon: {
//     padding: 2,
//     borderRadius: 10,
//   },
// });

import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Alert} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';

// --- Colors and Constants ---
const colors = {
  white: '#FFFFFF',
  black: '#000000',
  textPrimary: '#161B25',
  textSecondary: '#6B7280',
  border: '#E0E0E0',
  lightGray: '#F9FBF9',
  tagLightGreen: '#CAECC5',
  tagLightRed: '#FFD0E0',
  tagLightBlue: '#E2EAF6',
  tagLightYellow: '#FFFACD',
  tagLightPurple: '#E6E6FA',
  tagDefault: '#EBEBEB',
};

// --- Static Size to Color Mapping ---
const SIZE_COLOR_MAP = {
  S: colors.tagLightBlue,
  M: colors.tagLightGreen,
  L: colors.tagLightRed,
  XL: colors.tagLightYellow,
  XXL: colors.tagLightPurple,
  default: colors.tagDefault,
};

// --- Sub-Component: Interactive Variant Chip ---
const VariantChip = ({variant, onRemove}) => {
  const sizeKey = (variant.size || variant.id)?.toUpperCase();
  const chipColor =
    SIZE_COLOR_MAP[sizeKey] || variant.color || SIZE_COLOR_MAP.default;

  return (
    <View style={[tagStyles.chipContainer, {backgroundColor: chipColor}]}>
      <Text style={tagStyles.chipText}>{variant.label}</Text>
      <TouchableOpacity
        onPress={() => onRemove(variant.id)}
        style={tagStyles.deleteIcon}>
        <Feather name="x" size={12} color={colors.textPrimary} />
      </TouchableOpacity>
    </View>
  );
};

// ------------------------------------------------------------------
// Main Component: PriceVariantGroup
// ------------------------------------------------------------------
const PriceVariantGroup = ({value, onChange, options, label, placeholder}) => {
  // ✅ Ensure variants is always an array
  const variants = Array.isArray(value)
    ? value
    : typeof value === 'string' && value.length > 0
    ? value.split(',').map(v => ({
        id: v.trim(),
        size: v.trim(),
        label: `${v.trim()} Q - 100`,
        value: Math.floor(Math.random() * 100),
      }))
    : [];

  const [isOpen, setIsOpen] = useState(false);
  const AVAILABLE_OPTIONS = options || [];

  // ✅ Remove variant
  const handleRemoveVariant = idToRemove => {
    const updatedVariants = variants.filter(v => v.id !== idToRemove);
    onChange(updatedVariants);
  };

  // ✅ Add variant
  const handleAddVariant = selectedItem => {
    const uniqueKey = selectedItem.id;
    const alreadyExists = variants.some(v => v.id === uniqueKey);

    if (alreadyExists) {
      Alert.alert('Duplicate', `${selectedItem.label} is already added.`);
      return;
    }

    const newVariant = {
      id: uniqueKey,
      size: uniqueKey,
      label: `${selectedItem.label} Q - 100`,
      value: Math.floor(Math.random() * 100),
    };

    const updatedVariants = [...variants, newVariant];

    // (Optional) Serialized form for logging only
    const serializedValue = updatedVariants
      .map(item => item.size || item.id)
      .join(',');
    console.log('Serialized:', serializedValue);

    // ✅ Always send array to parent
    onChange(serializedValue);

    setIsOpen(false);
  };

  // ✅ Clear all
  const handleDeleteGroup = () => {
    onChange([]);
  };

  return (
    <View style={styles.container}>
      {/* Header Row */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{label || 'Price Variants'}</Text>
        {variants.length > 0 && (
          <TouchableOpacity onPress={handleDeleteGroup}>
            <Feather name="trash-2" size={18} color={colors.textSecondary} />
          </TouchableOpacity>
        )}
      </View>

      {/* Dropdown/Input */}
      <TouchableOpacity
        style={styles.dropdown}
        onPress={() => setIsOpen(!isOpen)}>
        <Text style={styles.dropdownText}>
          {variants.length > 0
            ? `${variants.length} items selected`
            : placeholder || 'Add Options...'}
        </Text>
        <Feather
          name={isOpen ? 'chevron-up' : 'chevron-down'}
          size={20}
          color={colors.textSecondary}
        />
      </TouchableOpacity>

      {/* Options List */}
      {isOpen && (
        <View style={styles.optionsContainer}>
          {AVAILABLE_OPTIONS.map(item => (
            <TouchableOpacity
              key={item.id}
              style={styles.optionItem}
              onPress={() => handleAddVariant(item)}>
              <Text style={styles.optionText}>
                {item.label} ({item.size || item.id})
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* Chips Display */}
      <View style={styles.chipsContainer}>
        {variants.map(variant => (
          <VariantChip
            key={variant.id}
            variant={variant}
            onRemove={handleRemoveVariant}
          />
        ))}
      </View>
    </View>
  );
};

export default PriceVariantGroup;

// --- Styles ---
const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.white,
    padding: 16,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
    margin: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.black,
  },
  dropdown: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 6,
    backgroundColor: colors.white,
    marginBottom: 15,
  },
  dropdownText: {
    fontSize: 16,
    color: colors.black,
    fontWeight: '600',
  },
  optionsContainer: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 6,
    marginBottom: 10,
    maxHeight: 150,
    overflow: 'hidden',
  },
  optionItem: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.lightGray,
  },
  optionText: {
    fontSize: 14,
    color: colors.textPrimary,
  },
  chipsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
});

const tagStyles = StyleSheet.create({
  chipContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 15,
    marginRight: 8,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  chipText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.black,
    marginRight: 5,
  },
  deleteIcon: {
    padding: 2,
    borderRadius: 10,
  },
});
