import {
  StyleSheet,
  View,
  Image,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import React from 'react';

// --- Placeholder Icons (Replace with your actual paths) ---
// Note: In a real app, you'd need to pass these paths as props or import them here.
// For demonstration, I'm defining mock icon paths.
const SearchIcon = require('../../../assets/search_icon.png');
const FilterIcon = require('../../../assets/filter_icon.png'); // Assuming you have this
const ActiveFilterIcon = require('../../../assets/filter_fill.png'); // Assuming you have this

/**
 * Reusable Searchbar Component
 * @param {string} value - The current value of the search input.
 * @param {function} onChangeText - Handler for text changes (e.g., setSearchQuery).
 * @param {string} placeholder - Placeholder text for the input.
 * @param {function} openFilters - Handler to open the filters.
 * @param {boolean} isFilterVisible - State to determine which filter icon to show.
 */
const Searchbar = ({
  value,
  onChangeText,
  placeholder = 'Search Product or orders',
  openFilters,
  isFilterVisible,
}) => {
  return (
    <View style={styles.searchContainer}>
      <View style={styles.searchBox}>
        {/* Search Icon */}
        <Image
          source={SearchIcon} // Use the imported icon (mocked)
          style={styles.searchImage}
          resizeMode="contain"
        />
        {/* Text Input */}
        <TextInput
          placeholder={placeholder} // 🚀 Using the placeholder prop
          placeholderTextColor="#888"
          style={styles.searchInput}
          value={value} // 🚀 Using the value prop
          onChangeText={onChangeText} // 🚀 Using the onChangeText prop
        />
      </View>
      {/* Filter Button (Conditional rendering based on props) */}
      {openFilters && (
        <TouchableOpacity onPress={openFilters}>
          <Image
            source={isFilterVisible ? ActiveFilterIcon : FilterIcon}
            style={styles.filterImage}
            resizeMode="contain"
          />
        </TouchableOpacity>
      )}
    </View>
  );
};

export default Searchbar;

// --- STYLES (Adjecting your provided styles) ---
const styles = StyleSheet.create({
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffff',
    borderRadius: 8,
    borderColor: '#D7D7D7',
    borderWidth: 1,
    paddingHorizontal: 10,
  },
  searchImage: {
    width: 25,
    height: 25,
    marginStart: 5,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    color: '#000',
    fontSize: 12,
    // Add paddingVertical to help center text vertically, if needed
    paddingVertical: Platform.OS === 'ios' ? 10 : 8,
  },
  filterImage: {
    width: 50,
    height: 50,
    marginStart: 5,
    marginTop: 5,
  },
});
