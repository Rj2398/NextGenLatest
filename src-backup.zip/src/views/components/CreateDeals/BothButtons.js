// ../../components/CreateDeals/BothButtons.js (FINAL FIX: Primary -> Secondary)

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const Colors = {
    primaryOrange: '#FF8719', 
    white: '#fff',           
    borderColor: '#ddd',
    darkText: '#161B25',
};


const BothButtons = ({ actions, onActionClick }) => {
    if (!actions || actions.length === 0) {
        return null;
    }
    
    // --- FINAL FIX: Sorting Logic for Primary (Left) -> Secondary (Right) ---
    // 1. Primary buttons should have lower priority (value 0) to appear first in the array.
    // 2. Secondary buttons should have higher priority (value 1) to appear later in the array.
    const sortedActions = [...actions].sort((a, b) => {
        const priorityA = a.type === 'primary' ? 0 : 1; // Primary = 0
        const priorityB = b.type === 'primary' ? 0 : 1; // Secondary = 1
        return priorityA - priorityB; // This places Primary (0) before Secondary (1)
    });
    // ------------------------------------------------------------------------
    
    return (
        <View style={styles.buttonRow}>
            {sortedActions.map((action, index) => {
                const isPrimary = action.type === 'primary';
                
                return (
                    <TouchableOpacity 
                        key={action.buttonId || index} 
                        style={[
                            styles.buttonBase,
                            { 
                                // Margin handling: Add margin space after the button, except the last one
                                marginRight: index < sortedActions.length - 1 ? 10 : 0,
                            }, 
                            isPrimary ? styles.primaryButton : styles.secondaryButton
                        ]} 
                        onPress={() => onActionClick(action)}
                    >
                        <Text style={isPrimary ? styles.primaryButtonText : styles.secondaryButtonText}>
                            {action.label}
                        </Text>
                    </TouchableOpacity>
                );
            })}
        </View>
    );
};

const styles = StyleSheet.create({
    buttonRow: { 
        flexDirection: 'row', 
        justifyContent: 'flex-start', // Start from the left side (Primary will be here)
        marginTop: 20,
        paddingTop: 10,
        borderTopWidth: 1,
        borderTopColor: Colors.borderColor,
    },
    buttonBase: {
        flexGrow: 1, 
        minWidth: 120, 
        paddingVertical: 14,
        borderRadius: 8,
        alignItems: 'center',
    },
    // --- Primary (Leftmost) ---
    primaryButton: {
        backgroundColor: Colors.primaryOrange,
    },
    primaryButtonText: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.white,
    },
    // --- Secondary (Right of Primary) ---
    secondaryButton: {
        backgroundColor: Colors.white,
        borderWidth: 1,
        borderColor: Colors.borderColor,
    },
    secondaryButtonText: {
        fontSize: 16,
        fontWeight: '700',
        color: Colors.darkText,
    },
});

export default BothButtons;