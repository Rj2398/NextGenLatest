// components/DateTimePickerInput.js

import React, {useState, useMemo} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Platform,
  StyleSheet,
  Alert, // Used for showing warnings/errors if needed
} from 'react-native';

// ⚠️ IMPORTANT: You must install this library first!
// npx expo install @react-native-community/datetimepicker
// or
// yarn add @react-native-community/datetimepicker
import DateTimePicker from '@react-native-community/datetimepicker';

/**
 * Helper function to format the Date object into a readable string (e.g., Nov 07, 2025, 01:10 PM).
 * @param {Date} date - The date object to format.
 * @returns {string} The formatted date string.
 */
const formatDateTime = date => {
  if (!date || isNaN(date.getTime())) return '';

  // Use 'en-GB' locale for standard formatting and specific options
  const options = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true, // Use AM/PM format
  };
  // Note: toLocaleString is used here for simplicity in a demo, but you might
  // need a robust library like date-fns or Moment.js for production consistency.
  return date.toLocaleTimeString('en-GB', options);
};

/**
 * Custom DateTime Picker Input Component for React Native.
 * Renders a touchable text field that opens the native date/time picker on press.
 *
 * @param {string} label - The field label (e.g., 'Start Date*')
 * @param {Date | string} value - The current date/time (Date object or ISO string)
 * @param {function} onChange - Function called when the date/time is selected (receives Date object)
 * @param {string} mode - 'date', 'time', or 'datetime' (iOS only for 'datetime')
 * @param {boolean} isRequired - Whether the field is mandatory
 * @param {string} placeholder - Placeholder text
 */
const DateTimePickerInput = ({
  label,
  value,
  onChange,
  mode = 'date', // Default to date mode
  isRequired = false,
  placeholder = 'Select Date & Time',
}) => {
  const [showPicker, setShowPicker] = useState(false);
  const [currentMode, setCurrentMode] = useState(mode); // Used for Android's sequential 'datetime'

  // 1. Normalize the 'value' prop to a Date object
  const dateValue = useMemo(() => {
    if (value instanceof Date && !isNaN(value.getTime())) return value;
    if (typeof value === 'string' && value) {
      const date = new Date(value);
      return isNaN(date.getTime()) ? new Date() : date; // Fallback to current date if invalid string
    }
    return new Date(); // Default to current date/time
  }, [value]);

  // 2. Handler for the picker change event
  const handlePickerChange = (event, selectedDate) => {
    const isIOS = Platform.OS === 'ios';

    // Dismiss the picker automatically on Android after selection
    if (!isIOS) {
      setShowPicker(false);
    }

    // Check if the user confirmed selection (type 'set') or if it's iOS (where it's always open)
    if (event.type === 'set' || isIOS) {
      if (mode === 'datetime' && Platform.OS === 'android') {
        // Android requires two sequential pickers: 'date' then 'time'
        if (currentMode === 'date') {
          // Date selected, now open Time Picker
          setCurrentMode('time');
          setShowPicker(true);
          // Pass the selected date to the main onChange immediately
          onChange(selectedDate || dateValue); 
          return;
        } else if (currentMode === 'time') {
          // Time selected, reset mode and finish
          setCurrentMode('date'); 
          onChange(selectedDate || dateValue);
        }
      } else {
        // Single mode (date or time) or iOS 'datetime' mode
        if (selectedDate) {
          onChange(selectedDate);
        }
      }
    }
  };

  // 3. Function to open the picker
  const showDatePicker = () => {
    setShowPicker(true);
    // Always start with 'date' for Android multi-step selection
    if (Platform.OS === 'android' && mode === 'datetime') {
        setCurrentMode('date'); 
    } else {
        setCurrentMode(mode);
    }
  };

  const displayValue = formatDateTime(dateValue);
  const displayPlaceholder = displayValue || placeholder;

  return (
    <View style={styles.container}>
      {/* Label with required asterisk */}
      <Text style={styles.label}>
        {label}
        {isRequired && <Text style={styles.required}> *</Text>}
      </Text>

      {/* Display Input Field (Touchable) */}
      <TouchableOpacity
        onPress={showDatePicker}
        style={styles.inputContainer}>
        <Text
          style={[
            styles.inputText,
            !displayValue && styles.placeholderText,
          ]}>
          {displayPlaceholder}
        </Text>
      </TouchableOpacity>

      {/* DateTimePicker component */}
      {showPicker && (
        <DateTimePicker
          value={dateValue}
          // Use the internal currentMode for Android sequential logic
          mode={Platform.OS === 'ios' ? mode : currentMode} 
          is24Hour={false} // Use 12-hour format for consistency with display format
          display={Platform.OS === 'ios' ? 'spinner' : 'default'} // 'default' uses native system UI
          onChange={handlePickerChange}
        />
      )}
    </View>
  );
};

export default DateTimePickerInput;

const styles = StyleSheet.create({
  container: {
    marginBottom: 15,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 5,
  },
  required: {
    color: '#dc3545', // Red color for required asterisk
  },
  inputContainer: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    backgroundColor: '#fff',
    minHeight: 45,
    justifyContent: 'center',
  },
  inputText: {
    fontSize: 16,
    color: '#333',
  },
  placeholderText: {
    color: '#999',
  },
});