import React from 'react';
import {View, FlatList, StyleSheet, Text} from 'react-native';
import InventoryCard from './InventoryCard'; // ✅ import your card
import useDashboard from '../../hooks/useDashboard';
import {useNavigation} from '@react-navigation/native';

const InventoryListScreen = () => {
  const navigation = useNavigation();
  const {getInventoryList, isLoadingInventory} = useDashboard();
  console.log(getInventoryList, '****************');

  // ✅ Inventory Data (your provided list)
  // const inventoryList = [
  //   {
  //     id: 'bce8c2d7-1c40-4846-b0c8-61e83254c788',
  //     product_name: null,
  //     product_title: 'iPhone 15 Pro Max 256GB Titanium Natural',
  //     description:
  //       'The most advanced iPhone with titanium design, A17 Pro chip, and professional camera system.',
  //     product_image: null,
  //     category_id: '1',
  //     brand: 'Apple',
  //     subcategory_id: '1',
  //     open_stock: null,
  //     remaining_stock: null,
  //     threshold_value: null,
  //     weight: null,
  //     price: null,
  //   },
  //   {
  //     id: '667af666-be14-42d9-8162-4f3074a95628',
  //     product_name: null,
  //     product_title: 'MacBook Pro 16-inch M3 Pro Chip',
  //     description:
  //       'Powerful laptop with M3 Pro chip, 16-inch Liquid Retina XDR display, and all-day battery life.',
  //     product_image: null,
  //     category_id: '4',
  //     brand: 'Apple',
  //     subcategory_id: '7',
  //     open_stock: null,
  //     remaining_stock: null,
  //     threshold_value: null,
  //     weight: null,
  //     price: null,
  //   },
  //   {
  //     id: '5328495d-cce0-4306-83fb-268fa8431a38',
  //     product_name: null,
  //     product_title: 'Nike Air Max 90 White Leather Running Shoes',
  //     description:
  //       'Classic running shoe with Air Max cushioning and timeless design.',
  //     product_image: null,
  //     category_id: '2',
  //     brand: 'Nike',
  //     subcategory_id: '3',
  //     open_stock: null,
  //     remaining_stock: null,
  //     threshold_value: null,
  //     weight: null,
  //     price: null,
  //   },
  //   {
  //     id: 'c0fb94bc-45bc-40ba-8a5b-4688d736d6b0',
  //     product_name: null,
  //     product_title: 'Samsung Galaxy S24 Ultra 512GB Titanium Black',
  //     description:
  //       'Ultimate Android smartphone with S Pen, AI-powered camera, and titanium frame.',
  //     product_image: null,
  //     category_id: '1',
  //     brand: 'Samsung',
  //     subcategory_id: '1',
  //     open_stock: null,
  //     remaining_stock: null,
  //     threshold_value: null,
  //     weight: null,
  //     price: null,
  //   },
  //   {
  //     id: '61570f90-03b2-43b2-b9e4-568936f3a7b1',
  //     product_name: null,
  //     product_title: 'Sony WH-1000XM5 Wireless Noise Cancelling Headphones',
  //     description:
  //       'Premium wireless headphones with industry-leading noise cancellation technology.',
  //     product_image: null,
  //     category_id: '3',
  //     brand: 'Sony',
  //     subcategory_id: '5',
  //     open_stock: null,
  //     remaining_stock: null,
  //     threshold_value: null,
  //     weight: null,
  //     price: null,
  //   },
  // ];

  // ✅ Event handlers
  const handleEdit = item => {
    navigation.navigate('AddNewProduct', {item});
  };
  const handleDelete = item => console.log('Delete:', item.product_title);

  const handleViewDetails = item => {
    // Pass the full dynamic data object
    navigation.navigate('InventoryScreen', {item});
  };

  const renderItem = ({item}) => (
    <InventoryCard
      item={item}
      onEdit={handleEdit}
      onDelete={handleDelete}
      onViewDetails={handleViewDetails}
    />
  );

  return (
    <View style={styles.container}>
      {getInventoryList?.items?.length > 0 ? (
        <FlatList
          data={getInventoryList?.items}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <Text style={styles.noDataText}>No inventory items found.</Text>
      )}
    </View>
  );
};

export default InventoryListScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  scrollContent: {
    padding: 16,
  },
  noDataText: {
    textAlign: 'center',
    marginTop: 50,
    fontSize: 16,
    color: '#6B7280',
  },
});
