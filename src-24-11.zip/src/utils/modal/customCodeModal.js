// utils/formatDisplayFields.js
// export const formatDisplayFields = (item, fieldLabelMap = {}, options = {}) => {
//   if (!item || typeof item !== 'object') return [];

//   const {
//     exclude = ['product_image', 'order_date', 'payment_method', 'total_amount'],
//     formatters = {}, // optional: field-specific formatters
//   } = options;

//   const result = [];

//   for (const key in item) {
//     if (!item.hasOwnProperty(key)) continue;
//     if (exclude.includes(key)) continue;

//     const value = item[key];
//     const label = fieldLabelMap[key];

//     if (value === null || value === undefined || value === '' || !label)
//       continue;

//     const formattedValue =
//       typeof formatters[key] === 'function'
//         ? formatters[key](value, item)
//         : value;

//     result.push({label, value: formattedValue});
//   }

//   return result;
// };

export const formatDisplayFields = (item, fieldLabelMap = {}, options = {}) => {
  if (!item || typeof item !== 'object') return [];

  const {exclude = [], formatters = {}} = options; // empty exclude

  const result = [];

  for (const key in item) {
    if (!item.hasOwnProperty(key)) continue;
    if (exclude.includes(key)) continue;

    const value = item[key];
    const label = fieldLabelMap[key];

    if (value === null || value === undefined || value === '' || !label)
      continue;

    const formattedValue =
      typeof formatters[key] === 'function'
        ? formatters[key](value, item)
        : value;

    result.push({label, value: formattedValue});
  }

  return result;
};

/**
 * Extracts a map of fieldName => localized label from an API schema.
 *
 * Example:
 * schema.pages[0].sections[0].fields[] → { product_name: "Product Name", quantity: "Quantity" }
 */
export const extractFieldLabelMap = schema => {
  const map = {};

  if (!schema || typeof schema !== 'object') return map;

  const pages = schema.pages || [];
  pages.forEach(page => {
    (page.sections || []).forEach(section => {
      (section.fields || []).forEach(field => {
        const key = field.fieldName;
        const label =
          field.localization?.localizedText ||
          field.label ||
          field.placeholder ||
          key;
        if (key) map[key] = label;
      });
    });
  });

  return map;
};
