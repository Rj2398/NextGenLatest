import React, {useMemo, useState} from 'react';
import {View, FlatList, StyleSheet, Text} from 'react-native';
import InventoryCard from './InventoryCard'; // ✅ import your card
import useDashboard from '../../hooks/useDashboard';
import {useNavigation} from '@react-navigation/native';
import {extractFieldLabelMap} from '../../utils/modal/customCodeModal';
import Loader from './Loader';
import {fetchChildCategories} from '../../utils/apiFunction';

const InventoryListScreen = () => {
  const navigation = useNavigation();
  const [productDetails, setProductDetails] = useState(null);
  const {getInventoryList, isLoadingInventory} = useDashboard();
  const [loadingItemId, setLoadingItemId] = useState(null);
  const fetchData = async item => {
    const productId = item?.id;
    if (!productId) return;

    // A. START LOADING: Set the ID of the item being loaded
    setLoadingItemId(productId);

    try {
      const response = await fetchChildCategories(
        '/api/v1/Products',
        productId,
        'ProductId',
      );
      console.log(response?.data, 'product details');
      setProductDetails(response.data?.items);
      navigation.navigate('InventoryScreen', {item: response?.data?.items});
    } catch (error) {
      console.error('Failed to fetch product details:', error);
    } finally {
      // C. STOP LOADING: Reset the loading state after API call completes (success or failure)
      setLoadingItemId(null);
    }
  };

  // ✅ Event handlers
  const handleEdit = item => {
    navigation.navigate('AddNewProduct', {item});
  };
  const handleDelete = item => console.log('Delete:', item.product_title);

  const handleViewDetails = item => {
    if (item.id) {
      fetchData(item);
    }
  };

  const renderItem = ({item}) => (
    <InventoryCard
      item={item}
      onEdit={handleEdit}
      onDelete={handleDelete}
      onViewDetails={handleViewDetails}
      isLoading={item.id === loadingItemId}
    />
  );

  return (
    <View style={styles.container}>
      <Loader visible={isLoadingInventory} />
      {getInventoryList?.items?.length > 0 ? (
        <FlatList
          data={getInventoryList?.items}
          keyExtractor={item => item.id}
          renderItem={renderItem}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <Text style={styles.noDataText}>No inventory items found.</Text>
      )}
    </View>
  );
};

export default InventoryListScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  scrollContent: {
    padding: 16,
  },
  noDataText: {
    textAlign: 'center',
    marginTop: 50,
    fontSize: 16,
    color: '#6B7280',
  },
});
