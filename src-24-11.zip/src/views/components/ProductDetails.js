import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Image,
  Dimensions,
} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';

// 🔸 Static colors
const PRIMARY_COLOR = '#f97316'; // Orange accent
const SECONDARY_COLOR = '#f3f4f6'; // Light gray background
const CARD_BG = '#ffffff'; // White card background
const DARK_TEXT = '#1f2937';
const GRAY_TEXT = '#000000';

const {width} = Dimensions.get('window');

const ProductDetails = ({item}) => {
  const [showVariants, setShowVariants] = useState(false);

  // 🔸 Render a single card (used for both main and variant)
  const renderProductCard = (product, isVariant = false) => (
    <View
      key={product.id}
      style={[
        styles.card,
        isVariant && {backgroundColor: '#f9fafb', marginTop: 8},
      ]}>
      <View style={styles.topSection}>
        {/* LEFT CONTENT */}
        <View style={{flex: 1, paddingRight: 12}}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>{product.name}</Text>

            {/* <View
              style={{
                width: 24,
                height: 24,
                borderRadius: 12,
                backgroundColor: `#${product.color}`,
                borderWidth: 1,
                borderColor: '#e5e7eb',
              }}
            /> */}
          </View>

          <View style={styles.detailsGrid}>
            <View style={styles.detailItemContainer}>
              <Text style={styles.detailItemLabel}>Open Stock</Text>
              <Text style={styles.detailItemValue}>{product.openStock}</Text>
            </View>
            <View style={styles.detailItemContainer}>
              <Text style={styles.detailItemLabel}>Remaining Stock</Text>
              <Text style={styles.detailItemValue}>
                {product.remainingStock}
              </Text>
            </View>
            <View style={styles.detailItemContainer}>
              <Text style={styles.detailItemLabel}>Threshold</Text>
              <Text style={styles.detailItemValue}>{product.threshold}</Text>
            </View>
            <View style={styles.detailItemContainer}>
              <Text style={styles.detailItemLabel}>On The Way</Text>
              <Text style={styles.detailItemValue}>{product.onTheWay}</Text>
            </View>
            <View style={styles.detailItemContainer}>
              <Text style={styles.detailItemLabel}>SP</Text>
              <Text style={styles.detailItemValue}>₹{product.sp}</Text>
            </View>
            <View style={styles.detailItemContainer}>
              <Text style={styles.detailItemLabel}>Weight</Text>
              <Text style={styles.detailItemValue}>{product.weight}</Text>
            </View>
          </View>
        </View>

        {/* RIGHT IMAGE */}
        <Image
          source={require('../../assets/images/ic_maggi.png')}
          style={styles.productImage}
          resizeMode="contain"
        />
      </View>

      {/* 🔹 Actions */}
      <View style={styles.actionButtonsContainer}>
        <TouchableOpacity style={[styles.button, styles.editButton]}>
          <Image
            source={require('../../assets/images/ic_edit_button.png')}
            style={{width: 20, height: 20, marginRight: 6}}
          />
          <Text style={styles.editButtonText}>Edit Item</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.button, styles.deleteButton]}>
          <Image
            source={require('../../assets/images/ic_delete_icon.png')}
            style={{width: 20, height: 20, marginRight: 6}}
          />
          <Text style={styles.deleteButtonText}>Delete Item</Text>
        </TouchableOpacity>
      </View>

      {/* 🔸 Variant toggle */}
      {!isVariant && (
        <TouchableOpacity
          onPress={() => setShowVariants(prev => !prev)}
          style={styles.viewMoreButton}>
          <Text style={styles.viewMoreText}>
            {showVariants ? 'Hide Product Variants' : 'Product Variants'}
          </Text>
          <Feather
            name={showVariants ? 'chevron-up' : 'chevron-down'}
            size={18}
            color="#000"
            style={{marginLeft: 6}}
          />
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <View>
      {/* 🔹 Main Product */}
      {renderProductCard(item)}

      {/* 🔹 Variants */}
      {showVariants && item.product_varient?.length > 0 && (
        <FlatList
          data={item.product_varient}
          keyExtractor={(v, i) => `${v.id}-${i}`}
          renderItem={({item}) => renderProductCard(item, true)}
          contentContainerStyle={{paddingTop: 8}}
        />
      )}
    </View>
  );
};

export default ProductDetails;

const {width: screenWidth} = Dimensions.get('window');

const styles = StyleSheet.create({
  card: {
    backgroundColor: CARD_BG,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  topSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'stretch',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  productImage: {
    width: 100,
    height: '100%',
    borderRadius: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: DARK_TEXT,
    flex: 1,
    paddingRight: 10,
  },
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  detailItemContainer: {
    width: screenWidth > 400 ? '33.333%' : '50%',
    marginBottom: 8,
    paddingRight: 8,
  },
  detailItemLabel: {
    fontSize: 12,
    color: GRAY_TEXT,
    marginBottom: 2,
  },
  detailItemValue: {
    fontSize: 14,
    fontWeight: '600',
    color: DARK_TEXT,
  },
  viewMoreButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    backgroundColor: SECONDARY_COLOR,
    borderRadius: 8,
    marginTop: 8,
    flexDirection: 'row',
  },
  viewMoreText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000000',
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    marginTop: 4,
  },
  button: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
    paddingVertical: 12,
    height: 48,
    marginHorizontal: 4,
  },
  editButton: {
    backgroundColor: PRIMARY_COLOR,
    shadowColor: PRIMARY_COLOR,
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 3,
  },
  editButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: CARD_BG,
  },
  deleteButton: {
    backgroundColor: SECONDARY_COLOR,
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  deleteButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000000',
  },
});
