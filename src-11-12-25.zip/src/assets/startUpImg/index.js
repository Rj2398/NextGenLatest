// Importing images from the assets directory
import BackgroundRectImg from './png/backgroundRectImg.png';
import BackgroundRectImgBg from './png/backgroundRectImgBg.png';
import OnBoarding1 from './png/onBoarding1.png';
import OnBoarding2 from './png/onBoarding2.png';
import OnBoarding3 from './png/onBoarding3.png';
import OnBoarding4 from './png/onBoarding4.png';
import OnBoarding5 from './png/onBoarding5.png';
import UserLogo from './png/user_logo.png';
import InstituteLogo from './png/InstituteLogo.png';
import MerchantLogo from './png/merchant_logo.png';

// SVG imports
import Logo from './svg/logo.svg';
import InstituteIcon from './svg/instituteIcon.svg';
import UserIcon from './svg/userIcon.svg';
import MerchantIcon from './svg/merchantIcon.svg';
import WelcomeImg from './svg/welcomeImg.svg';
import MailIcon from './svg/mailIcon.svg';
import TickIcon from './svg/tick.svg';
import GpsIcon from './svg/gpsIcon.svg';
import UploadIcon from './svg/backupIcon.svg';
import CloseIcon from './svg/closeIcon.svg';

export {
  Logo,
  BackgroundRectImg,
  BackgroundRectImgBg,
  InstituteIcon,
  UserIcon,
  MerchantIcon,
  WelcomeImg,
  OnBoarding1,
  OnBoarding2,
  OnBoarding3,
  OnBoarding4,
  OnBoarding5,
  MailIcon,
  TickIcon,
  GpsIcon,
  UploadIcon,
  CloseIcon,
  UserLogo,
  InstituteLogo,
  MerchantLogo,
};
