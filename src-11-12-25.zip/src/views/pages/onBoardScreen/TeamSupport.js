import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Platform,
  Image,
} from 'react-native';
import React, {useState} from 'react';

// Icon imports
import AntDesign from 'react-native-vector-icons/AntDesign';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';

// --- Constants ---
const PRIMARY_COLOR = '#FF7A00';
const BORDER_COLOR = '#E0E0E0';
const TEXT_GRAY = '#666666';
const LIGHT_GRAY_BG = '#F7F7F7';
const ROLE_COLORS = {
  Admin: '#F44336', // Red
  Manager: '#2196F3', // Blue
  Operator: '#4CAF50', // Green
};

// --- Dummy Data ---
const TEAM_MEMBERS = [
  {
    id: 1,
    name: 'Sarah Johnson',
    role: 'Admin',
    department: 'Engineering',
    email: 'sarah.johnson@academia.edu',
    status: 'online', // for the little green/yellow dot
    avatarUrl: 'https://i.pravatar.cc/150?img=3', // Placeholder image URL
  },
  {
    id: 2,
    name: 'Michael Chen',
    role: 'Manager',
    department: 'Computer Science',
    email: 'michael.chen@academia.edu',
    status: 'online',
    avatarUrl: 'https://i.pravatar.cc/150?img=5',
  },
  {
    id: 3,
    name: 'Emma Rodriquez',
    role: 'Operator',
    department: 'Mathematics',
    email: 'emma.rodriguez@academia.edu',
    status: 'online',
    avatarUrl: 'https://i.pravatar.cc/150?img=8',
  },
  {
    id: 4,
    name: 'David Park',
    role: 'Operator',
    department: 'Physics',
    email: 'david.park@academia.edu',
    status: 'busy',
    avatarUrl: 'https://i.pravatar.cc/150?img=15',
  },
  {
    id: 5,
    name: 'Lisa Thompson',
    role: 'Manager',
    department: 'Biology',
    email: 'lisa.thompson@academia.edu',
    status: 'online',
    avatarUrl: 'https://i.pravatar.cc/150?img=17',
  },
  {
    id: 6,
    name: 'James Wilson',
    role: 'Operator',
    department: 'Chemistry',
    email: 'james.wilson@academia.edu',
    status: 'busy',
    avatarUrl: 'https://i.pravatar.cc/150?img=22',
  },
  {
    id: 7,
    name: 'Robert Garcia',
    role: 'Operator',
    department: 'History',
    email: 'robert.garcia@academia.edu',
    status: 'online',
    avatarUrl: 'https://i.pravatar.cc/150?img=25',
  },
  {
    id: 8,
    name: 'Alex Kumar',
    role: 'Operator',
    department: 'Art & Design',
    email: 'alex.kumar@academia.edu',
    status: 'busy',
    avatarUrl: 'https://i.pravatar.cc/150?img=33',
  },
];

const FILTER_TABS = [
  {key: 'All', label: 'All', count: TEAM_MEMBERS.length},
  {key: 'Active', label: 'Active', count: 18},
  {key: 'Invited', label: 'Invited', count: 4},
  {key: 'Suspended', label: 'Suspended', count: 0},
];

// --- Sub-Components ---

// Component for a single team member row
const TeamMemberItem = ({member}) => {
  const roleColor = ROLE_COLORS[member.role] || TEXT_GRAY;
  const statusColor =
    member.status === 'online' ? ROLE_COLORS.Operator : PRIMARY_COLOR; // Green for online, Yellow/Orange for busy

  return (
    <TouchableOpacity style={styles.memberCard}>
      <View style={styles.avatarContainer}>
        <Image source={{uri: member.avatarUrl}} style={styles.avatar} />
        {/* Status dot */}
        <View style={[styles.statusDot, {backgroundColor: statusColor}]} />
      </View>

      <View style={styles.memberDetails}>
        <View style={styles.nameRow}>
          <Text style={styles.memberName}>{member.name}</Text>
          <View style={styles.roleTag}>
            <Text style={[styles.roleText, {color: roleColor}]}>
              {member.role}
            </Text>
          </View>
          {/* Small status indicator next to role */}
          <View
            style={[styles.statusDotSmall, {backgroundColor: statusColor}]}
          />
        </View>

        <Text style={styles.memberDepartment}>{member.department}</Text>
        <Text style={styles.memberEmail}>{member.email}</Text>
      </View>

      <TouchableOpacity
        onPress={() => console.log('Options for:', member.name)}>
        <Feather name="more-vertical" size={24} color={TEXT_GRAY} />
      </TouchableOpacity>
    </TouchableOpacity>
  );
};

// Component for the horizontal filter tabs
const FilterTab = ({label, count, isSelected, onPress}) => (
  <TouchableOpacity
    style={[
      styles.filterTab,
      isSelected ? styles.filterTabSelected : styles.filterTabDefault,
    ]}
    onPress={onPress}>
    <Text
      style={[
        styles.filterText,
        isSelected ? styles.filterTextSelected : styles.filterTextDefault,
      ]}>
      {label} {count > 0 && <Text style={styles.filterCount}>{count}</Text>}
    </Text>
  </TouchableOpacity>
);

// --- Main Screen Component ---
const TeamSupport = ({navigation}) => {
  const [searchText, setSearchText] = useState('');
  const [selectedTab, setSelectedTab] = useState('All');

  const filteredMembers = TEAM_MEMBERS.filter(
    member =>
      member.name.toLowerCase().includes(searchText.toLowerCase()) ||
      member.department.toLowerCase().includes(searchText.toLowerCase()) ||
      member.role.toLowerCase().includes(searchText.toLowerCase()),
  );

  // Apply tab filtering here if actual active/invited status was in the TEAM_MEMBERS data.
  // For this example, we just filter by search text for simplicity.

  return (
    <View style={styles.fullContainer}>
      {/* --- Fixed Header --- */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}
          style={styles.backButton}>
          <AntDesign name="left" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Teams</Text>
        <View style={styles.headerIcons}>
          <Ionicons
            name="notifications-outline"
            size={24}
            color="#333"
            style={{marginRight: 10}}
          />
          <Image
            source={{uri: TEAM_MEMBERS[0].avatarUrl}}
            style={styles.headerAvatar}
          />
        </View>
      </View>

      {/* --- Scrollable Content Container --- */}
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* --- Search and Filter Bar --- */}
        <View style={styles.searchFilterContainer}>
          <View style={styles.searchBar}>
            <Feather name="search" size={20} color={TEXT_GRAY} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search name, role, department or email"
              placeholderTextColor={TEXT_GRAY}
              value={searchText}
              onChangeText={setSearchText}
            />
            <TouchableOpacity onPress={() => console.log('Filter clicked')}>
              <Ionicons name="filter-outline" size={24} color={TEXT_GRAY} />
            </TouchableOpacity>
          </View>
        </View>

        {/* --- Filter Tabs --- */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.tabScroll}>
          {FILTER_TABS.map(tab => (
            <FilterTab
              key={tab.key}
              label={tab.label}
              count={tab.count}
              isSelected={selectedTab === tab.key}
              onPress={() => setSelectedTab(tab.key)}
            />
          ))}
        </ScrollView>

        {/* --- Team Members List --- */}
        <View style={styles.memberList}>
          {filteredMembers.map(member => (
            <TeamMemberItem key={member.id} member={member} />
          ))}
        </View>

        {/* Spacer for FAB */}
        <View style={{height: 100}} />
      </ScrollView>

      {/* --- Floating Action Button (FAB) --- */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => navigation.navigate('CreateOperat')}>
        <AntDesign name="plus" size={28} color="white" />
      </TouchableOpacity>
    </View>
  );
};

export default TeamSupport;

// --- Stylesheet ---
const styles = StyleSheet.create({
  fullContainer: {
    flex: 1,
    backgroundColor: LIGHT_GRAY_BG,
  },
  // --- Header Styles ---
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 15,
    backgroundColor: 'white',
    paddingTop: Platform.OS === 'ios' ? 50 : 15,
    borderBottomWidth: 1,
    borderBottomColor: BORDER_COLOR,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  backButton: {
    padding: 5,
  },
  headerIcons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: PRIMARY_COLOR,
  },
  scrollContent: {
    paddingTop: 10,
    paddingHorizontal: 15,
  },
  // --- Search and Filter ---
  searchFilterContainer: {
    marginBottom: 10,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 10,
    paddingHorizontal: 15,
    height: 50,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: '#333',
    paddingHorizontal: 10,
    paddingVertical: 0,
  },
  // --- Filter Tabs ---
  tabScroll: {
    marginBottom: 15,
  },
  filterTab: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 10,
  },
  filterTabDefault: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: BORDER_COLOR,
  },
  filterTabSelected: {
    backgroundColor: PRIMARY_COLOR,
    borderWidth: 1,
    borderColor: PRIMARY_COLOR,
  },
  filterText: {
    fontSize: 14,
    fontWeight: '600',
  },
  filterTextDefault: {
    color: TEXT_GRAY,
  },
  filterTextSelected: {
    color: 'white',
  },
  filterCount: {
    fontWeight: 'bold',
  },
  // --- Member List ---
  memberList: {},
  memberCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
  },
  avatarContainer: {
    marginRight: 15,
    position: 'relative',
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  statusDot: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: 'white',
  },
  memberDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  memberName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginRight: 8,
  },
  roleTag: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    backgroundColor: LIGHT_GRAY_BG,
    marginRight: 5,
  },
  roleText: {
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  statusDotSmall: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  memberDepartment: {
    fontSize: 13,
    color: TEXT_GRAY,
    marginBottom: 2,
  },
  memberEmail: {
    fontSize: 12,
    color: TEXT_GRAY,
  },
  // --- Floating Action Button (FAB) ---
  fab: {
    position: 'absolute',
    width: 60,
    height: 60,
    alignItems: 'center',
    justifyContent: 'center',
    right: 20,
    bottom: 30,
    backgroundColor: PRIMARY_COLOR,
    borderRadius: 30,
    elevation: 4, // Android shadow
    shadowColor: '#000', // iOS shadow
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
});
