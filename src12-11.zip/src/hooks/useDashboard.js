import {useState} from 'react';
import {useDispatch} from 'react-redux';
import {useMutation, useQuery} from '@tanstack/react-query';
import {api} from '../utils/api';

export default function useDashboard() {
  const dispatch = useDispatch();
  const [manualLoading, setManualLoading] = useState(false);

  const {data: getDashboardList, isLoading: isLoadingDashboard} = useQuery({
    queryKey: ['Products/dashboard-kpis', 'user'],
    queryFn: async () => {
      try {
        const response = await api.get('Products/dashboard-kpis');
        const {data} = response;
        return data.data;
      } catch (error) {
        const errorMessage =
          error?.response?.data?.message ||
          error.message ||
          'An unknown error occurred';

        if (error?.response?.data?.message === 'Unauthenticated.') {
          LogoutError();
        }

        toast.error(errorMessage);
        throw new Error(errorMessage);
      }
    },
    staleTime: 1000 * 60 * 5,
    cacheTime: 1000 * 60 * 10,
    refetchOnWindowFocus: false,
  });
  //

  //

  const {data: getStuctDashboard, isLoading: isLoadignStuctDashboard} =
    useQuery({
      queryKey: ['PageGroup/Inventory_Dashboard', 'user'],
      queryFn: async () => {
        try {
          const response = await api.get('PageGroup/Inventory_Dashboard');
          const {data} = response;
          return data.data;
        } catch (error) {
          const errorMessage =
            error?.response?.data?.message ||
            error.message ||
            'An unknown error occurred';

          if (error?.response?.data?.message === 'Unauthenticated.') {
            LogoutError();
          }

          toast.error(errorMessage);
          throw new Error(errorMessage);
        }
      },
      staleTime: 1000 * 60 * 5,
      cacheTime: 1000 * 60 * 10,
      refetchOnWindowFocus: false,
    });

  //

  const isLoading = manualLoading;

  return {
    getDashboardList,
    isLoadingDashboard,
    getStuctDashboard,
    isLoadignStuctDashboard,
  };
}
