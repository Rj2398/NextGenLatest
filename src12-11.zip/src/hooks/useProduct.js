import {useState} from 'react';
import {useDispatch} from 'react-redux';
import {useMutation, useQuery} from '@tanstack/react-query';
import {api} from '../utils/api';

export default function useProductModal() {
  const dispatch = useDispatch();
  const [manualLoading, setManualLoading] = useState(false);

  const {data: getAllProductModal, isLoading: isLoadinAllModal} = useQuery({
    queryKey: ['PageGroup/Ecommerce_Product', 'user'],
    queryFn: async () => {
      try {
        const response = await api.get('PageGroup/Ecommerce_Product');
        const {data} = response;
        return data.data;
      } catch (error) {
        const errorMessage =
          error?.response?.data?.message ||
          error.message ||
          'An unknown error occurred';

        if (error?.response?.data?.message === 'Unauthenticated.') {
          LogoutError();
        }

        toast.error(errorMessage);
        throw new Error(errorMessage);
      }
    },
    staleTime: 1000 * 60 * 5,
    cacheTime: 1000 * 60 * 10,
    refetchOnWindowFocus: false,
  });
  //
  const {data: getCategory, isLoading: loadingCategory} = useQuery({
    queryKey: ['Category', 'user'],
    queryFn: async () => {
      try {
        const response = await api.get('Category');
        const {data} = response;
        return data.data;
      } catch (error) {
        const errorMessage =
          error?.response?.data?.message ||
          error.message ||
          'An unknown error occurred';

        if (error?.response?.data?.message === 'Unauthenticated.') {
          LogoutError();
        }

        toast.error(errorMessage);
        throw new Error(errorMessage);
      }
    },
    staleTime: 1000 * 60 * 5,
    cacheTime: 1000 * 60 * 10,
    refetchOnWindowFocus: false,
  });

  //get product

  const {data: getProducts, isLoading: isLoadingProducts} = useQuery({
    queryKey: ['Products', 'Academia'],
    queryFn: async () => {
      try {
        const response = await api.get('Products');
        const {data} = response;
        return data.data;
      } catch (error) {
        const errorMessage =
          error?.response?.data?.message ||
          error.message ||
          'An unknown error occurred';

        if (error?.response?.data?.message === 'Unauthenticated.') {
          LogoutError();
        }

        toast.error(errorMessage);
        throw new Error(errorMessage);
      }
    },
    staleTime: 1000 * 60 * 5,
    cacheTime: 1000 * 60 * 10,
    refetchOnWindowFocus: false,
  });

  const fetchCategoriesByParentId = async parentId => {
    // Determine the base URL
    let url = 'Category';

    // Construct the URL dynamically based on parentId
    if (parentId) {
      // Ensure parentId is safe for URL embedding
      url = `Category?parentId=${parentId}`;
    }

    try {
      // Assuming 'api' is an axios instance or similar client available here
      const response = await api.get(url);
      return response.data;
    } catch (error) {
      // *** IMPORTANT: Keep error handling simple for a reusable function ***
      // Throw the error so React Query/calling function can catch it
      throw error;
    }
  };

  //

  const {mutateAsync: basicInformation} = useMutation({
    mutationKey: ['basicInformation', 'user'],
    mutationFn: async payload => {
      try {
        setManualLoading(true);
        const response = await api.post('Products/complete', payload);

        const {data} = response;

        return {
          ...data,
          message: data?.message,
        };
      } catch (error) {
        const errorMessage = error.message || 'An unknown error occurred';
        throw new Error(errorMessage);
      } finally {
        setManualLoading(false);
      }
    },
  });
  //

  const {mutateAsync: productVariantApi} = useMutation({
    mutationKey: ['productVariantApi', 'user'],
    mutationFn: async payload => {
      try {
        setManualLoading(true);
        const response = await api.post('Products/variants', payload);

        const {data} = response;

        return {
          ...data,
          message: data?.message,
        };
      } catch (error) {
        const errorMessage = error.message || 'An unknown error occurred';
        throw new Error(errorMessage);
      } finally {
        setManualLoading(false);
      }
    },
  });

  const {mutateAsync: productDetailapi} = useMutation({
    mutationKey: ['productDetailapi', 'user'],
    mutationFn: async payload => {
      try {
        setManualLoading(true);
        const response = await api.post('Products/details', payload);

        const {data} = response;

        return {
          ...data,
          message: data?.message,
        };
      } catch (error) {
        const errorMessage = error.message || 'An unknown error occurred';
        throw new Error(errorMessage);
      } finally {
        setManualLoading(false);
      }
    },
  });

  const {mutateAsync: ProductsCompliance} = useMutation({
    mutationKey: ['ProductsCompliance', 'user'],
    mutationFn: async payload => {
      try {
        setManualLoading(true);
        const response = await api.post('Products/details', payload);

        const {data} = response;

        return {
          ...data,
          message: data?.message,
        };
      } catch (error) {
        const errorMessage = error.message || 'An unknown error occurred';
        throw new Error(errorMessage);
      } finally {
        setManualLoading(false);
      }
    },
  });
  const isLoading = manualLoading;

  return {
    getAllProductModal,
    isLoadinAllModal,
    isLoading,
    basicInformation,
    productVariantApi,
    productDetailapi,
    ProductsCompliance,
    getCategory,
    loadingCategory,
    fetchCategoriesByParentId,
    getProducts,
    isLoadingProducts,
  };
}
