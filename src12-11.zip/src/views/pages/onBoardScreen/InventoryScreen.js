// import React, { useState } from 'react';
// import { StyleSheet, View, Text, TouchableOpacity, TextInput, ScrollView, Image, Dimensions } from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';

import React, {useState} from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Image,
  Dimensions,
} from 'react-native';

// Get screen width for responsive sizing
const {width} = Dimensions.get('window');

// --- Theme Constants (matching the design's colors)
const PRIMARY_COLOR = '#f97316'; // Orange accent
const SECONDARY_COLOR = '#f3f4f6'; // Light gray background
const CARD_BG = '#ffffff'; // White card background
const DARK_TEXT = '#1f2937';
const GRAY_TEXT = '#000000';

// --- Reusable Component for a single item detail (e.g., Open Stock: 40)
const DetailItem = ({label, value}) => (
  <View style={styles.detailItemContainer}>
    <Text style={styles.detailItemLabel}>{label}</Text>
    <Text style={styles.detailItemValue}>{value}</Text>
  </View>
);

// --- The main Inventory Card Component (for Overview tab)
const InventoryCard = ({item}) => {
  const [showDetails, setShowDetails] = useState(false);

  // Function to create a placeholder image URL
  const getPlaceholderUrl = text =>
    `https://placehold.co/100x100/${
      item.color
    }/ffffff?text=${encodeURIComponent(text.substring(0, 4).toUpperCase())}`;

  return (
    <View style={styles.card}>
      {/* Title and Image Header */}
      <View style={styles.cardHeader}>
        <Text style={styles.cardTitle}>{item.name}</Text>
        <Image
          source={require('../../../assets/images/ic_maggi.png')}
          style={styles.productImage}
        />
      </View>

      {/* Details Grid (Open Stock, SP, Weight, etc.) */}
      <View style={styles.detailsGrid}>
        <DetailItem label="Open Stock" value={item.openStock} />
        <DetailItem label="Rem. Stock" value={item.remainingStock} />
        <DetailItem label="Threshold value" value={item.threshold} />
        <DetailItem label="On the way" value={item.onTheWay} />
        <DetailItem label="SP" value={item.sp} />
        <DetailItem label="Weight" value={item.weight} />
      </View>

      {/* Action Buttons */}
      <View style={styles.actionButtonsContainer}>
        <TouchableOpacity style={[styles.button, styles.editButton]}>
          {/* <Text style={styles.editButtonText}>✏️ Edit Item</Text> */}
          <Image
            source={require('../../../assets/images/ic_edit_button.png')} // your custom edit icon path
            style={{width: 20, height: 20}}
          />
          <Text style={styles.editButtonText}>Edit Item</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.deleteButton]}>
          {/* <Text style={styles.deleteButtonText}>🗑️ Delete Item</Text> */}

          <Image
            source={require('../../../assets/images/ic_delete_icon.png')} // your custom edit icon path
            style={{width: 20, height: 20}}
          />
          <Text style={styles.deleteButtonText}>Delete Item</Text>
        </TouchableOpacity>
      </View>

      {/* View More Details Dropdown */}
      <TouchableOpacity
        style={styles.viewMoreButton}
        onPress={() => setShowDetails(!showDetails)}>
        <Text style={styles.viewMoreText}>View More Details</Text>
        <Image
          source={require('../../../assets/images/ic_drop_down_black.png')} // ✅ folder name should be "assets"
          style={{width: 12, height: 12, resizeMode: 'contain', marginLeft: 12}} // ✅ commas inside one object
        />
      </TouchableOpacity>

      {/* Conditional Details (Hidden by default) */}
      {showDetails && (
        <View style={styles.expandedDetails}>
          <Text style={styles.expandedDetailsText}>
            <Text style={{fontWeight: 'bold'}}>Last Restock:</Text> 2 days ago
            (Qty: 50)
          </Text>
          <Text style={styles.expandedDetailsText}>
            <Text style={{fontWeight: 'bold'}}>Supplier:</Text> XYZ Distributors
          </Text>
          <Text style={styles.expandedDetailsText}>
            <Text style={{fontWeight: 'bold'}}>Location:</Text> Aisle 3, Shelf B
          </Text>
        </View>
      )}
    </View>
  );
};

// --- Purchase Order Card Component (for Purchase tab)
const PurchaseOrderCard = ({item}) => {
  // Function to create a placeholder image URL
  const getPlaceholderUrl = text =>
    `https://placehold.co/100x100/${
      item.color
    }/ffffff?text=${encodeURIComponent(text.substring(0, 4).toUpperCase())}`;

  return (
    <View style={styles.purchaseCard}>
      <View style={styles.purchaseCardContent}>
        <Image
          source={require('../../../assets/images/ic_maggi.png')}
          style={styles.purchaseProductImage}
        />
        <View style={styles.purchaseDetails}>
          <Text style={styles.purchaseProductName}>{item.name}</Text>
          <Text style={styles.purchaseDetailText}>
            <Text style={{fontWeight: 'bold'}}>Quantity:</Text> {item.quantity}
          </Text>
          <Text style={styles.purchaseDetailText}>
            <Text style={{fontWeight: 'bold'}}>Weight:</Text> {item.weight}
          </Text>
        </View>
        <View style={styles.purchaseRightSection}>
          <Text style={styles.purchaseOrderDate}>
            Ordered on {item.orderDate}
          </Text>
          <Text style={styles.purchasePayment}>
            <Text style={{fontWeight: 'bold', color: '#1a1f71'}}>VISA</Text>{' '}
            Paid via Card ************{item.lastFourDigits}
          </Text>
          <Text style={styles.purchaseAmount}>
            <Text style={{fontWeight: 'bold'}}>Amount:</Text> {item.amount} INR
          </Text>
        </View>
      </View>
    </View>
  );
};

// --- Main Screen Component
const InventoryScreen = () => {
  const [activeTab, setActiveTab] = useState('Overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 4;

  const inventoryData = [
    {
      id: '1',
      name: 'Nestle Maggi Masala',
      openStock: 40,
      remainingStock: 40,
      threshold: 12,
      onTheWay: 15,
      sp: 30,
      weight: '250gm',
      color: 'f97316',
    },
    {
      id: '2',
      name: 'Haldiram’s Sev Bhujia',
      openStock: 80,
      remainingStock: 65,
      threshold: 20,
      onTheWay: 5,
      sp: 60,
      weight: '400gm',
      color: '4b5563',
    },
    {
      id: '3',
      name: 'Coca Cola 2L Bottle',
      openStock: 120,
      remainingStock: 100,
      threshold: 50,
      onTheWay: 0,
      sp: 90,
      weight: '2.0L',
      color: 'ef4444',
    },
  ];

  // Dummy Data for Purchase Orders (Purchase Tab)
  const purchaseData = [
    {
      id: 'p1',
      name: 'Maggi Large',
      quantity: 12,
      weight: '850 Gm',
      orderDate: '25/03/2025',
      lastFourDigits: '567',
      amount: '720',
      color: 'f97316',
    },
    {
      id: 'p2',
      name: 'Coffee',
      quantity: 10,
      weight: '150 Gm',
      orderDate: '25/03/2025',
      lastFourDigits: '567',
      amount: '850',
      color: 'b91c1c',
    },
    {
      id: 'p3',
      name: 'Silk',
      quantity: 10,
      weight: '65 Gm',
      orderDate: '25/03/2025',
      lastFourDigits: '567',
      amount: '1050',
      color: '6b21a8',
    },
    {
      id: 'p4',
      name: 'Sandwich Bread',
      quantity: 10,
      weight: '500 Gm',
      orderDate: '25/03/2025',
      lastFourDigits: '567',
      amount: '600',
      color: 'd97706',
    },
    {
      id: 'p5',
      name: 'Milk Carton',
      quantity: 6,
      weight: '1.0 L',
      orderDate: '24/03/2025',
      lastFourDigits: '123',
      amount: '350',
      color: '3b82f6',
    },
    {
      id: 'p6',
      name: 'Eggs (Dozen)',
      quantity: 2,
      weight: '600 Gm',
      orderDate: '24/03/2025',
      lastFourDigits: '123',
      amount: '180',
      color: 'fbbf24',
    },
    // Add more purchase data to test pagination
  ];

  const filteredInventory = inventoryData.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const filteredPurchaseOrders = purchaseData.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  // Pagination logic for Purchase tab
  const totalPages = Math.ceil(filteredPurchaseOrders.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentPurchaseItems = filteredPurchaseOrders.slice(
    startIndex,
    endIndex,
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Image
            source={require('../../../assets/images/nextgenlogo.png')}></Image>
          <Text style={styles.headerTitle}>Inventory</Text>
          <Image
            source={require('../../../assets/images/slider_icon.png')}
            style={{width: 25, height: 18}}></Image>
        </View>

        <View style={styles.searchFilterContainer}>
          <View style={styles.searchBar}>
            <Image
              source={require('../../../assets/images/ic_search_icon.png')}></Image>
            <TextInput
              style={styles.searchInput}
              placeholder="Search order"
              placeholderTextColor={GRAY_TEXT}
              value={searchTerm}
              onChangeText={setSearchTerm}
            />
          </View>
          <TouchableOpacity>
            <Image
              source={require('../../../assets/images/ic_filter_icon.png')}
              style={{height: 48, width: 48, marginInlineStart: 8}}></Image>
          </TouchableOpacity>
        </View>

        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[
              styles.tabButton,
              activeTab === 'Overview' ? styles.activeTab : styles.passiveTab,
            ]}
            onPress={() => setActiveTab('Overview')}>
            <Text
              style={
                activeTab === 'Overview'
                  ? styles.activeTabText
                  : styles.passiveTabText
              }>
              Overview
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.tabButton,
              activeTab === 'Purchase' ? styles.activeTab : styles.passiveTab,
            ]}
            onPress={() => setActiveTab('Purchase')}>
            <Text
              style={
                activeTab === 'Purchase'
                  ? styles.activeTabText
                  : styles.passiveTabText
              }>
              Purchase
            </Text>
          </TouchableOpacity>
        </View>

        {activeTab === 'Overview' ? (
          // Added key to force remount on tab change, which often resolves hook errors
          <ScrollView
            key="overview-content"
            contentContainerStyle={styles.contentContainer}>
            {filteredInventory.length > 0 ? (
              filteredInventory.map(item => (
                <InventoryCard key={item.id} item={item} />
              ))
            ) : (
              <View style={styles.noResults}>
                <Text style={styles.noResultsText}>
                  No inventory items match your search.
                </Text>
              </View>
            )}
            <View style={{height: 20}} />
          </ScrollView>
        ) : (
          // Added key to force remount on tab change
          <View key="purchase-content" style={styles.purchaseContentContainer}>
            <ScrollView contentContainerStyle={styles.contentContainer}>
              {currentPurchaseItems.length > 0 ? (
                currentPurchaseItems.map(item => (
                  <PurchaseOrderCard key={item.id} item={item} />
                ))
              ) : (
                <View style={styles.noResults}>
                  <Text style={styles.noResultsText}>
                    No purchase orders match your search.
                  </Text>
                </View>
              )}
              <View style={{height: 20}} />
            </ScrollView>

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <View style={styles.paginationContainer}>
                <TouchableOpacity
                  style={styles.paginationButton}
                  onPress={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}>
                  <Text style={styles.paginationButtonText}>{'<'}</Text>
                </TouchableOpacity>
                <Text style={styles.paginationText}>
                  Page {currentPage} of {totalPages}
                </Text>
                <TouchableOpacity
                  style={styles.paginationButton}
                  onPress={() =>
                    setCurrentPage(prev => Math.min(totalPages, prev + 1))
                  }
                  disabled={currentPage === totalPages}>
                  <Text style={styles.paginationButtonText}>{'>'}</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
      </View>
    </SafeAreaView>
  );
};

// --- Stylesheet for all components
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: CARD_BG,
  },
  container: {
    flex: 1,
    backgroundColor: SECONDARY_COLOR,
  },
  // Header Styles
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: CARD_BG,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    position: 'relative', // 👈 important
  },
  headerTitle: {
    position: 'absolute', // 👈 centers independently
    left: 0,
    right: 0,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
    color: DARK_TEXT,
  },
  headerLogo: {
    fontWeight: '900',
    color: PRIMARY_COLOR,
    fontSize: 18,
  },
  headerIcon: {
    fontSize: 24,
    color: DARK_TEXT,
    lineHeight: 24, // Fix for text-based icon alignment
  },

  // Search and Filter Styles
  searchFilterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: CARD_BG,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: SECONDARY_COLOR,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 48,
  },

  editButton: {
    backgroundColor: '#FFFFFF',
  },
  deleteButton: {
    backgroundColor: '#000000',
  },
  searchIcon: {
    fontSize: 18,
    marginRight: 8,
    color: GRAY_TEXT,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: DARK_TEXT,
    marginLeft: 10,
    paddingVertical: 0, // important for android
  },
  filterIconContainer: {
    marginLeft: 10,
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: CARD_BG,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#d1d5db',
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  filterIcon: {
    fontSize: 20,
    color: DARK_TEXT,
  },

  // Tab Styles
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: CARD_BG,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginRight: 8,
  },

  // Active (Overview) Styles
  activeTab: {
    backgroundColor: PRIMARY_COLOR,
    shadowColor: PRIMARY_COLOR,
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
  },
  activeTabText: {
    fontSize: 16,
    fontWeight: '700',
    color: CARD_BG,
  },
  // Passive (Purchase) Styles
  passiveTab: {
    backgroundColor: SECONDARY_COLOR,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    marginLeft: 8,
    marginRight: 0,
  },
  passiveTabText: {
    fontSize: 16,
    fontWeight: '600',
    color: DARK_TEXT,
  },

  // Inventory Card Styles
  contentContainer: {
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  card: {
    backgroundColor: CARD_BG,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: DARK_TEXT,
    flex: 1,
    paddingRight: 10,
  },
  productImage: {
    width: 80,
    height: 80,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: SECONDARY_COLOR,
    flexShrink: 0,
  },

  // Details Grid Styles (for Overview)
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6',
  },
  detailItemContainer: {
    width: width > 400 ? '33.333%' : '50%', // Use 3 per row on wider screens, 2 on mobile
    marginBottom: 8,
    paddingRight: 8,
  },
  detailItemLabel: {
    fontSize: 12,
    color: GRAY_TEXT,
    marginBottom: 2,
  },
  detailItemValue: {
    fontSize: 14,
    fontWeight: '600',
    color: DARK_TEXT,
  },

  // Action Buttons Styles (for Overview)
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    marginTop: 4,
  },
  button: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
    paddingVertical: 12,
    height: 48,
    marginHorizontal: 4,
  },
  editButton: {
    backgroundColor: PRIMARY_COLOR,
    marginRight: 4,
    shadowColor: PRIMARY_COLOR,
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 3,
    flexDirection: 'row',
    alignItems: 'center',
  },
  editButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: CARD_BG,
  },
  deleteButton: {
    backgroundColor: SECONDARY_COLOR,
    marginLeft: 4,
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  deleteButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000000',
    fontWeight: 'bold',
  },

  // View More Details Button
  viewMoreButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    backgroundColor: SECONDARY_COLOR,
    borderRadius: 8,
    marginTop: 8,
    flexDirection: 'row',
  },
  viewMoreText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000000',
  },

  // Optional Expanded Details
  expandedDetails: {
    marginTop: 10,
    padding: 12,
    backgroundColor: '#e5e7eb',
    borderRadius: 8,
  },
  expandedDetailsText: {
    color: '#374151',
    fontSize: 14,
    marginBottom: 4,
  },
  noResults: {
    backgroundColor: CARD_BG,
    borderRadius: 12,
    padding: 30,
    alignItems: 'center',
    marginTop: 16,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  noResultsText: {
    fontSize: 18,
    color: GRAY_TEXT,
  },

  // --- Purchase Tab Specific Styles ---
  purchaseContentContainer: {
    flex: 1,
  },
  purchaseCard: {
    backgroundColor: CARD_BG,
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16, // Matches contentContainer padding
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  purchaseCardContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  purchaseProductImage: {
    width: 60,
    height: 60,
    borderRadius: 6,
    marginRight: 12,
    borderWidth: 1,
    borderColor: SECONDARY_COLOR,
  },
  purchaseDetails: {
    flex: 2, // Takes more space
    marginRight: 10,
  },
  purchaseRightSection: {
    flex: 3, // Takes remaining space
    alignItems: 'flex-end',
  },
  purchaseProductName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: DARK_TEXT,
    marginBottom: 4,
  },
  purchaseDetailText: {
    fontSize: 13,
    color: GRAY_TEXT,
    marginBottom: 2,
  },
  purchaseOrderDate: {
    fontSize: 13,
    color: GRAY_TEXT,
    marginBottom: 4,
  },
  purchasePayment: {
    fontSize: 13,
    color: GRAY_TEXT,
    marginBottom: 4,
  },
  purchaseAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: DARK_TEXT,
  },

  // Pagination Styles
  paginationContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
    backgroundColor: CARD_BG,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  paginationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SECONDARY_COLOR,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 8,
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  paginationButtonText: {
    fontSize: 18,
    color: DARK_TEXT,
    fontWeight: 'bold',
  },
  paginationText: {
    fontSize: 16,
    color: DARK_TEXT,
    fontWeight: '600',
  },
});

export default InventoryScreen;
