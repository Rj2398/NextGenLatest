import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Modal,
  LogBox,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import React, {useState, useMemo} from 'react'; // 🚀 Added useMemo
import BottomSheetFilter from './BottomSheetFilter';
import DealsDiscountScreen from './DealsDiscountScreen';

const FilterIcon = require('../../../assets/filter_icon.png');
const ActiveFilterIcon = require('../../../assets/filter_fill.png');
import {useNavigation} from '@react-navigation/native';
import useDashboard from '../../../hooks/useDashboard';

// --- Dimensions for Card Width Calculation ---
const {width} = Dimensions.get('window');
const CARD_MARGIN = 8;

// --- KPI Value Formatting Function ---
function formatKpiValue(kpi) {
  if (kpi.valueType === 'currency') {
    const value = parseFloat(kpi.value).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    return `${kpi.currency || ''} ${value}`;
  } else if (kpi.valueType === 'number') {
    const value = parseFloat(kpi.value).toLocaleString(undefined, {
      maximumFractionDigits: 0,
    });
    return kpi.unit ? `${value} ${kpi.unit}` : value;
  }
  return kpi.value;
}

// --- KpiCard Component Definition ---
const KpiCard = ({item}) => {
  const isSecondaryStyle =
    item.kpiKey === 'low_stock' ||
    item.kpiKey === 'out_of_stock' ||
    item.kpiKey === 'cost';
  const formattedValue = formatKpiValue(item);
  const cardStyle = isSecondaryStyle ? styles.card2 : styles.card;
  const titleStyle = isSecondaryStyle ? styles.card2Title : styles.cardTitle;
  const subText = item.period || (item.unit ? `Total ${item.unit}` : 'Overall');

  return (
    <View
      style={[
        cardStyle,
        {width: width / 2 - 24, marginHorizontal: CARD_MARGIN / 2},
      ]}>
      <Text style={titleStyle} numberOfLines={1}>
        {item.name}
      </Text>
      <Text style={styles.cardValue}>{formattedValue}</Text>
      <Text style={styles.cardSub} numberOfLines={1}>
        {subText}
      </Text>
    </View>
  );
};
// --- END KpiCard Component ---

const Dashboard = () => {
  const {
    getDashboardList,
    isLoadingDashboard,
    getStuctDashboard,
    isLoadignStuctDashboard,
  } = useDashboard();

  // 🚀 1. State for the search query
  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterVisible, setIsFilterVisible] = useState(false);

  const navigation = useNavigation();

  const dashboardData = getDashboardList?.items || [];

  // 🚀 2. Filtering Logic (Optimized with useMemo)
  const filteredData = useMemo(() => {
    if (!searchQuery) {
      return dashboardData;
    }
    const lowerCaseQuery = searchQuery.toLowerCase();

    return dashboardData.filter(kpi => {
      // Search by KPI name or key
      const nameMatches = kpi.name.toLowerCase().includes(lowerCaseQuery);
      const keyMatches = kpi.kpiKey.toLowerCase().includes(lowerCaseQuery);

      return nameMatches || keyMatches;
    });
  }, [dashboardData, searchQuery]); // Re-run only when data or query changes

  const openFilters = () => setIsFilterVisible(true);
  const closeFilters = () => setIsFilterVisible(false);

  const handlePressBulk = () => {
    navigation.navigate('BulkUpload');
  };
  const handlePressAddProduct = () => {
    navigation.navigate('AddNewProduct');
  };
  const handlePressDeals = () => {
    navigation.navigate('DealsDiscountScreen');
  };

  const renderKpiItem = ({item}) => <KpiCard item={item} />;

  return (
    <View style={styles.container}>
      {/* Search */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <Image
            source={require('../../../assets/search_icon.png')}
            style={styles.searchImage}
            resizeMode="contain"
          />
          <TextInput
            placeholder="Search Product or orders"
            placeholderTextColor="#888"
            style={styles.searchInput}
            value={searchQuery} // 🚀 Bind value
            onChangeText={setSearchQuery} // 🚀 Bind change handler
          />
        </View>
        <TouchableOpacity onPress={openFilters}>
          <Image
            source={isFilterVisible ? ActiveFilterIcon : FilterIcon}
            style={styles.filterImage}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>

      <BottomSheetFilter isVisible={isFilterVisible} onClose={closeFilters} />

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>Overall Inventory</Text>

        {/* Cards Grid - FlatList Implementation */}
        <FlatList
          data={filteredData} // 🚀 Use the FILTERED data here
          keyExtractor={item => item.kpiKey}
          renderItem={renderKpiItem}
          numColumns={2}
          scrollEnabled={false}
          columnWrapperStyle={styles.cardRow}
          ListEmptyComponent={() =>
            !isLoadingDashboard &&
            filteredData.length === 0 && (
              <Text style={styles.emptyText}>
                {searchQuery
                  ? `No results found for "${searchQuery}".`
                  : 'No inventory data available.'}
              </Text>
            )
          }
        />

        {isLoadingDashboard && (
          <ActivityIndicator
            size="large"
            color="#FF8719"
            style={{marginTop: 20}}
          />
        )}

        {/* Buttons and Deals Card... (rest of the component) */}
        <TouchableOpacity
          style={styles.orangeBtn}
          onPress={handlePressAddProduct}>
          <Image
            source={require('../../../assets/plus_icon.png')}
            style={styles.uploadImage}
            resizeMode="contain"
          />
          <Text style={[styles.btnText, {marginStart: 5}]}>
            Add New Products
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.orangeBtnLight}>
          <Text style={styles.btnText}>View all Products</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.uploadBtn} onPress={handlePressBulk}>
          <Image
            source={require('../../../assets/upload_icon.png')}
            style={styles.uploadImage}
            resizeMode="contain"
          />
          <Text style={[styles.btnText, {marginLeft: 6}]}>Bulk Upload</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.dealCard} onPress={handlePressDeals}>
          <Image
            source={require('../../../assets/cuppons_icon.png')}
            style={styles.discountImage}
            resizeMode="contain"
          />
          <Text style={styles.dealText}>Deals & Discount</Text>
          <Image
            source={require('../../../assets/arrow_icon.png')}
            style={styles.arrowImage}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default Dashboard;

// --- Stylesheet (Kept for completeness) ---
const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#fff', paddingHorizontal: 16},
  scrollContent: {
    paddingBottom: 100,
  },

  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffff',
    borderRadius: 8,
    borderColor: '#D7D7D7',
    borderWidth: 1,
    paddingHorizontal: 10,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    color: '#000',
    fontSize: 12,
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginVertical: 10,
    color: '#000',
  },

  cardRow: {
    justifyContent: 'space-between',
    marginBottom: 12,
  },

  card: {
    backgroundColor: '#fff7f0',
    borderColor: '#F89941',
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    height: 100,
    justifyContent: 'space-around',
  },
  card2: {
    backgroundColor: '#ffedee',
    borderColor: '#D24648',
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    height: 100,
    justifyContent: 'space-around',
  },
  cardTitle: {
    fontSize: 13,
    color: '#FF7A00',
    fontWeight: '500',
  },
  card2Title: {
    fontSize: 13,
    color: '#D24648',
    fontWeight: '500',
  },
  cardValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
    marginVertical: 4,
  },
  cardSub: {
    fontSize: 10,
    color: '#5F6368',
    fontWeight: '500',
  },

  orangeBtn: {
    backgroundColor: '#FF8719',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  orangeBtnLight: {
    backgroundColor: '#FFAF66',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  uploadBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFAF66',
    padding: 14,
    borderRadius: 10,
    marginTop: 10,
  },
  btnText: {color: '#fff', fontWeight: '600', fontSize: 14},

  dealCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFF',
    padding: 14,
    borderRadius: 10,
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#E2E2E2',
  },
  dealText: {fontWeight: '600', color: '#000', marginStart: 10},
  emptyText: {
    textAlign: 'center',
    color: '#888',
    marginTop: 20,
  },
  filterImage: {width: 50, height: 50, marginStart: 5, marginTop: 5},
  searchImage: {width: 25, height: 25, marginStart: 5},
  uploadImage: {width: 15, height: 15},
  discountImage: {width: 15, height: 15},
  arrowImage: {width: 15, height: 15, marginStart: 25, marginTop: 3},
});

//

///
///
///
///

///

///

//

//

//
//
//
//

//

//

//

//

//

//

//

//

//
// import {
//   StyleSheet,
//   Text,
//   View,
//   ScrollView,
//   TouchableOpacity,
//   Alert, // Added Alert for feedback
// } from 'react-native';
// import React, {useState, useMemo} from 'react';
// // Assuming these paths are correct
// import PriceVariantGroup from '../../components/PriceVariantGroup';
// import ProductImagePicker from '../../components/ProductImagePicker';
// import useProductModal from '../../../hooks/useProduct';
// import InputGroup from '../../components/InputGroup';
// import DescriptionInput from '../../components/DescriptionInput';
// import DropdownGroup from '../../components/DropdownGroup';
// import CheckboxGroup from '../../components/CheckBoxGroup';
// import NumberInputGroup from '../../components/NumberInputGroup';
// import Feather from 'react-native-vector-icons/Feather'; // For styling/icons if needed

// // --- API Configuration ---
// const PRODUCT_API_URLS = {
//   Ecommerce_Product_Basic:
//     'https://dev-backend.nextgenedus.com/api/v1/Products/basic-information',
//   Ecommerce_Product_Details:
//     'https://dev-backend.nextgenedus.com/api/v1/Products/details',
//   Ecommerce_Product_Variant:
//     'https://dev-backend.nextgenedus.com/api/v1/Products/variants',
//   Ecommerce_Product_Compliance:
//     'https://dev-backend.nextgenedus.com/api/v1/Products/compliance',
// };

// // --- API Payload Utility ---
// // ⚠️ NOTE: This function is complex due to the API's nested FormData requirement.
// // It is a necessary implementation based on the structure you provided.
// const createAPIFormData = (pageData, pageName, currentProductId) => {
//   const formData = new FormData();
//   formData.append('pageName', pageName);

//   if (currentProductId) {
//     formData.append('productId', currentProductId);
//   }

//   // --- Logic for Basic, Details, Compliance Pages (Simple fields[i].fieldName structure) ---
//   if (pageName !== 'Ecommerce_Product_Variant') {
//     let fieldIndex = 0;

//     pageData.forEach(field => {
//       const base = `fields[${fieldIndex}]`;
//       formData.append(`${base}.fieldName`, field.fieldName);

//       if (field.fieldType === 'File' || field.fieldType === 'imgpicker') {
//         // Assuming 'value' is an array of local image URIs
//         (field.value || []).forEach(uri => {
//           const fileExtension = uri.split('.').pop();
//           formData.append(`${base}.file`, {
//             uri: uri,
//             name: `${field.fieldName}-${Date.now()}.${fileExtension}`,
//             type: `image/${fileExtension === 'jpg' ? 'jpeg' : fileExtension}`,
//           });
//         });
//       } else {
//         // For Text, Number, Select, Checkbox (API expects string representation)
//         formData.append(`${base}.value`, String(field.value));
//       }
//       fieldIndex++;
//     });
//   }
//   // --- Logic for Variant Page (variants[i].pageData.fields[j].fieldName structure) ---
//   else {
//     // Find the variants array within pageData
//     const variantEntry = pageData.find(d => d.fieldName === 'variants');
//     const variants = variantEntry ? variantEntry.value : [];

//     variants.forEach((variant, vIndex) => {
//       const base = `variants[${vIndex}].pageData`;
//       formData.append(`${base}.pageName`, pageName);

//       // Loop through the fields INSIDE the variant object (which comes from PriceVariantGroup)
//       variant.fields.forEach((field, fIndex) => {
//         formData.append(`${base}.fields[${fIndex}].fieldName`, field.fieldName);
//         formData.append(`${base}.fields[${fIndex}].value`, String(field.value));
//       });

//       // Handle variant images/documents (simplified)
//       (variant.documents || []).forEach((doc, dIndex) => {
//         // Assuming doc.file is the local URI
//         const fileExtension = doc.file.split('.').pop();
//         formData.append(
//           `${base}.documents[${dIndex}].fieldName`,
//           doc.fieldName,
//         );
//         formData.append(`${base}.documents[${dIndex}].file`, {
//           uri: doc.file,
//           name: `${doc.fieldName}-${Date.now()}.${fileExtension}`,
//           type: `image/${fileExtension === 'jpg' ? 'jpeg' : fileExtension}`,
//         });
//       });
//     });
//   }

//   return formData;
// };

// const AddNewProduct = () => {
//   const {
//     getAllProductModal,
//     basicInformation,
//     productVariantApi,
//     productDetailapi,
//     ProductsCompliance,
//   } = useProductModal();

//   const [formData, setFormData] = useState({});
//   const [productVariants, setProductVariants] = useState([]);
//   const [currentProductId, setCurrentProductId] = useState(null); // State to track ID after Step 1
//   const [isSubmitting, setIsSubmitting] = useState(false);

//   // 1. REVISED LOGIC: Sort and Structure the form data for display (Same as before)
//   const structuredForm = useMemo(() => {
//     // ... (rest of sorting logic remains the same) ...
//     const rawPages = getAllProductModal?.pages || [];
//     const sortedPages = [...rawPages].sort((a, b) => a.order - b.order);
//     return sortedPages.map(page => {
//       const sortedSections = page.sections
//         ? [...page.sections].sort((a, b) => a.order - b.order)
//         : [];
//       const sectionsWithSortedFields = sortedSections.map(section => ({
//         ...section,
//         fields: section.fields
//           ? [...section.fields].sort((a, b) => a.displayOrder - b.displayOrder)
//           : [],
//       }));
//       return {...page, sections: sectionsWithSortedFields};
//     });
//   }, [getAllProductModal]);

//   // 2. NEW LOGIC: Group collected formData values by PageName for API submission
//   const dataGroupedByPage = useMemo(() => {
//     const groupedData = {};
//     const rawPages = getAllProductModal?.pages || [];

//     rawPages.forEach(page => {
//       const pageName = page.pageName;
//       groupedData[pageName] = [];

//       page.sections.forEach(section => {
//         section.fields.forEach(field => {
//           const fieldValue = formData[field.fieldName];

//           // Collect all necessary fields for submission payload
//           if (
//             fieldValue !== null &&
//             fieldValue !== undefined &&
//             fieldValue !== ''
//           ) {
//             groupedData[pageName].push({
//               fieldName: field.fieldName,
//               value: fieldValue,
//               fieldType: field.fieldType,
//             });
//           }
//         });
//       });
//     });

//     // Explicitly handle the 'variants' data under its designated page
//     if (productVariants.length > 0) {
//       groupedData['Ecommerce_Product_Variant'].push({
//         fieldName: 'variants',
//         value: productVariants, // Pass the entire structured array
//         fieldType: 'Array',
//       });
//     }

//     return groupedData;
//   }, [formData, productVariants, getAllProductModal]);

//   const handleFieldChange = (fieldName, value) => {
//     setFormData(prev => ({...prev, [fieldName]: value}));
//   };

//   const renderField = field => {
//     // ... (renderField logic remains the same for component rendering) ...
//     const commonProps = {
//       key: field.id,
//       label: field.label,
//       placeholder: field.placeholder,
//       isRequired: field.isRequired,
//       isReadOnly: field.isReadOnly,
//       helpText: field.helpText,
//       maxLength: field.maxLength,
//       regexPattern: field.regexPattern,
//       value: formData[field.fieldName] || field.defaultValue,
//       onChangeText: text => handleFieldChange(field.fieldName, text),
//       onChange: value => handleFieldChange(field.fieldName, value),
//     };

//     switch (field.fieldType) {
//       case 'Text':
//         return <InputGroup {...commonProps} />;
//       case 'Number':
//         return <NumberInputGroup {...commonProps} />;
//       case 'Checkbox':
//         return (
//           <CheckboxGroup {...commonProps} onChange={commonProps.onChange} />
//         );
//       case 'TextArea':
//         return <DescriptionInput {...commonProps} />;
//       case 'Select':
//         return (
//           <DropdownGroup
//             {...commonProps}
//             options={field.options || []}
//             onSelect={commonProps.onChange}
//             onChangeText={() => {}}
//           />
//         );
//       case 'imgpicker':
//       case 'File':
//         return (
//           <ProductImagePicker
//             key={field.id}
//             images={formData[field.fieldName] || []}
//             setImages={commonProps.onChange}
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   // --- 3. SEQUENTIAL SUBMISSION HANDLER ---
//   const handleSubmit = async () => {
//     if (isSubmitting) return;

//     const pageNamesToSubmit = [
//       'Ecommerce_Product_Basic',
//       'Ecommerce_Product_Details',
//       'Ecommerce_Product_Variant',
//       'Ecommerce_Product_Compliance',
//     ];

//     setIsSubmitting(true);
//     let tempProductId = currentProductId;

//     try {
//       for (const pageName of pageNamesToSubmit) {
//         const endpoint = PRODUCT_API_URLS[pageName];
//         const pageData = dataGroupedByPage[pageName];

//         if (!endpoint || !pageData || pageData.length === 0) {
//           console.warn(
//             `Skipping submission for ${pageName}: No data or endpoint.`,
//           );
//           continue;
//         }

//         // Create API-specific FormData payload
//         const apiPayload = createAPIFormData(pageData, pageName, tempProductId);

//         // ⚠️ Replace with your actual authentication token and headers
//         const response = await fetch(endpoint, {
//           method: 'POST',
//           // Ensure you set Authorization header here
//           // headers: { 'Authorization': `Bearer YOUR_TOKEN` },
//           body: apiPayload,
//         });

//         const result = await response.json();

//         if (!response.ok) {
//           throw new Error(
//             `[${pageName}] Failed: ${result.message || response.statusText}`,
//           );
//         }

//         // CRUCIAL: Capture the Product ID from the first step
//         if (
//           pageName === 'Ecommerce_Product_Basic' &&
//           result.data &&
//           result.data.productId
//         ) {
//           tempProductId = result.data.productId;
//           setCurrentProductId(tempProductId);
//         }
//       }

//       Alert.alert(
//         'Success',
//         `Product creation completed! Product ID: ${tempProductId}`,
//       );
//       // Reset form or navigate away here
//       setFormData({});
//     } catch (error) {
//       Alert.alert('Submission Failed', error.message);
//       console.error('Submission sequence failed:', error);
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   return (
//     <ScrollView contentContainerStyle={styles.contentContainer}>
//       <Text style={styles.header}>Add New Product</Text>

//       {/* 2. RENDERING: Map over the sorted structured data */}
//       {structuredForm.map(page => (
//         <View key={page.pageId}>
//           <Text style={styles.pageTitle}>{page.title}</Text>

//           {page.sections.map(section => (
//             <View key={section.id} style={styles.sectionContainer}>
//               <Text style={styles.sectionTitle}>{section.title}</Text>
//               {section.description && (
//                 <Text style={styles.sectionDescription}>
//                   {section.description}
//                 </Text>
//               )}

//               {/* Render sorted fields within the section */}
//               {section.fields.map(
//                 field => field.isVisible !== false && renderField(field),
//               )}
//             </View>
//           ))}
//         </View>
//       ))}

//       {/* Fixed Components (outside the dynamic sections) */}
//       <Text style={styles.sectionTitle}>Price & Variants</Text>
//       <PriceVariantGroup onVariantsChange={setProductVariants} />

//       <TouchableOpacity
//         style={[
//           styles.submitButton,
//           isSubmitting && styles.submitButtonDisabled,
//         ]}
//         onPress={handleSubmit}
//         disabled={isSubmitting}>
//         <Text style={styles.submitButtonText}>
//           {isSubmitting ? 'SAVING...' : 'SAVE PRODUCT'}
//         </Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// export default AddNewProduct;

// const styles = StyleSheet.create({
//   contentContainer: {
//     padding: 20,
//     backgroundColor: '#fff',
//     minHeight: '100%',
//   },
//   header: {
//     fontSize: 24,
//     fontWeight: '800',
//     marginBottom: 20,
//     color: '#333',
//   },
//   pageTitle: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     marginTop: 10,
//     marginBottom: 15,
//     borderBottomWidth: 2,
//     borderBottomColor: '#F89941',
//     paddingBottom: 5,
//     color: '#333',
//   },
//   sectionContainer: {
//     marginBottom: 25,
//     paddingBottom: 15,
//     borderBottomWidth: StyleSheet.hairlineWidth,
//     borderBottomColor: '#ccc',
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: '700',
//     color: '#333',
//     marginBottom: 4,
//   },
//   sectionDescription: {
//     fontSize: 14,
//     color: '#888',
//     marginBottom: 15,
//   },
//   submitButton: {
//     backgroundColor: '#F89941',
//     padding: 15,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 30,
//     marginBottom: 50,
//   },
//   submitButtonDisabled: {
//     backgroundColor: '#FFA07A',
//     opacity: 0.7,
//   },
//   submitButtonText: {
//     color: '#FFFFFF',
//     fontSize: 16,
//     fontWeight: '700',
//   },
// });
//

//
