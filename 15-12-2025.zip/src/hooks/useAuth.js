import {useDispatch} from 'react-redux';
import {useMutation} from '@tanstack/react-query';
import {clearUser, setUserInfo} from '../store/slices/userSlice';

import AsyncStorage from '@react-native-async-storage/async-storage';

import {api} from '../utils/api';
import {KEYS} from '../config/constant';
import {useState} from 'react';
// import {err} from 'react-native-svg/lib/typescript/xml'; // Removed unused import

export default function useAuth() {
  const dispatch = useDispatch();

  const [manualLoading, setManualLoading] = useState(false);

  const {mutateAsync: loginUser} = useMutation({
    mutationKey: ['login', 'user'],
    mutationFn: async payload => {
      try {
        console.log('call transfer***');
        // setManualLoading(true);
        // const response = await api.post('Auth/login', payload);

        // const {data} = response;

        // // --- CHANGE START: Extracting and saving refreshToken ---
        // const accessToken = data?.data?.accessToken;
        // const refreshToken = data?.data?.refreshToken; // <--- EXTRACT REFRESH TOKEN

        // const userId = data?.data?.user?.id;
        // // --- CHANGE END ---

        // if (accessToken && refreshToken) {
        //   //
        //   await AsyncStorage.setItem(
        //     KEYS.USER_INFO,
        //     JSON.stringify(data?.data),
        //   );

        //   setTimeout(() => {
        //     dispatch(setUserInfo(data?.data));
        //   }, 1000);
        // }
        const dummyUser = {
          id: 'U1001',
          name: 'Alex Johnson',
          userType: 'User', // Or 'Academia', 'Merchant'
        };

        setTimeout(() => {
          dispatch(setUserInfo(dummyUser));
        }, 1000);

        return {
          ...data,
          message: data?.message,
        };
      } catch (error) {
        const errorMessage = error.message || 'An unknown error occurred';
        throw new Error(errorMessage);
      } finally {
        setManualLoading(false);
      }
    },
  });

  const isLoading = manualLoading;
  return {
    loginUser,
    isLoading, // Added isLoading for completeness
  };
}
