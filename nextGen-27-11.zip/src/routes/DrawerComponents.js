

import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';

// React Navigation Imports
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  // We won't use DrawerItemList, we'll implement custom rendering
  DrawerItem,
} from '@react-navigation/drawer';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Icon Import (Assuming you have Ionicons installed)
import Ionicons from 'react-native-vector-icons/Ionicons';

// --- Screen Imports (These paths are assumed to be correct) ---
// NOTE: These files must exist in your project structure for this to run
import Orders from '../views/pages/onBoardScreen/Orders';
import Reports from '../views/pages/onBoardScreen/Reports';
import Manage from '../views/pages/onBoardScreen/Manage';
import Dashboard from '../views/pages/onBoardScreen/Dashboard';
import Inventory from '../views/pages/onBoardScreen/Inventory';
import CreateAd from '../views/pages/onBoardScreen/CreateAd';
import MyAds from '../views/pages/onBoardScreen/MyAds';
import Billing from '../views/pages/onBoardScreen/Billing';
import ReportsScreen from '../views/pages/onBoardScreen/ReportsScreen';
import OrdersScreen from '../views/pages/onBoardScreen/OrdersScreen';
import ReviewScreen from '../views/pages/onBoardScreen/ReviewScreen';
import InventoryListScreen from '../views/pages/onBoardScreen/InventoryListScreen';

const Drawer = createDrawerNavigator();
const Stack = createNativeStackNavigator();

// --- Centralized Color Definitions (From DrawerScreen.js) ---
const colors = {
  white: '#FFFFFF',
  primaryOrange: '#FF8719', // Active Menu Text/Icon
  secondaryOrange: '#FF7A00', // Avatar Border
  textDark: '#333', // Inactive Menu Icon
  textMedium: '#5F6368', // Inactive Menu Text
  textLight: '#757575', // Name Text
  roleDark: '#1E1E1E', // Role Text
  borderLight: '#ddd', // Header Border
  activeBackground: '#FFF6EE', // Active Menu Item Background
};

// --- Local Icon Mapping (From DrawerScreen.js) ---
// NOTE: These local require paths must point to valid images in your assets folder
const localIcons = {
  'drawer_click': require('./../assets/drawer_click.png'),
  'nextlogo': require('./../assets/nextlogo.png'),
  'dashboard': require('./../assets/dashboard.png'),
  'inventory': require('./../assets/inventory.png'),
  'ads': require('./../assets/ads.png'),
  'manage': require('./../assets/manage.png'),
  'orders': require('./../assets/orders.png'),
  'reports': require('./../assets/reports.png'),
  'billing': require('./../assets/billing.png'),
  // Fallback icons for items not explicitly mapped in the old file, using Ionicons:
  'home-outline': 'home-outline',
  'list-outline': 'list-outline',
  'bar-chart-outline': 'bar-chart-outline',
  'settings-outline': 'settings-outline',
  'log-out-outline': 'log-out-outline',
};

// Map screen names to their visible titles and preferred icons from the old design
const screenMap = [
  // Mapped to React Navigation Screens
  { name: 'DashboardHome', title: 'Dashboard', iconKey: 'dashboard' },
  { name: 'Inventory', title: 'Inventory', iconKey: 'inventory' },
  { name: 'Reports', title: 'Reports', iconKey: 'reports' },
  { name: 'Orders', title: 'Orders', iconKey: 'orders' },
  { name: 'Manage', title: 'Manage', iconKey: 'manage' },
  // Additional items from the old design that don't have a screen defined (Placeholder items)
  { name: 'Teams', title: 'Teams', iconKey: 'orders' }, // Reusing 'orders' icon
  { name: 'ReviewsAndRatings', title: 'Reviews and Ratings', iconKey: 'manage' }, // Using Ionicons fallback
  { name: 'ReportsAndAnalytics', title: 'Reports and Analytics', iconKey: 'bar-chart-outline' }, // Using Ionicons fallback
  { name: 'Billing', title: 'Billing', iconKey: 'billing' },
  { name: 'Ads', title: 'Ads', iconKey: 'ads' },
];


// --- Custom Menu Item Component for Design Consistency ---
const CustomDrawerItem = ({ route, title, iconKey, onPress, active, isIonicons = false }) => {
  const isActive = active || false;
  const iconColor = isActive ? colors.primaryOrange : colors.textDark;

  const renderIcon = () => {
    if (isIonicons) {
      return <Ionicons name={iconKey} size={22} color={iconColor} />;
    } else if (localIcons[iconKey]) {
      return (
        <Image
          source={localIcons[iconKey]}
          style={{
            width: 22,
            height: 22,
            tintColor: iconColor,
          }}
          resizeMode="contain"
        />
      );
    }
    // Placeholder if no icon is found
    return <View style={{ width: 22, height: 22 }} />;
  };

  return (
    <TouchableOpacity
      style={[styles.menuItem, isActive ? styles.activeMenu : null]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      {renderIcon()}
      <Text
        style={[
          styles.menuText,
          { color: isActive ? colors.primaryOrange : colors.textMedium },
        ]}
      >
        {title}
      </Text>
    </TouchableOpacity>
  );
};


// --- Custom Drawer Content ---
function CustomDrawerContent(props) {
  // Get the current active route name
  const currentRouteName = props.state.routeNames[props.state.index];

  // Filter items to only show the screens defined in the Drawer.Navigator
  const navigableRoutes = props.state.routes.map(route => route.name);

  // Combine the defined screens with the custom look from screenMap
  const displayedItems = screenMap.filter(item => navigableRoutes.includes(item.name));
  
  // Add Logout item separately
  const logoutItem = {
    name: 'Logout',
    title: 'Logout',
    iconKey: 'log-out-outline',
    isIonicons: true,
    onPress: () => props.navigation.replace('LoginScreen'),
  };

  return (
    <DrawerContentScrollView {...props} contentContainerStyle={{ paddingTop: 0 }}>
      {/* Header with logo and profile (from DrawerScreen.js) */}
      <View style={styles.header}>
        <View style={styles.statusAndAmountRow}>
          <Image
            source={localIcons.drawer_click}
            style={styles.drawerIcon}
            resizeMode="contain"
          />
          <View style={{ flex: 1, alignItems: 'center' }}>
            <Image
              source={localIcons.nextlogo}
              style={styles.centerLogo}
              resizeMode="contain"
            />
          </View>
        </View>
        
        <View style={styles.profileRow}>
          <Image
            source={{ uri: 'https://i.pravatar.cc/100' }}
            style={styles.avatar}
          />
          <View style={[styles.textContainer, { marginStart: 10 }]}>
            <Text style={styles.name}>Jane Doe</Text>
            <Text style={styles.role}>Store Admin</Text>
          </View>
        </View>
      </View>

      {/* Menu Items (Custom Styled List) */}
      <View style={styles.menuContainer}>
        {displayedItems.map((item, index) => (
          <CustomDrawerItem
            key={index}
            title={item.title}
            iconKey={item.iconKey}
            active={item.name === currentRouteName}
            onPress={() => props.navigation.navigate(item.name)}
          />
        ))}

        {/* Custom Styled Logout Item */}
        <View style={styles.divider} />
        <CustomDrawerItem
          title={logoutItem.title}
          iconKey={logoutItem.iconKey}
          onPress={logoutItem.onPress}
          isIonicons={true}
        />
      </View>
    </DrawerContentScrollView>
  );
}

// --- Dashboard Stack (Wraps the main Dashboard view) ---
const DashboardStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {/* <Stack.Screen name="Dashboard" component={Dashboard} /> */}
      <Stack.Screen name="Inventory" component={InventoryListScreen} />
    </Stack.Navigator>
  );
};

// --- Main Drawer Component ---
const DrawerComponent = () => {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerShown: true,
        // The custom drawer content handles all colors, so these are minimal
        drawerActiveTintColor: colors.primaryOrange, 
        drawerInactiveTintColor: colors.textMedium,
        // We set the drawer item style here, but the custom component overrides it
        drawerItemStyle: { marginVertical: 0, paddingHorizontal: 0 }, 
      }}
      drawerContent={props => <CustomDrawerContent {...props} />}
    >
      {/* <Drawer.Screen
        name="DashboardHome" // Maps to 'Dashboard' title in custom menu
        component={DashboardStack}
        options={{
          title: 'Dashboard',
          // The drawerIcon defined here is ignored by CustomDrawerContent, but kept for standard behavior if CustomDrawerContent is removed.
          drawerIcon: ({ color }) => (
            <Ionicons name="home-outline" size={22} color={color} />
          ),
        }}
      /> */}

      <Drawer.Screen
        name="Inventory"
        component={DashboardStack} // Use PlaceholderScreen since the actual component path is not provided
        options={{
          title: 'Inventory',
          drawerIcon: ({ color }) => (
            <Image
              source={localIcons.inventory}
              style={{ width: 22, height: 22, tintColor: color }}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="Ads"
        component={MyAds} // Use PlaceholderScreen since the actual component path is not provided
        options={{
          title: 'Ads',
          drawerIcon: ({ color }) => (
            <Image
              source={localIcons.ads}
              style={{ width: 22, height: 22, tintColor: color }}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="Orders"
        component={OrdersScreen}
        options={{
          title: 'Orders',
          headerShown: false,
          drawerIcon: ({ color }) => (
            <Ionicons name="list-outline" size={22} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Reports"
        component={ReportsScreen}
        options={{
          title: 'Reports',
          headerShown: false,
          drawerIcon: ({ color }) => (
            <Ionicons name="bar-chart-outline" size={22} color={color} />
          ),
        }}
      />

        <Drawer.Screen
                name="Billing"
                component={Billing}
                options={{
                  title: 'Billing',
                  drawerIcon: ({ color }) => (
                    <Ionicons name="bar-chart-outline" size={22} color={color} />
                  ),
                }}
              />

      <Drawer.Screen
        name="Manage"
        component={Manage}
        options={{
          title: 'Manage',
          drawerIcon: ({ color }) => (
            <Ionicons name="settings-outline" size={22} color={color} />
          ),
        }}
      />

      <Drawer.Screen
        name="ReviewsAndRatings"
        component={ReviewScreen}
        options={{
          title: 'Reviews and Ratings',
          drawerIcon: ({ color }) => (
            <Ionicons name="settings-outline" size={22} color={color} />
          ),
        }}
      />
      
    </Drawer.Navigator>
  );
};

// --- Stylesheet using Centralized Colors (From DrawerScreen.js) ---
const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.white,
    paddingVertical: 20,
    alignItems: 'center',
    borderBottomWidth: 0.3,
    borderColor: colors.borderLight,
  },
  centerLogo: {
    width: 100,
    height: 40,
  },
  drawerIcon: {
    width: 24,
    height: 24,
    marginStart: 20,
  },
  textContainer: {
    flexDirection: 'column',
    justifyContent: 'center',
  },
  statusAndAmountRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginTop: 10
  },
  profileRow: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: '100%',
    marginTop: 10,
    marginStart: 20,
  },
  avatar: {
    width: 35,
    height: 35,
    marginStart: 10,
    borderColor: colors.secondaryOrange,
    borderWidth: 1,
    borderRadius: 30,
  },
  name: {
    fontSize: 16,
    fontWeight: '400',
    marginTop: 5,
    color: colors.textLight,
  },
  role: {
    fontSize: 13,
    color: colors.roleDark,
    fontWeight: '700'
  },
  menuContainer: {
    paddingHorizontal: 20,
    paddingTop: 15,
    marginStart: 32,
    paddingBottom: 30,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderRadius: 8,
    marginVertical: 4, // Added a small vertical margin for separation
  },
  activeMenu: {
    backgroundColor: colors.activeBackground,
  },
  menuText: {
    fontSize: 20,
    marginLeft: 15,
    color: colors.textMedium,
    fontFamily: 'Roboto',
    fontWeight: '500'
  },
  divider: {
    height: 1,
    backgroundColor: colors.borderLight,
    marginVertical: 10,
    width: '90%',
    alignSelf: 'center',
  }
});

export default DrawerComponent;