// utils/formatDisplayFields.js
// export const formatDisplayFields = (item, fieldLabelMap = {}, options = {}) => {
//   if (!item || typeof item !== 'object') return [];

//   const {
//     exclude = ['product_image', 'order_date', 'payment_method', 'total_amount'],
//     formatters = {}, // optional: field-specific formatters
//   } = options;

//   const result = [];

//   for (const key in item) {
//     if (!item.hasOwnProperty(key)) continue;
//     if (exclude.includes(key)) continue;

//     const value = item[key];
//     const label = fieldLabelMap[key];

//     if (value === null || value === undefined || value === '' || !label)
//       continue;

//     const formattedValue =
//       typeof formatters[key] === 'function'
//         ? formatters[key](value, item)
//         : value;

//     result.push({label, value: formattedValue});
//   }

//   return result;
// };

export const formatDisplayFields = (item, fieldLabelMap = {}, options = {}) => {
  if (!item || typeof item !== 'object') return [];

  const {exclude = [], formatters = {}} = options; // empty exclude

  const result = [];

  for (const key in item) {
    if (!item.hasOwnProperty(key)) continue;
    if (exclude.includes(key)) continue;

    const value = item[key];
    const label = fieldLabelMap[key];

    if (value === null || value === undefined || value === '' || !label)
      continue;

    const formattedValue =
      typeof formatters[key] === 'function'
        ? formatters[key](value, item)
        : value;

    result.push({label, value: formattedValue});
  }

  return result;
};

/**
 * Extracts a map of fieldName => localized label from an API schema.
 *
 * Example:
 * schema.pages[0].sections[0].fields[] → { product_name: "Product Name", quantity: "Quantity" }
 */
export const extractFieldLabelMap = schema => {
  const map = {};

  if (!schema || typeof schema !== 'object') return map;

  const pages = schema.pages || [];
  pages.forEach(page => {
    (page.sections || []).forEach(section => {
      (section.fields || []).forEach(field => {
        const key = field.fieldName;
        const label =
          field.localization?.localizedText ||
          field.label ||
          field.placeholder ||
          key;
        if (key) map[key] = label;
      });
    });
  });

  return map;
};
//

// export const extractFieldLabelMapForPage = page => {
//   const map = {};

//   if (!page || typeof page !== 'object') return map;

//   const sections = page.sections || [];

//   sections.forEach(section => {
//     (section.fields || []).forEach(field => {
//       const key = field.fieldName;

//       const label =
//         field.localization?.localizedText ||
//         field.label ||
//         field.placeholder ||
//         key;

//       if (key) map[key] = label;
//     });
//   });

//   return map;
// };

//

export const extractFieldLabelMapForPage = page => {
  const map = {};

  if (!page || typeof page !== 'object') return map;

  const sections = page.sections || [];

  sections.forEach(section => {
    (section.fields || []).forEach(field => {
      const key = field.fieldName;

      const label =
        field.localization?.localizedText ||
        field.label ||
        field.placeholder ||
        key;

      const placeholder = field.placeholder || '';

      if (key) {
        map[key] = label;
        map[`${key}_placeholder`] = placeholder;
      }
    });
  });

  return map;
};

export const mapApiResponseToFormData = apiResponse => {
  if (!apiResponse) {
    return {};
  }

  const basic = apiResponse.ecommerce_Product_Basic?.basicInformation || {};
  const details = apiResponse.ecommerce_Product_Details;
  const policies = details?.policies || {};
  const attributes = details?.productAttributes || {};
  const identifiers = details?.identifiers || {};
  const compliance = apiResponse.ecommerce_Product_Compliance;
  const ageRestrictions = compliance?.ageRestrictions || {};
  const certifications = compliance?.certifications || {};

  // NOTE: For simplicity, we are taking the physical/package/price dimensions
  // from the *first* variant if it exists, matching how your formData was structured.
  const firstVariant = apiResponse.ecommerce_Product_Variant?.[0];
  const variantPhysical = firstVariant?.variantPhysical || {};
  const variantPackage = firstVariant?.variantPackage || {};
  const variantPrice = firstVariant?.variantPrice || {};
  const variantCore = firstVariant?.variantCore || {};

  // --- Map the data to the desired flat structure ---
  const normalizedData = {
    // 1. Basic Information
    product_title: basic.product_title || '',
    description: basic.description || '',
    category_id: basic.category_id || '',
    subcategory_id: basic.subcategory_id || '',

    // 2. Policies / Attributes
    is_returnable: policies.is_returnable ?? false,
    has_variants: policies.has_variants ?? false,
    return_window_days: policies.return_window_days || null,
    variation_theme: policies.variation_theme || null,
    gender: attributes.gender || null,

    // 3. Identifiers
    external_product_type: identifiers.external_product_type || null,
    mpn: identifiers.mpn || null,
    model_number: identifiers.model_number || null,
    country_of_origin: identifiers.country_of_origin || null,
    is_searchable: identifiers.is_searchable ?? false,
    slug: identifiers.slug || null,

    // 4. Core Variant Data (from the first variant)
    sku: variantCore.sku || null,
    serial_number: variantCore.serial_number || null,
    is_active: variantCore.is_active ?? false,
    variant_price: variantPrice.variant_price || null,
    variant_quantity: variantPrice.variant_quantity || null,

    // 5. Physical Dimensions (from the first variant)
    dimension_unit: variantPhysical.dimension_unit || null,
    width: variantPhysical.width || null,
    height: variantPhysical.height || null,
    length: variantPhysical.length || null,
    weight_unit: variantPhysical.weight_unit || null,
    weight: variantPhysical.weight || null,

    // 6. Package Dimensions (from the first variant)
    package_dimension_unit: variantPackage.package_dimension_unit || null,
    package_width: variantPackage.package_width || null,
    package_height: variantPackage.package_height || null,
    package_length: variantPackage.package_length || null,

    // 7. Compliance
    age_min: ageRestrictions.age_min || null,
    age_max: ageRestrictions.age_max || null,
    certification_codes: certifications.certification_codes || null,
    safety_notes: certifications.safety_notes || null,

    // 8. Nested Variants Array
    Ecommerce_Product_Variant:
      apiResponse.ecommerce_Product_Variant?.map(variant => ({
        // Note: You need a dedicated mapping function for variants if the variant structure
        // in your API response is different from the structure expected by your form's variant array.
        // Assuming a direct map for now based on your initial formData structure:
        weight: variant.variantPhysical?.weight || null,
        package_width: variant.variantPackage?.package_width || null,
        package_height: variant.variantPackage?.package_height || null,
        package_length: variant.variantPackage?.package_length || null,
        package_weight: variant.variantPackage?.package_weight || null,
        variant_price: variant.variantPrice?.variant_price || null,
        variant_quantity: variant.variantPrice?.variant_quantity || null,
        serial_number: variant.variantCore?.serial_number || null,
        is_active: variant.variantCore?.is_active ?? false,
        width: variant.variantPhysical?.width || null,
        height: variant.variantPhysical?.height || null,
        length: variant.variantPhysical?.length || null,
        weight_unit: variant.variantPhysical?.weight_unit || null,
        // Add other variant fields here...
      })) || [],
  };

  return normalizedData;
};
