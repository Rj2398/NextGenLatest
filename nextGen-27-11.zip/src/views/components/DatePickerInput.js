import React, {useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  Platform,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';

const DatePickerInput = ({label = 'Select Date', value, onDateChange}) => {
  const [showPicker, setShowPicker] = useState(false);

  const handleChange = (event, selectedDate) => {
    setShowPicker(false);
    if (selectedDate) onDateChange(selectedDate);
  };

  const formatDate = date => {
    if (!date) return label;
    return date.toISOString().split('T')[0];
  };

  return (
    <View>
      <TouchableOpacity
        style={styles.button}
        onPress={() => setShowPicker(true)}>
        <Text style={styles.buttonText}>{formatDate(value)}</Text>

        <Image
          source={require('../../assets/images/ic_date_icon.png')}
          style={styles.icon}
        />
      </TouchableOpacity>

      {showPicker && (
        <DateTimePicker
          value={value || new Date()}
          mode="date"
          display={Platform.OS === 'ios' ? 'spinner' : 'calendar'}
          onChange={handleChange}
        />
      )}
    </View>
  );
};

export default DatePickerInput;

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E2E2',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: '#FFF',
    justifyContent: 'space-between',
  },
  buttonText: {
    fontSize: 15,
    color: '#333',
  },
  icon: {
    width: 20,
    height: 20,
    resizeMode: 'contain',
  },
});
