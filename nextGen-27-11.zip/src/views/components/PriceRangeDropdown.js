import React, {useState} from 'react';
import {View, Text, TouchableOpacity, StyleSheet, FlatList} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';

const colors = {
  primary: '#F89941',
  white: '#FFFFFF',
  black: '#000000',
  border: '#E0E0E0',
  textPrimary: '#858D9D',
  lightGray: '#F9FAFB',
};

const PriceRangePicker = ({
  label = 'Price Range',
  value,
  options = [], // [{label, value}]
  onSelect,
  placeholder = 'Select Price',
  fullwidth = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const selectedLabel = options.find(opt => opt.value === value)?.label;

  const handleSelect = item => {
    onSelect(item.value); // return value only
    setIsOpen(false);
  };

  return (
    <View style={[styles.wrapper, {width: fullwidth ? '100%' : '45%'}]}>
      {label && <Text style={styles.label}>{label}</Text>}

      {/* Trigger */}
      <TouchableOpacity
        style={styles.dropdown}
        onPress={() => setIsOpen(!isOpen)}>
        <Text
          style={selectedLabel ? styles.selectedText : styles.placeholderText}>
          {selectedLabel || placeholder}
        </Text>

        <Feather
          name={isOpen ? 'chevron-up' : 'chevron-down'}
          size={20}
          color={colors.black}
        />
      </TouchableOpacity>

      {/* List */}
      {isOpen && (
        <View style={styles.optionBox}>
          <FlatList
            data={options}
            keyExtractor={item => item.value.toString()}
            renderItem={({item}) => (
              <TouchableOpacity
                style={styles.optionItem}
                onPress={() => handleSelect(item)}>
                <Text
                  style={[
                    styles.optionText,
                    item.value === value && styles.selectedOption,
                  ]}>
                  {item.label}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>
      )}
    </View>
  );
};

export default PriceRangePicker;

const styles = StyleSheet.create({
  wrapper: {
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    color: colors.textPrimary,
    marginBottom: 6,
  },
  dropdown: {
    borderWidth: 1,
    borderColor: colors.border,
    padding: 12,
    borderRadius: 8,
    backgroundColor: colors.lightGray,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  placeholderText: {
    color: colors.textPrimary,
    fontSize: 14,
  },
  selectedText: {
    color: colors.black,
    fontWeight: '600',
    fontSize: 14,
  },
  optionBox: {
    marginTop: 5,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 6,
    maxHeight: 140,
    backgroundColor: colors.white,
  },
  optionItem: {
    paddingVertical: 10,
    paddingHorizontal: 12,
  },
  optionText: {
    fontSize: 15,
    color: colors.black,
  },
  selectedOption: {
    color: colors.primary,
    fontWeight: '700',
  },
});
