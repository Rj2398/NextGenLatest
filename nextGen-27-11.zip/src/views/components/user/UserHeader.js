import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image} from 'react-native';
import {useNavigation} from '@react-navigation/native';
// 1. ⬇️ Import the Icon library (e.g., Ionicons)
import Ionicons from 'react-native-vector-icons/Ionicons';

// 🎨 Header Colors ko ek jagah define kiya gaya hai
const HEADER_COLORS = {
  background: '#fff',
  border: '#f0f0f0',
  title: 'black',
  icon: '#161B25', // Define icon color
};

// 2. 🛠️ backButton prop added with default value 'true'
const UserHeader = ({title, backButton = true, arrow}) => {
  // Use useNavigation to get the navigation object
  const navigation = useNavigation();

  // Check if we should show the button (prop is true AND we can navigate back)
  const showBackButton = backButton && navigation.canGoBack();

  return (
    <View style={styles.header}>
      {/* LEFT SIDE: Conditional Back Button/Placeholder */}
      {showBackButton ? (
        // The goBack() function is used in onPress
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}>
          {/* 3. 🖼️ Using Ionicons for the back button */}

          {!arrow ? (
            <Ionicons
              name="chevron-back" // A standard iOS-style back arrow icon
              size={24} // Adjust size as needed
              color={HEADER_COLORS.icon}
            />
          ) : (
            <Ionicons
              name="arrow-back" // A standard iOS-style back arrow icon
              size={24} // Adjust size as needed
              color={HEADER_COLORS.icon}
            />
          )}
        </TouchableOpacity>
      ) : (
        // 📏 Placeholder to maintain centering when the back button is hidden
        // Width needs to match the space taken by the icon for proper centering
        <View style={styles.leftPlaceholder} />
      )}

      <Text style={styles.title}>{title}</Text>

      {/* RIGHT SIDE: Placeholder (for centering) */}
      <View style={styles.rightPlaceholder} />
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: HEADER_COLORS.border,
    backgroundColor: HEADER_COLORS.background,
  },
  backButton: {
    padding: 4,
  },
  title: {
    fontSize: 18,
    fontWeight: '800',
    fontFamily: 'Roboto',
    color: HEADER_COLORS.title,
    textAlign: 'center', // Ensures title text itself is centered within its flex space
    flexShrink: 1, // Allows title to shrink if screens are small
  },
  // 📏 Placeholder style. We estimate the icon size (24) + padding (4*2=8) = 32.
  leftPlaceholder: {
    width: 32, // Adjust this width to match the size of the icon/touchable area
  },
  // To keep the title centered when no right-side button exists
  rightPlaceholder: {
    width: 32, // Match the left placeholder width
  },
  // 4. 🗑️ Removed arrowImage style since we are using Icon
});

export default UserHeader;
