import React from 'react';
import {View, Text, Image, StyleSheet, Dimensions} from 'react-native';

const {width} = Dimensions.get('window');

const CARD_BG = '#ffffff';
const SECONDARY_COLOR = '#f3f4f6';
const DARK_TEXT = '#1f2937';
const GRAY_TEXT = '#525252'; // Made GRAY_TEXT slightly lighter for better readability
const ACCENT_COLOR = '#1a1f71';

// Function to extract the last four digits from the payment method string
const getLastFourDigits = paymentMethod => {
  if (typeof paymentMethod === 'string') {
    const match = paymentMethod.match(/(\d{4})$/);
    return match ? match[0] : null;
  }
  return null;
};

const PurchaseNewOrderCard = ({item: propItem}) => {
  const item = propItem;

  const lastFourDigits = getLastFourDigits(item.payment_method);

  // Helper to format the date (optional, but good practice)
  const formattedDate = item.order_date
    ? new Date(item.order_date).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      })
    : 'Unknown Date';

  return (
    <View style={styles.purchaseCard}>
      <View style={styles.purchaseCardContent}>
        {/* Product Image - Keep in mind this image path is relative */}
        <Image
          source={require('../../assets/images/ic_maggi.png')}
          style={styles.purchaseProductImage}
          resizeMode="contain"
        />

        {/* Left Details */}
        <View style={styles.purchaseDetails}>
          {/* 1. Corrected property name from item.name to item.product_name */}
          {item.product_name && (
            <Text style={styles.purchaseProductName}>{item.product_name}</Text>
          )}

          {/* 2. Quantity - Conditionally rendered */}
          {item.quantity !== undefined && (
            <Text style={styles.purchaseDetailText}>
              <Text style={{fontWeight: 'bold'}}>Quantity: </Text>
              {item.quantity}
            </Text>
          )}

          {/* 3. Weight - Conditionally rendered and added unit if available */}
          {item.weight !== undefined && (
            <Text style={styles.purchaseDetailText}>
              <Text style={{fontWeight: 'bold'}}>Weight: </Text>
              {item.weight} {item.weight_unit || ''}
            </Text>
          )}
        </View>

        {/* Right Section */}
        <View style={styles.purchaseRightSection}>
          {/* 4. Order Date - Conditionally rendered and formatted */}
          {item.order_date && (
            <Text style={styles.purchaseOrderDate}>
              Ordered on {formattedDate}
            </Text>
          )}

          {/* 5. Payment Method - Conditionally rendered and parsed */}
          {item.payment_method && lastFourDigits && (
            <Text style={styles.purchasePayment}>
              {/* Conditional rendering for the "VISA" part using a new property */}
              {item.show_visa_logo && (
                <Text style={{fontWeight: 'bold', color: ACCENT_COLOR}}>
                  VISA{' '}
                </Text>
              )}
              Paid via Card ************{lastFourDigits}
            </Text>
          )}

          {/* 6. Total Amount - Conditionally rendered */}
          {item.total_amount !== undefined && (
            <Text style={styles.purchaseAmount}>
              <Text style={{fontWeight: 'bold'}}>Amount: </Text>
              {item.total_amount} {item.currency_code || 'INR'}
            </Text>
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  purchaseCard: {
    backgroundColor: CARD_BG,
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  purchaseCardContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  purchaseProductImage: {
    width: 70,
    height: 80,
    borderRadius: 6,
    marginRight: 12,
    borderWidth: 1,
    borderColor: SECONDARY_COLOR,
  },
  purchaseDetails: {
    flex: 1,
    marginRight: 10,
  },
  purchaseRightSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
  purchaseProductName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: DARK_TEXT,
    marginBottom: 4,
  },
  purchaseDetailText: {
    fontSize: 13,
    color: GRAY_TEXT,
    marginBottom: 2,
  },
  purchaseOrderDate: {
    fontSize: 13,
    color: GRAY_TEXT,
    marginBottom: 4,
  },
  purchasePayment: {
    fontSize: 13,
    color: GRAY_TEXT,
    marginBottom: 4,
  },
  purchaseAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: DARK_TEXT,
  },
});

export default PurchaseNewOrderCard;

//

//

//

//
// import React from 'react';
// import {View, Text, Image, StyleSheet, Dimensions} from 'react-native';
// import {formatDisplayFields} from '../../utils/modal/customCodeModal';

// const {width} = Dimensions.get('window');

// const CARD_BG = '#ffffff';
// const SECONDARY_COLOR = '#f3f4f6';
// const DARK_TEXT = '#1f2937';
// const GRAY_TEXT = '#000000';

// // 🛑 FILTERING RULE: Define the LABELS that MUST appear in the RIGHT column.
// const RIGHT_SIDE_FIELD_LABELS = [
//   'Ordered On',
//   'Paid Via',
//   'Amount',
//   'Currency',
// ];
// const AMOUNT_LABEL = 'Amount';
// const WEIGHT_LABEL = 'Weight';
// const WEIGHT_UNIT_LABEL = 'Weight Unit';
// const PRODUCT_NAME_LABEL = 'Product Name';
// const QUANTITY_LABEL = 'Quantity';

// const PurchaseNewOrderCard = ({item, fieldLabelMap}) => {
//   console.log(item, 'puchase card item');

//   console.log(fieldLabelMap, 'field map data');
//   // Ensure item exists
//   if (!item) {
//     return null;
//   }

//   // Get all fields (assuming output is {label, value} array)
//   const displayFields = formatDisplayFields(item, fieldLabelMap);

//   // 1. SPLIT DYNAMIC FIELDS by checking the 'label' property
//   const rightFields = displayFields.filter(field =>
//     RIGHT_SIDE_FIELD_LABELS.includes(field.label),
//   );
//   const leftFields = displayFields.filter(
//     field => !RIGHT_SIDE_FIELD_LABELS.includes(field.label),
//   );

//   // --- Left Side Processing (Combining Product Name, Quantity, Weight) ---

//   const finalLeftFields = [];
//   const productNameField = leftFields.find(f => f.label === PRODUCT_NAME_LABEL);
//   const quantityField = leftFields.find(f => f.label === QUANTITY_LABEL);
//   const weightField = leftFields.find(f => f.label === WEIGHT_LABEL);
//   const weightUnitField = leftFields.find(f => f.label === WEIGHT_UNIT_LABEL);

//   // 1. Product Name (Styled large and bold)
//   if (productNameField) {
//     finalLeftFields.push(productNameField);
//   }

//   // 2. Quantity
//   if (quantityField) {
//     finalLeftFields.push(quantityField);
//   }

//   // 3. Combine Weight + Weight Unit
//   if (weightField && weightUnitField) {
//     finalLeftFields.push({
//       label: weightField.label,
//       value: `${weightField.value} ${weightUnitField.value}`,
//       isCombined: true, // Flag to ensure it gets rendered
//     });
//   } else if (weightField) {
//     finalLeftFields.push(weightField);
//   }

//   // --- Right Side Processing (Combining Amount + Currency) ---

//   const finalRightFields = [];
//   const amountField = rightFields.find(f => f.label === AMOUNT_LABEL);
//   const currencyField = rightFields.find(f => f.label === 'Currency');

//   rightFields.forEach(field => {
//     // Skip Currency and Amount, we handle them combined below
//     if (field.label === 'Currency' || field.label === AMOUNT_LABEL) return;

//     finalRightFields.push(field);
//   });

//   // Add the combined Amount + Currency field
//   if (amountField) {
//     finalRightFields.push({
//       label: AMOUNT_LABEL,
//       value: `${amountField.value} ${currencyField?.value || ''}`,
//       isAmount: true, // Custom flag for styling
//     });
//   }

//   return (
//     <View style={styles.purchaseCard}>
//       {/* Main Row Container - Aligns Left Section and Right Section */}
//       <View style={styles.purchaseCardContent}>
//         {/* === START LEFT SECTION (Image + Details) === */}
//         <View style={styles.purchaseLeftSectionContainer}>
//           {/* Product Image */}
//           <Image
//             source={
//               !item?.product_image
//                 ? {uri: item.product_image}
//                 : require('../../assets/images/ic_maggi.png')
//             }
//             style={styles.purchaseProductImage}
//             resizeMode="contain"
//           />

//           {/* Left Fields: Product Name, Quantity & Combined Weight */}
//           <View style={styles.purchaseDetails}>
//             {finalLeftFields.map((field, index) => (
//               <Text
//                 key={field.label + index} // Use label + index for key
//                 style={[
//                   styles.purchaseDetailText,
//                   field.label === PRODUCT_NAME_LABEL &&
//                     styles.purchaseProductName,
//                 ]}>
//                 {/* Product Name value is displayed without a label prefix */}
//                 {field.label !== PRODUCT_NAME_LABEL ? (
//                   <>
//                     <Text style={{fontWeight: 'bold'}}>{field.label}: </Text>
//                     {field.value}
//                   </>
//                 ) : (
//                   // Product Name value alone (styled by purchaseProductName)
//                   field.value
//                 )}
//               </Text>
//             ))}
//           </View>
//         </View>
//         {/* === END LEFT SECTION === */}

//         {/* === START RIGHT SECTION (Ordered On, Paid Via, Amount) === */}
//         <View style={styles.purchaseRightSection}>
//           {/* Map through the right fields */}
//           {finalRightFields.map((field, index) => (
//             <Text
//               key={field.label + index}
//               style={[
//                 styles.purchaseDetailText,
//                 // Apply the bold style for the combined Amount field
//                 field.isAmount && styles.purchaseAmount,
//               ]}>
//               <Text style={{fontWeight: 'bold'}}>{field.label}: </Text>
//               {field.value}
//             </Text>
//           ))}
//         </View>
//         {/* === END RIGHT SECTION === */}
//       </View>
//     </View>
//   );
// };

// // --- STYLESHEET ---

// const styles = StyleSheet.create({
//   purchaseCard: {
//     backgroundColor: CARD_BG,
//     borderRadius: 12,
//     padding: 16,
//     marginHorizontal: 16,
//     marginBottom: 16,
//     shadowColor: '#000',
//     shadowOffset: {width: 0, height: 2},
//     shadowOpacity: 0.1,
//     shadowRadius: 4,
//     elevation: 3,
//   },

//   // MODIFIED: Use space-between to push left and right sections apart
//   purchaseCardContent: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'flex-start',
//   },

//   // NEW STYLE: Container for Image + Left Details
//   purchaseLeftSectionContainer: {
//     flexDirection: 'row', // Aligns Image and Details horizontally
//     alignItems: 'flex-start',
//     flexShrink: 1, // Allows this section to shrink if needed
//   },

//   purchaseProductImage: {
//     width: 70,
//     height: 80,
//     borderRadius: 6,
//     marginRight: 12,
//     borderWidth: 1,
//     borderColor: SECONDARY_COLOR,
//   },

//   purchaseDetails: {
//     marginRight: 10,
//     justifyContent: 'flex-start',
//   },

//   // MODIFIED: Takes remaining space and aligns content to the right
//   purchaseRightSection: {
//     flex: 1,
//     alignItems: 'flex-end', // Aligns the Text components to the right
//     marginLeft: 10,
//   },

//   // Style for the main product name on the left
//   purchaseProductName: {
//     fontSize: 15,
//     fontWeight: 'bold',
//     color: DARK_TEXT,
//     marginBottom: 4,
//     textAlign: 'left',
//   },

//   purchaseDetailText: {
//     fontSize: 13,
//     color: GRAY_TEXT,
//     marginBottom: 2,
//     // Note: No explicit textAlign here allows the content on the right to align right via alignItems: 'flex-end'
//   },

//   // Style for the bold amount on the right
//   purchaseAmount: {
//     fontSize: 16,
//     fontWeight: 'bold',
//     color: DARK_TEXT,
//     textAlign: 'right',
//   },

//   // Retained original styles for backward compatibility
//   purchaseOrderDate: {
//     fontSize: 13,
//     color: GRAY_TEXT,
//     marginBottom: 4,
//   },
//   purchasePayment: {
//     fontSize: 13,
//     color: GRAY_TEXT,
//     marginBottom: 4,
//     textAlign: 'right',
//   },
// });

// export default PurchaseNewOrderCard;
//

//

//
