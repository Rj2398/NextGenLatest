import {Button, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {useNavigation} from '@react-navigation/native';

const TemporaryScreen = () => {
  const navigation = useNavigation();
  return (
    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
      <Button
        title="HelpCenter"
        onPress={() => navigation.navigate('HelpCenter')}
      />

      <Button
        title="REview screen"
        onPress={() => navigation.navigate('Return')}
      />
      <Button
        title="Confirm Pickup"
        onPress={() => navigation.navigate('ConfirmPickup')}
      />
    </View>
  );
};

export default TemporaryScreen;

const styles = StyleSheet.create({});
