import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Dimensions,
} from 'react-native';

import COLORS from '../../../config/colors';
import DropdownGroup from '../../components/DropdownGroup';
import useProductModal from '../../../hooks/useProduct';
import {fetchChildCategories} from '../../../utils/apiFunction';
import PriceRangeDropdown from '../../components/PriceRangeDropdown';
import DatePickerInput from '../../components/DatePickerInput';
import useDashboard from '../../../hooks/useDashboard';
import {extractFieldLabelMapForPage} from '../../../utils/modal/customCodeModal';
import Loader from '../../components/Loader';

const {height: screenHeight} = Dimensions.get('window');

const BottomSheetFilter = ({isVisible, onClose, exportData}) => {
  //

  const {filterUIApi, isLoadingFilterUI} = useDashboard();

  const filterDynamicLabel = extractFieldLabelMapForPage(filterUIApi);

  const {getCategory} = useProductModal();
  const [categoryId, setCategoryId] = useState('');
  const [subcategoryId, setSubcategoryId] = useState('');
  const [labelCategory, setSelectLabel] = useState('');
  const [dataList, setDataList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [subcategories, setSubcategories] = useState([]);
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [dateCalender, setDateCalender] = useState(null);
  const rawCategoryItems = getCategory?.items ?? [];
  const mappedCategoryOptions = rawCategoryItems.map(item => ({
    value: String(item.id),
    label: item.name,
  }));

  const mappedSubcategoryOptions = subcategories.map(item => ({
    value: String(item.id),
    label: item.name,
  }));

  // Category selection + fetch subcategories
  const handleCategorySelect = async selectedId => {
    setCategoryId(selectedId);
    setSubcategoryId(''); // reset previous subcategory

    try {
      const response = await fetchChildCategories(
        '/api/v1/Category',
        selectedId,
        'parentId',
      );

      const subcategoryItems = response?.data?.items ?? [];

      setSubcategories(subcategoryItems);
    } catch (err) {
      setSubcategories([]);
    }
  };

  if (!isVisible) return null;

  const priceOptions = [
    {label: '₹29', value: 29},
    {label: '₹39', value: 39},
    {label: '₹40', value: 40},
    {label: '₹59', value: 59},
  ];

  const SearchProduct = async () => {
    try {
      setLoading(true);

      const query = {
        // "max_price": maxPrice,
        // "min_price": minPrice,
        categoryid: categoryId,
        producttitle: labelCategory,
        // "subcategory_id": subcategories,
        // dateCalender,
      };

      const response = await fetchChildCategories(
        '/api/v1/Products',
        query,
        'PageName=Inventory_Product_List&fieldQuery',
      );
      exportData(response.data?.items);
      setDataList(response.data?.items);
      console.log(response.data?.items, '&&&&&&&&&&&&&&&&&&&');
    } catch (error) {
      console.log('SearchProduct Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.overlay}>
      <Loader visible={isLoadingFilterUI} />
      <TouchableOpacity
        style={styles.backdrop}
        onPress={onClose}
        activeOpacity={1}
      />

      <View style={styles.sheetCard}>
        <View style={styles.header}>
          <Text style={styles.title}>{filterDynamicLabel?.search_filter}</Text>

          <TouchableOpacity
            onPress={() => {
              setCategoryId('');
              setSubcategoryId('');
              setSubcategories([]);
              setDateCalender(null);
              setMinPrice('');
              setMaxPrice('');

              onClose();
            }}>
            <Text style={styles.resetText}>
              {filterDynamicLabel?.reset_all}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Category */}
        <Text style={styles.categoryLabel}>
          {filterDynamicLabel?.category_id}
        </Text>
        <View style={{marginTop: -20}}>
          <DropdownGroup
            value={categoryId}
            options={mappedCategoryOptions}
            onSelectLabel={setSelectLabel}
            onSelect={handleCategorySelect} // Still works
            placeholder={filterDynamicLabel?.category_id_placeholder}
          />
        </View>

        <View style={{marginTop: -20}}>
          {/* Subcategory */}
          <DropdownGroup
            value={subcategoryId}
            options={mappedSubcategoryOptions}
            onSelect={setSubcategoryId}
            placeholder={'Suppliers'}
            onSelectLabel={label => console.log('Selected label:', label)}
          />
        </View>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <PriceRangeDropdown
            label={filterDynamicLabel?.min_price}
            value={minPrice}
            options={priceOptions}
            onSelect={setMinPrice}
            placeholder={filterDynamicLabel?.min_price_placeholder}
          />
          <PriceRangeDropdown
            label={filterDynamicLabel?.max_price}
            value={maxPrice}
            options={priceOptions}
            onSelect={setMaxPrice}
            placeholder={filterDynamicLabel?.max_price_placeholder}
          />
        </View>

        <DatePickerInput
          label="Select Date"
          value={dateCalender}
          onDateChange={setDateCalender}
        />

        <TouchableOpacity
          style={styles.applyButton}
          onPress={() => {
            SearchProduct();

            onClose();
          }}>
          <Text style={styles.applyButtonText}>
            {filterDynamicLabel?.ApplyFilters}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// --- Stylesheet for Bottom Sheet (Using Colors Object) ---
const styles = StyleSheet.create({
  // Styles for the full-screen transparent container
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: COLORS.overlayDark, // Using color variable
    justifyContent: 'flex-end',
    zIndex: 100,
  },
  // Backdrop
  backdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: screenHeight * 0.4,
  },
  // The sheet card styling
  sheetCard: {
    backgroundColor: COLORS.white, // Using color variable
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    ...Platform.select({
      ios: {
        shadowColor: COLORS.darkText, // Using color variable
        shadowOffset: {width: 0, height: -5},
        shadowOpacity: 0.15,
        shadowRadius: 10,
      },
      android: {
        elevation: 10,
      },
    }),
  },

  // --- Inner Component Styles ---
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingBottom: 5,
  },
  title: {
    fontSize: 20,
    fontWeight: '500',
    fontFamily: 'Roboto',
    color: COLORS.darkText, // Using color variable
  },
  resetText: {
    fontSize: 14,
    fontWeight: '500',
    fontFamily: 'Roboto',
  },
  categoryLabel: {
    fontSize: 14,
    color: COLORS.mediumText, // Using color variable
    marginBottom: 8,
    marginTop: 5,
    fontWeight: '500',
    fontFamily: 'Roboto',
  },
  // Custom Select Box Styles
  selectBox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.BORDER_COLOR, // Using color variable
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 12,
    marginBottom: 15,
    backgroundColor: COLORS.white, // Using color variable
  },
  selectText: {
    fontSize: 12,
    color: COLORS.darkGray, // Using color variable
  },
  // Styles for the two-column layout
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  halfWidth: {
    width: '48%',
    marginBottom: 15,
  },
  // Apply Button Styles
  applyButton: {
    backgroundColor: COLORS.PRIMARY_COLOR, // Using color variable
    borderRadius: 8,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 20,
  },
  applyButtonText: {
    color: COLORS.white, // Using color variable
    fontSize: 18,
    fontWeight: '700',
    fontFamily: 'Roboto',
  },
});

export default BottomSheetFilter;

///

///imp

// import React from 'react';
// import {
//   StyleSheet,
//   Text,
//   View,
//   ScrollView,
//   TouchableOpacity,
//   Modal,
// } from 'react-native';

// /* ------------------------------------------------------------------ */
// /* -------------------- DYNAMIC DATA/SCHEMA ------------------------- */
// /* ------------------------------------------------------------------ */

// // 1. Paste the API response JSON here
// const API_RESPONSE = {
//   pageId: 47,
//   pageName: 'Inventory_Search_Filter',
//   title: 'Search and Filter',
//   subtitle: 'Search and filter products in inventory',
//   description: '',
//   order: 1,
//   sections: [
//     {
//       id: 92,
//       name: 'SearchBox',
//       type: 'normal',
//       title: 'Search Products',
//       description: 'Search for products by title, description, SKU, or brand',
//       order: 1,
//       fields: [
//         {
//           id: 450,
//           fieldName: 'search_query',
//           fieldType: 'Text',
//           isRequired: false,
//           isReadOnly: false,
//           displayOrder: 1,
//           isVisible: true,
//           label: 'Search Products',
//           placeholder: 'Search by product title, description, SKU, or brand',
//           localization: {
//             localizedText: 'Search Products',
//             localizedPlaceholder:
//               'Search by product title, description, SKU, or brand',
//           },
//         },
//         {
//           id: 451,
//           fieldName: 'search_filter',
//           fieldType: 'FilterIconPopUp',
//           isRequired: false,
//           isReadOnly: false,
//           displayOrder: 2,
//           isVisible: true,
//           label: 'Filter',
//           placeholder: 'Open filter options',
//           localization: {
//             localizedText: 'Filter',
//             localizedPlaceholder: 'Open filter options',
//           },
//         },
//       ],
//       buttons: [],
//     },
//     {
//       id: 93,
//       name: 'Filters',
//       type: 'filter',
//       title: 'Filter Products',
//       description:
//         'Filter products by category, brand, price range, and other criteria',
//       order: 2,
//       fields: [
//         {
//           id: 452,
//           fieldName: 'reset_all',
//           fieldType: 'link',
//           label: 'Reset All',
//           localization: {localizedText: 'Reset All'},
//         },
//         {
//           id: 453,
//           fieldName: 'category_id',
//           fieldType: 'Select',
//           label: 'Category',
//           placeholder: 'Select category',
//           localization: {
//             localizedText: 'Category',
//             localizedPlaceholder: 'Select category',
//           },
//         },
//         {
//           id: 454,
//           fieldName: 'brand',
//           fieldType: 'Select',
//           label: 'Brand',
//           placeholder: 'Select brand',
//           localization: {
//             localizedText: 'Brand',
//             localizedPlaceholder: 'Select brand',
//           },
//         },
//         {
//           id: 455,
//           fieldName: 'min_price',
//           fieldType: 'Number',
//           label: 'Minimum Price',
//           placeholder: 'Enter minimum price',
//           localization: {
//             localizedText: 'Minimum Price',
//             localizedPlaceholder: 'Enter minimum price',
//           },
//         },
//         {
//           id: 456,
//           fieldName: 'max_price',
//           fieldType: 'Number',
//           label: 'Maximum Price',
//           placeholder: 'Enter maximum price',
//           localization: {
//             localizedText: 'Maximum Price',
//             localizedPlaceholder: 'Enter maximum price',
//           },
//         },
//         {
//           id: 457,
//           fieldName: 'is_active',
//           fieldType: 'Checkbox',
//           label: 'Active Products Only',
//           localization: {localizedText: 'Active Products Only'},
//         },
//         {
//           id: 458,
//           fieldName: 'has_variants',
//           fieldType: 'Checkbox',
//           label: 'Products with Variants',
//           localization: {localizedText: 'Products with Variants'},
//         },
//         {
//           id: 459,
//           fieldName: 'ApplyFilters',
//           fieldType: 'button',
//           label: 'Apply Filters',
//           localization: {localizedText: 'Apply Filters'},
//         },
//       ],
//       buttons: [],
//     },
//   ],
//   data: null,
// };

// // 2. Helper function to extract and group the filter fields
// const parseFilterData = apiResponse => {
//   // Find the 'Filters' section
//   const filterSection = apiResponse.sections.find(s => s.name === 'Filters');

//   if (!filterSection) {
//     return {
//       title: 'Filters',
//       resetLinkText: 'Reset all',
//       fields: [],
//       applyButtonText: 'Apply Filters',
//     };
//   }

//   const fields = filterSection.fields || [];
//   const processedFields = [];

//   // Find the Reset All field to get the correct localization for the link
//   const resetField = fields.find(f => f.fieldType === 'link');
//   const resetLinkText = resetField?.localization?.localizedText || 'Reset all';

//   // Find the Apply Button field to get the correct localization for the button
//   const applyButtonField = fields.find(f => f.fieldType === 'button');
//   const applyButtonText =
//     applyButtonField?.localization?.localizedText || 'Apply Filters';

//   // Process fields, grouping sequential 'Number' fields (like min/max price)
//   for (let i = 0; i < fields.length; i++) {
//     const field = fields[i];

//     // Skip 'link' and 'button' fields as they are handled in the header/footer
//     if (field.fieldType === 'link' || field.fieldType === 'button') {
//       continue;
//     }

//     // Group two sequential 'Number' fields into a 'horizontal' pair
//     if (
//       field.fieldType === 'Number' &&
//       fields[i + 1] &&
//       fields[i + 1].fieldType === 'Number'
//     ) {
//       processedFields.push({
//         type: 'horizontal',
//         fields: [field, fields[i + 1]],
//       });
//       i++; // Skip the next field since it was just grouped
//     } else {
//       // Add all other field types (Select, Checkbox) as they are
//       processedFields.push(field);
//     }
//   }

//   return {
//     title: filterSection.title || 'Filters',
//     resetLinkText,
//     fields: processedFields,
//     applyButtonText,
//   };
// };

// // Extract the structured data using the parser
// const DYNAMIC_CONFIG = parseFilterData(API_RESPONSE);

// /* ------------------------------------------------------------------ */
// /* -------------------- STYLES FOR UI MATCH ------------------------- */
// /* ------------------------------------------------------------------ */
// const uiStyles = StyleSheet.create({
//   // --- Modal Specific Styles ---
//   overlay: {
//     flex: 1,
//     backgroundColor: 'rgba(0,0,0,0.4)',
//   },
//   sheet: {
//     position: 'absolute',
//     bottom: 0,
//     width: '100%',
//   },

//   // --- Filter Card/Container Styles ---
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     paddingHorizontal: 20,
//     paddingTop: 15,
//     borderTopLeftRadius: 20,
//     borderTopRightRadius: 20,
//     maxHeight: '100%', // Limit height to prevent full screen takeover
//   },

//   // --- Header Styles (Title and Reset Link) ---
//   header: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     paddingVertical: 10,
//   },
//   title: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     color: '#333',
//   },
//   resetLink: {
//     fontSize: 14,
//     color: '#333',
//     fontWeight: 'normal',
//   },

//   // --- Content and Field Styles ---
//   content: {
//     paddingVertical: 10,
//   },
//   fieldWrapper: {
//     marginBottom: 20,
//   },
//   label: {
//     fontSize: 16,
//     fontWeight: '600',
//     color: '#333',
//     marginBottom: 8,
//   },

//   // --- Input Visual Styles (for SelectField) ---
//   inputWrapper: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     borderWidth: 1,
//     borderColor: '#ddd',
//     borderRadius: 8,
//     backgroundColor: '#fff',
//     paddingHorizontal: 12,
//     paddingVertical: 10,
//   },
//   placeholderText: {
//     flex: 1,
//     fontSize: 16,
//     color: '#777',
//   },
//   dropdownArrow: {
//     fontSize: 20,
//     color: '#999',
//     marginLeft: 10,
//     // Unicode for a simple down arrow (▼)
//   },

//   // --- Horizontal Grouping Style ---
//   horizontalGroup: {
//     flexDirection: 'row',
//     marginBottom: 20,
//     justifyContent: 'space-between',
//   },

//   // --- Checkbox Styles ---
//   checkboxContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginBottom: 20,
//     paddingVertical: 5,
//   },
//   checkbox: {
//     width: 20,
//     height: 20,
//     borderRadius: 4,
//     borderWidth: 2,
//     borderColor: '#ddd',
//     marginRight: 10,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   checkedCheckbox: {
//     backgroundColor: '#FF7F43', // Checked color
//     borderColor: '#FF7F43',
//   },
//   checkboxLabel: {
//     fontSize: 16,
//     color: '#333',
//   },
//   checkboxCheckmark: {
//     color: '#fff',
//     fontWeight: 'bold',
//     fontSize: 14,
//   },

//   // --- Footer and Button Styles ---
//   footer: {
//     paddingVertical: 15,
//     borderTopWidth: 1,
//     borderTopColor: '#eee',
//   },
//   applyButton: {
//     backgroundColor: '#FF7F43', // Orange color from image
//     padding: 15,
//     borderRadius: 10,
//     alignItems: 'center',
//   },
//   applyButtonText: {
//     color: '#fff',
//     fontSize: 18,
//     fontWeight: 'bold',
//   },
// });

// /* ------------------------------------------------------------------ */
// /* ------------------- REUSABLE UI COMPONENTS ----------------------- */
// /* ------------------------------------------------------------------ */

// // Component for all Select/Number inputs (visual style)
// const SelectField = ({label, placeholder, isHalfWidth = false, fieldType}) => {
//   // Determine which field type is being rendered for logging/action purposes
//   const isNumber = fieldType === 'Number';

//   const fieldStyle = isHalfWidth
//     ? {flex: 1, marginRight: 10}
//     : uiStyles.fieldWrapper;

//   // Use localized text if available, otherwise fallback to generic label/placeholder
//   const effectiveLabel = label;
//   const effectivePlaceholder = placeholder || 'Select an option';

//   return (
//     <View style={fieldStyle}>
//       {effectiveLabel && <Text style={uiStyles.label}>{effectiveLabel}</Text>}
//       <TouchableOpacity
//         style={uiStyles.inputWrapper}
//         onPress={() =>
//           console.log(
//             `Opening ${
//               isNumber ? 'Number' : 'Select'
//             } modal for: ${effectiveLabel}`,
//           )
//         }>
//         <Text style={uiStyles.placeholderText}>{effectivePlaceholder}</Text>
//         {/* Only show dropdown arrow for Select type, not Number */}
//         {fieldType === 'Select' && (
//           <Text style={uiStyles.dropdownArrow}>&#x2304;</Text>
//         )}
//       </TouchableOpacity>
//     </View>
//   );
// };

// // Component for Checkbox fields
// const CheckboxField = ({label, fieldName}) => {
//   // In a real app, this would use a state hook (e.g., const [checked, setChecked] = useState(false);)
//   // We'll simulate 'checked' state based on 'is_active' for demonstration
//   const checked = fieldName === 'is_active';

//   return (
//     <TouchableOpacity
//       style={uiStyles.checkboxContainer}
//       onPress={() => console.log(`Toggling checkbox for: ${label}`)}>
//       <View style={[uiStyles.checkbox, checked && uiStyles.checkedCheckbox]}>
//         {checked && <Text style={uiStyles.checkboxCheckmark}>&#x2713;</Text>}
//       </View>
//       <Text style={uiStyles.checkboxLabel}>{label}</Text>
//     </TouchableOpacity>
//   );
// };

// // Component to render fields side-by-side (specifically for Min/Max Price group)
// const HorizontalPair = ({fields}) => (
//   <View style={uiStyles.horizontalGroup}>
//     {fields.map((field, index) => (
//       // For horizontal pairs, we use localizedText and localizedPlaceholder from the API
//       <SelectField
//         key={field.id}
//         label={field.localization.localizedText}
//         placeholder={field.localization.localizedPlaceholder}
//         fieldType={field.fieldType} // This will be 'Number'
//         isHalfWidth={true}
//         // The last element in the pair shouldn't have margin
//         style={{marginRight: index === 0 ? 10 : 0}}
//       />
//     ))}
//   </View>
// );

// /* ------------------------------------------------------------------ */
// /* -------------------- MAIN COMPONENT ------------------------------ */
// /* ------------------------------------------------------------------ */

// const BottomSheetFilter = ({isVisible, onClose}) => {
//   const {title, resetLinkText, fields, applyButtonText} = DYNAMIC_CONFIG;

//   // Renders a single field based on its 'type' or 'fieldType'
//   const renderDynamicField = field => {
//     // Handle the custom grouped type (Min/Max price)
//     if (field.type === 'horizontal') {
//       return <HorizontalPair key={field.fields[0].id} fields={field.fields} />;
//     }

//     // Handle individual fields based on API fieldType
//     const fieldProps = {
//       key: field.id,
//       label: field.localization.localizedText || field.label,
//       placeholder: field.localization.localizedPlaceholder || field.placeholder,
//       fieldType: field.fieldType,
//       fieldName: field.fieldName, // Needed for Checkbox
//     };

//     switch (field.fieldType) {
//       case 'Select':
//       case 'Number':
//         // These use the same visual component
//         return <SelectField {...fieldProps} />;
//       case 'Checkbox':
//         return <CheckboxField {...fieldProps} />;
//       default:
//         return null; // Ignore unknown field types
//     }
//   };

//   return (
//     <Modal
//       visible={true} // For demonstration, keep it visible
//       transparent
//       animationType="slide"
//       onRequestClose={onClose}>
//       {/* Dimmed Background to close the modal */}
//       <TouchableOpacity
//         style={uiStyles.overlay}
//         activeOpacity={1}
//         onPress={onClose}
//       />

//       {/* Bottom Sheet Container */}
//       <View style={uiStyles.sheet}>
//         <View style={uiStyles.container}>
//           {/* Header (Title and Reset Link) */}
//           <View style={uiStyles.header}>
//             <Text style={uiStyles.title}>{title}</Text>
//             <TouchableOpacity onPress={() => console.log('Reset All action')}>
//               <Text style={uiStyles.resetLink}>{resetLinkText}</Text>
//             </TouchableOpacity>
//           </View>

//           {/* Scrollable Filter Content */}
//           {/* Use ScrollView to ensure content doesn't overflow the screen */}
//           <ScrollView style={uiStyles.content}>
//             {fields.map(renderDynamicField)}

//             {/* Add some extra padding at the bottom for comfortable scrolling near the button */}
//             <View style={{height: 20}} />
//           </ScrollView>

//           {/* Footer (Apply Button) */}
//           <View style={uiStyles.footer}>
//             <TouchableOpacity
//               style={uiStyles.applyButton}
//               onPress={() => console.log('Apply Filters action')}>
//               <Text style={uiStyles.applyButtonText}>{applyButtonText}</Text>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </View>
//     </Modal>
//   );
// };

// export default BottomSheetFilter;
