import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Platform,
  Switch,
  Alert,
} from 'react-native';
import React, {useState} from 'react';

// Icon imports
import AntDesign from 'react-native-vector-icons/AntDesign';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import colors from '../../../config/colors';

// --- Constants ---
const PRIMARY_COLOR = colors.PRIMARY_COLOR;
const BORDER_COLOR = colors.BORDER_COLOR;
const TEXT_GRAY = colors.TEXT_GRAY;
const LIGHT_GRAY_BG = colors.LIGHT_GRAY_BG;
const ERROR_RED = colors.ERROR_RED;
const INFO_BLUE_BG = colors.INFO_BLUE_BG;

// Role definitions
const ROLES = [
  {
    key: 'Admin',
    label: 'Admin',
    access: 'Full Access',
    description:
      'Complete control over all settings and accounts including user management, billing, and all features.',
  },
  {
    key: 'Manager',
    label: 'Manager',
    access: 'Limited Admin',
    description:
      'Can manage team members, view reports, and access assigned modules.',
  },
  {
    key: 'Operator',
    label: 'Operator',
    access: 'Standard Access',
    description:
      'Access to assigned modules and basic functionality for daily operations.',
  },
];

// --- Sub-Components ---

// Component for a single form field group
const FormField = ({
  label,
  placeholder,
  value,
  onChangeText,
  required = true,
  keyboardType = 'default',
}) => (
  <View style={styles.inputGroup}>
    <Text style={styles.label}>
      {label}
      {required && <Text style={styles.required}>*</Text>}
    </Text>
    <TextInput
      style={styles.inputField}
      placeholder={placeholder}
      placeholderTextColor={TEXT_GRAY}
      value={value}
      onChangeText={onChangeText}
      keyboardType={keyboardType}
    />
  </View>
);

// Component for a single role option
const RoleOption = ({role, isSelected, onPress}) => (
  <TouchableOpacity
    style={[
      styles.roleCard,
      isSelected ? styles.roleCardSelected : styles.roleCardDefault,
    ]}
    onPress={() => onPress(role.key)}>
    <View style={styles.roleHeader}>
      <Text style={styles.roleLabel}>{role.label}</Text>
      <View
        style={[
          styles.roleAccessTag,
          {backgroundColor: isSelected ? 'white' : ERROR_RED},
        ]}>
        <Text
          style={[
            styles.roleAccessText,
            {color: isSelected ? PRIMARY_COLOR : 'white'},
          ]}>
          {role.access}
        </Text>
      </View>
    </View>
    <Text style={styles.roleDescription}>{role.description}</Text>
    {isSelected && (
      <Feather
        name="check-circle"
        size={20}
        color={PRIMARY_COLOR}
        style={styles.checkIcon}
      />
    )}
  </TouchableOpacity>
);

// --- Main Screen Component ---
const CreateOperator = ({navigation}) => {
  // State for Personal Information
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  // State for Professional Information
  const [jobTitle, setJobTitle] = useState('');
  const [selectedDepartments, setSelectedDepartments] = useState([
    'Academic Affairs',
  ]); // Simplified, as a multi-select is complex
  const [preferredLanguage, setPreferredLanguage] = useState('English');
  const [selectedRole, setSelectedRole] = useState('Operator');

  // State for Additional Settings
  const [sendInvitation, setSendInvitation] = useState(true);

  const handleSubmit = () => {
    if (
      !firstName ||
      !lastName ||
      !email ||
      !jobTitle ||
      selectedDepartments.length === 0
    ) {
      Alert.alert('Missing Fields', 'Please fill in all required fields.');
      return;
    }
    console.log('New Operator Data:', {
      firstName,
      lastName,
      email,
      phoneNumber,
      jobTitle,
      selectedDepartments,
      preferredLanguage,
      selectedRole,
      sendInvitation,
    });
    // In a real app, you would send this data to your backend API
    Alert.alert(
      'Success',
      `${firstName} ${lastName} created as ${selectedRole}!`,
    );
    // Optionally navigate back: navigation.goBack();
  };

  const handleDepartmentRemove = dept => {
    setSelectedDepartments(selectedDepartments.filter(d => d !== dept));
  };

  return (
    <View style={styles.fullContainer}>
      {/* --- Fixed Header --- */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}
          style={styles.backButton}>
          <AntDesign name="left" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Create Operator</Text>
        <View style={{width: 24}} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* --- Personal Information Section --- */}
        <Text style={styles.sectionHeader}>Personal Information</Text>
        <View style={styles.sectionCard}>
          <FormField
            label="First Name"
            placeholder="Enter first name"
            value={firstName}
            onChangeText={setFirstName}
          />
          <FormField
            label="Last Name"
            placeholder="Enter last name"
            value={lastName}
            onChangeText={setLastName}
          />
          <FormField
            label="Email Address"
            placeholder="Enter email address"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
          />

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Phone Number</Text>
            <View style={styles.phoneInputContainer}>
              {/* Simplified Country Code Input */}
              <View style={styles.countryCode}>
                <Text style={styles.countryCodeText}>+1</Text>
                <AntDesign
                  name="down"
                  size={14}
                  color="#333"
                  style={{marginLeft: 5}}
                />
              </View>
              <TextInput
                style={styles.phoneInputField}
                placeholder="Phone number"
                placeholderTextColor={TEXT_GRAY}
                value={phoneNumber}
                onChangeText={setPhoneNumber}
                keyboardType="phone-pad"
              />
            </View>
          </View>
        </View>

        {/* --- Professional Information Section --- */}
        <Text style={styles.sectionHeader}>Professional Information</Text>
        <View style={styles.sectionCard}>
          <FormField
            label="Job Title"
            placeholder="Enter job title"
            value={jobTitle}
            onChangeText={setJobTitle}
          />

          {/* Department Selector */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>
              Department(s)<Text style={styles.required}>*</Text>
            </Text>
            {/* Display selected tags */}
            <View style={styles.tagContainer}>
              {selectedDepartments.map(dept => (
                <View key={dept} style={styles.deptTag}>
                  <Text style={styles.deptTagText}>{dept}</Text>
                  <TouchableOpacity
                    onPress={() => handleDepartmentRemove(dept)}
                    style={{paddingLeft: 5}}>
                    <Feather name="x" size={14} color={PRIMARY_COLOR} />
                  </TouchableOpacity>
                </View>
              ))}
              {/* Dropdown for selecting more departments */}
              <TouchableOpacity style={styles.departmentDropdown}>
                <Text style={styles.departmentText}>
                  Select or deselect departments
                </Text>
                <AntDesign name="down" size={16} color={TEXT_GRAY} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Preferred Language Radio Buttons */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Preferred Language</Text>
            <View style={styles.radioContainer}>
              <TouchableOpacity
                style={styles.radioOption}
                onPress={() => setPreferredLanguage('English')}>
                <MaterialCommunityIcons
                  name={
                    preferredLanguage === 'English'
                      ? 'radiobox-marked'
                      : 'radiobox-blank'
                  }
                  size={20}
                  color={
                    preferredLanguage === 'English' ? PRIMARY_COLOR : TEXT_GRAY
                  }
                />
                <Text style={styles.radioText}>English</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.radioOption}
                onPress={() => setPreferredLanguage('Arabic')}>
                <MaterialCommunityIcons
                  name={
                    preferredLanguage === 'Arabic'
                      ? 'radiobox-marked'
                      : 'radiobox-blank'
                  }
                  size={20}
                  color={
                    preferredLanguage === 'Arabic' ? PRIMARY_COLOR : TEXT_GRAY
                  }
                />
                <Text style={styles.radioText}>Arabic</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* --- Role Assignment Section --- */}
        <Text style={styles.sectionHeader}>Role Assignment</Text>
        <View style={styles.sectionCard}>
          {ROLES.map(role => (
            <RoleOption
              key={role.key}
              role={role}
              isSelected={selectedRole === role.key}
              onPress={setSelectedRole}
            />
          ))}
        </View>

        {/* --- Additional Settings Section --- */}
        <Text style={styles.sectionHeader}>Additional Settings</Text>
        <View style={[styles.sectionCard, {paddingVertical: 15}]}>
          {/* Send Invitation Email Toggle */}
          <View style={styles.toggleRow}>
            <View style={{flex: 1}}>
              <Text style={styles.toggleLabel}>Send Invitation Email</Text>
              <Text style={styles.toggleHelpText}>
                User will receive setup instructions via email.
              </Text>
            </View>
            <Switch
              trackColor={{false: BORDER_COLOR, true: PRIMARY_COLOR}}
              thumbColor={sendInvitation ? 'white' : '#f4f3f4'}
              ios_backgroundColor={BORDER_COLOR}
              onValueChange={setSendInvitation}
              value={sendInvitation}
            />
          </View>

          {/* Access Notice Box */}
          <View style={styles.noticeBox}>
            <Ionicons
              name="information-circle"
              size={20}
              color={PRIMARY_COLOR}
            />
            <Text style={styles.noticeText}>
              This operator will have access to student data and personal
              accounts. Ensure compliance with **privacy policies**.
            </Text>
          </View>
        </View>

        {/* Spacer for fixed footer */}
        <View style={{height: 100}} />
      </ScrollView>

      {/* --- Fixed Footer Buttons --- */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.cancelButton}
          onPress={() => {
            /* navigation.goBack() */
          }}>
          <Text style={styles.cancelText}>Cancel</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitText}>Create Operator</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default CreateOperator;

// --- Stylesheet ---
const styles = StyleSheet.create({
  fullContainer: {
    flex: 1,
    backgroundColor: LIGHT_GRAY_BG,
  },
  // --- Header Styles ---
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 15,
    backgroundColor: 'white',
    paddingTop: Platform.OS === 'ios' ? 50 : 15,
    borderBottomWidth: 1,
    borderBottomColor: BORDER_COLOR,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  backButton: {
    padding: 5,
  },
  scrollContent: {
    paddingHorizontal: 15,
    paddingVertical: 10,
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
    marginTop: 15,
    marginBottom: 8,
  },
  sectionCard: {
    backgroundColor: 'white',
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
  },
  // --- Form Field Styles ---
  inputGroup: {
    paddingVertical: 10,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginBottom: 5,
  },
  required: {
    color: ERROR_RED,
  },
  inputField: {
    fontSize: 15,
    color: '#333',
    padding: 10,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
    borderRadius: 8,
    backgroundColor: LIGHT_GRAY_BG,
    height: 45,
  },
  // --- Phone Input Specific Styles ---
  phoneInputContainer: {
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: BORDER_COLOR,
    borderRadius: 8,
    backgroundColor: LIGHT_GRAY_BG,
    height: 45,
    overflow: 'hidden',
  },
  countryCode: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    backgroundColor: 'white',
    borderRightWidth: 1,
    borderRightColor: BORDER_COLOR,
  },
  countryCodeText: {
    fontSize: 15,
    color: '#333',
    fontWeight: '500',
  },
  phoneInputField: {
    flex: 1,
    fontSize: 15,
    color: '#333',
    paddingHorizontal: 10,
  },
  // --- Department Tags ---
  tagContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
  },
  deptTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: PRIMARY_COLOR + '10', // Light orange background
    borderRadius: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginRight: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: PRIMARY_COLOR,
  },
  deptTagText: {
    fontSize: 13,
    color: PRIMARY_COLOR,
    fontWeight: '600',
  },
  departmentDropdown: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
    borderRadius: 8,
    backgroundColor: LIGHT_GRAY_BG,
    height: 45,
    marginTop: 5,
    width: '100%',
  },
  departmentText: {
    fontSize: 15,
    color: TEXT_GRAY,
  },
  // --- Language Radio Buttons ---
  radioContainer: {
    flexDirection: 'row',
  },
  radioOption: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
  },
  radioText: {
    fontSize: 15,
    color: '#333',
    marginLeft: 5,
  },
  // --- Role Assignment Cards ---
  roleCard: {
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    position: 'relative',
  },
  roleCardDefault: {
    backgroundColor: LIGHT_GRAY_BG,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
  },
  roleCardSelected: {
    backgroundColor: PRIMARY_COLOR + '10', // Light orange
    borderWidth: 1,
    borderColor: PRIMARY_COLOR,
  },
  roleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  roleLabel: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
    marginRight: 10,
  },
  roleAccessTag: {
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  roleAccessText: {
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  roleDescription: {
    fontSize: 13,
    color: TEXT_GRAY,
    paddingRight: 30, // Make room for the checkmark
  },
  checkIcon: {
    position: 'absolute',
    right: 15,
    top: 15,
  },
  // --- Additional Settings ---
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: BORDER_COLOR,
    marginBottom: 10,
  },
  toggleLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: '#333',
  },
  toggleHelpText: {
    fontSize: 12,
    color: TEXT_GRAY,
    marginTop: 2,
  },
  noticeBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: INFO_BLUE_BG,
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  noticeText: {
    fontSize: 13,
    color: '#333',
    marginLeft: 10,
    flexShrink: 1,
  },
  // --- Fixed Footer Buttons ---
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    padding: 15,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: BORDER_COLOR,
    paddingBottom: Platform.OS === 'ios' ? 30 : 15,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: BORDER_COLOR,
    paddingVertical: 12,
    marginRight: 10,
    alignItems: 'center',
  },
  cancelText: {
    fontSize: 16,
    fontWeight: '600',
    color: TEXT_GRAY,
  },
  submitButton: {
    flex: 1,
    backgroundColor: PRIMARY_COLOR,
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
  },
  submitText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
  },
});
