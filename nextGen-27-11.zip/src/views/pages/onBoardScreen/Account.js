import React, {useState} from 'react';
import {
  View,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Text,
  TextInput,
  Platform,
  Image,
} from 'react-native';
import Header from '../../components/Header';

// --- Define Colors and Constants ---
const PRIMARY_COLOR = '#FFAF66'; // The custom orange color
const SURFACE_COLOR = '#FFFFFF';
const BACKGROUND_COLOR = '#F5F5F5';
const TEXT_COLOR = '#1F2937';
const PLACEHOLDER_COLOR = '#ADAEBC';
const BORDER_COLOR = '#E5E7EB';
const ACCENT_TEXT_COLOR = '#6B7280';

// --- Custom Components for Reusability ---

/**
 * Custom Input Component to handle common styling
 */
const CustomTextInput = ({
  label,
  placeholder,
  value,
  onChangeText,
  multiline,
  keyboardType,
  required,
  style,
}) => (
  <View style={[styles.inputContainer, style]}>
    {label && (
      <Text style={styles.label}>
        {label} {required && <Text style={{color: '#1F2937'}}>*</Text>}
      </Text>
    )}
    <TextInput
      style={[
        styles.input,
        multiline && styles.multilineInput,
        {borderColor: BORDER_COLOR},
      ]}
      placeholder={placeholder}
      placeholderTextColor={PLACEHOLDER_COLOR}
      value={value}
      onChangeText={onChangeText}
      multiline={multiline}
      keyboardType={keyboardType || 'default'}
    />
  </View>
);

/**
 * Mock component for a Dropdown/Picker
 */
const InstituteTypeSelect = ({value, onValueChange, label, required}) => {
  const [open, setOpen] = useState(false);

  return (
    <View style={styles.inputContainer}>
      <Text style={[styles.label, {color: '#1F2937'}]}>
        {label} {required && <Text style={{color: '#1F2937'}}>*</Text>}
      </Text>
      <TouchableOpacity
        style={[styles.pickerContainer, {borderColor: BORDER_COLOR}]}
        onPress={() => setOpen(!open)}>
        <Text style={styles.pickerText}>
          {value || 'Select Institute Type'}
        </Text>
        <Image
          // 💡 Path Updated
          source={require('../../../assets/down_arrow_black.png')}
          style={styles.downImage}
          resizeMode="contain"
        />
      </TouchableOpacity>
      {/* Mocking the opened state */}
      {open && (
        <View style={styles.dropdownMock}>
          <Text
            style={styles.dropdownOption}
            onPress={() => {
              onValueChange('University');
              setOpen(false);
            }}>
            University
          </Text>
          <Text
            style={styles.dropdownOption}
            onPress={() => {
              onValueChange('College');
              setOpen(false);
            }}>
            College
          </Text>
        </View>
      )}
    </View>
  );
};

/**
 * Collapsible Section Component
 */
const CollapsibleSection = ({title, children, expanded: initialExpanded}) => {
  const [expanded, setExpanded] = useState(initialExpanded);

  return (
    <View style={styles.sectionContainer}>
      <TouchableOpacity
        style={[
          styles.sectionHeader,
          {backgroundColor: PRIMARY_COLOR},
          {margin: 15},
        ]}
        onPress={() => setExpanded(!expanded)}>
        <Text style={styles.sectionTitle}>{title}</Text>
        <Image
          // 💡 Path Updated
          source={require('../../../assets/down_arrow.png')}
          style={styles.downImage}
          resizeMode="contain"
        />
        {/* <Icon name={expanded ? 'chevron-up' : 'chevron-down'} size={24} color="#FFF" /> */}
      </TouchableOpacity>
      {expanded && <View style={styles.sectionContent}>{children}</View>}
    </View>
  );
};

// --- Primary Screen Component ---

const Account = () => {
  // --- State for Form Fields ---
  const [instituteName, setInstituteName] = useState('');
  const [instituteType, setInstituteType] = useState('');
  const [establishmentYear, setEstablishmentYear] = useState('');
  const [description, setDescription] = useState('');

  const [streetAddress, setStreetAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zip, setZip] = useState('');
  const [country, setCountry] = useState('Country');

  const [email, setEmail] = useState('instituinfo@email.com');
  const [phone, setPhone] = useState('+1 8884 03 4567');
  const [website, setWebsite] = useState('www.instinfo.com');
  const [linkedin, setLinkedin] = useState('linkedin.com/company/instinfo');

  return (
    <View style={styles.container}>
      {/* Header */}

      <Header title={'Institute Info'} onBackPress={true} />

      {/* Scrollable Content */}
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        {/* 1. Main Information Section */}
        <CollapsibleSection title="Main Information" expanded={true}>
          <View style={styles.profileContainer}>
            <Image
              // 💡 Path Updated
              source={require('../../../assets/account_place.png')}
              style={styles.profileImage}
              resizeMode="contain"
            />

            <Text style={styles.avatarText}>Institute Logo</Text>
          </View>

          <CustomTextInput
            label="Institute Name"
            required
            value={instituteName}
            onChangeText={setInstituteName}
            placeholder="Enter institute name"
          />

          <InstituteTypeSelect
            label="Institute Type"
            required
            value={instituteType}
            onValueChange={setInstituteType}
          />

          <CustomTextInput
            label="Establishment Year"
            value={establishmentYear}
            onChangeText={setEstablishmentYear}
            keyboardType="numeric"
            placeholder="YYYY"
          />

          {/* Helper Text */}
          <Text style={styles.helperText}>
            When was your institute established?
          </Text>

          <CustomTextInput
            label="Description"
            value={description}
            onChangeText={setDescription}
            multiline
            style={styles.descriptionInput}
            placeholder="Write a brief description of your institute..."
          />

          <View style={styles.buttonGroup}>
            <TouchableOpacity
              style={[styles.button, {backgroundColor: '#F89941'}]}
              onPress={console.log('Save Main Info')}>
              <Text style={styles.buttonText}>Save</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.button,
                styles.outlineButton,
                {borderColor: '#E2E2E2', backgroundColor: '#FFF9F2'},
              ]}
              onPress={console.log('Cancel Main Info')}>
              <Text style={[styles.buttonTextcencel, {color: '#000000'}]}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </CollapsibleSection>

        {/* 2. Institute Address Section */}
        <CollapsibleSection title="Institute Address" expanded={true}>
          <CustomTextInput
            label="Street Address"
            required
            value={streetAddress}
            onChangeText={setStreetAddress}
            placeholder="Enter street address"
          />

          <View style={styles.row}>
            <CustomTextInput
              label="City"
              required
              value={city}
              onChangeText={setCity}
              placeholder="City"
              style={styles.halfInput}
            />
            <CustomTextInput
              label="State"
              required
              value={state}
              onChangeText={setState}
              placeholder="State"
              style={styles.halfInput}
            />
          </View>

          <View style={styles.row}>
            <CustomTextInput
              label="ZIP Code"
              required
              value={zip}
              onChangeText={setZip}
              keyboardType="numeric"
              placeholder="ZIP"
              style={styles.halfInput}
            />

            <View style={[styles.halfInput, {marginTop: 0}]}>
              <InstituteTypeSelect
                label="Country"
                required
                value={country}
                onValueChange={setCountry}
              />
            </View>
          </View>

          <View style={styles.buttonGroup}>
            <TouchableOpacity
              style={[styles.button, {backgroundColor: '#F89941'}]}
              onPress={console.log('Save Address')}>
              <Text style={styles.buttonText}>Save</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.button,
                styles.outlineButton,
                {borderColor: '#E2E2E2', backgroundColor: '#FFF9F2'},
              ]}
              onPress={console.log('Cancel Address')}>
              <Text style={[styles.buttonTextcencel, {color: '#000000'}]}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </CollapsibleSection>

        {/* 3. Contact Details Section */}
        <CollapsibleSection title="Contact Details" expanded={true}>
          {[
            {icon: 'account', value: email, setter: setEmail},
            {icon: 'phone', value: phone, setter: setPhone},
            {icon: 'web', value: website, setter: setWebsite},
            {icon: 'link', value: linkedin, setter: setLinkedin},
          ].map((item, index) => (
            <View key={index} style={styles.contactRow}>
              {/* <Icon name={item.icon} size={24} color={PRIMARY_COLOR} style={styles.contactIcon} /> */}
              <Image
                // 💡 Path Updated for localIcons object
                source={localIcons[item.icon]}
                style={{
                  width: 40,
                  height: 40,
                }}
                resizeMode="contain"
              />

              <TextInput
                placeholder={item.value}
                onChangeText={item.setter}
                style={styles.inputcontact}
                placeholderTextColor={PLACEHOLDER_COLOR}
              />
            </View>
          ))}

          <TouchableOpacity style={styles.addMoreLink}>
            <Text style={{color: '#F97316', fontSize: 14}}>
              + Add more link
            </Text>
          </TouchableOpacity>
        </CollapsibleSection>

        <View style={{height: 30}} />
      </ScrollView>
    </View>
  );
};

// 💡 Path Updated for the localIcons definition
const localIcons = {
  account: require('../../../assets/account_email.png'),
  web: require('../../../assets/web.png'),
  phone: require('../../../assets/phone.png'),
  link: require('../../../assets/link.png'),
  // add more images here ⬆️
};

export default Account;

// --- Stylesheet ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BACKGROUND_COLOR,
  },
  scrollViewContent: {
    padding: 16,
    paddingBottom: 50,
  },
  downImage: {width: 15, height: 15, marginEnd: 5},
  profileImage: {width: 100, height: 100, marginBottom: 5},

  headerIconContainer: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: TEXT_COLOR,
    textAlign: 'center',
    flex: 1,
  },

  // Section Styles
  sectionContainer: {
    backgroundColor: SURFACE_COLOR,
    borderRadius: 8,
    marginBottom: 20,
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: {width: 0, height: 1},
        shadowOpacity: 0.2,
        shadowRadius: 1.41,
      },
      android: {elevation: 2},
    }),
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    color: '#FFAF66',
    borderRadius: 8,
    padding: 15,
  },
  sectionTitle: {
    color: '#FFF',
    fontWeight: '500',
    fontFamily: 'Roboto',
    fontSize: 16,
  },
  sectionContent: {
    padding: 15,
  },

  // Main Info Styles
  profileContainer: {
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderColor: '#E5E7EB',
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: BACKGROUND_COLOR,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 5,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  avatarText: {
    fontSize: 12,
    fontFamily: 'Roboto',
    fontWeight: 600,
    color: ACCENT_TEXT_COLOR,
  },

  // Custom Input Styles
  inputContainer: {
    marginBottom: 15,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    fontFamily: 'Inter',
    marginBottom: 4,
    marginTop: 10,
    color: '#1F2937',
  },
  input: {
    borderWidth: 1,
    borderRadius: 4,
    fontFamily: 'Inter',
    fontWeight: 500,
    paddingHorizontal: 12,
    minHeight: 56, // Matches standard outlined input height
    fontSize: 16,
    color: TEXT_COLOR,
    backgroundColor: SURFACE_COLOR,
  },
  inputcontact: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 4,
    fontFamily: 'Inter',
    fontWeight: 500,
    paddingHorizontal: 12,
    minHeight: 56, // Matches standard outlined input height
    fontSize: 16,
    color: '#ADAEBC',
    borderColor: '#E5E7EB',
    marginStart: 10,
    backgroundColor: '#FFFFFF',
  },
  multilineInput: {
    minHeight: 100,
    paddingTop: 12, // Ensure text starts at the top
    textAlignVertical: 'top',
  },
  helperText: {
    marginTop: -15,
    marginBottom: 10,
    fontSize: 12,
    color: ACCENT_TEXT_COLOR,
  },
  descriptionInput: {
    marginBottom: 0, // CustomTextInput adds 15 by default, override it here
  },

  // Dropdown/Picker Mock Styles
  pickerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    padding: 12,
    borderRadius: 4,
    minHeight: 56,
  },
  pickerText: {
    fontSize: 16,
    color: TEXT_COLOR,
  },
  dropdownMock: {
    position: 'absolute',
    top: 60,
    left: 0,
    right: 0,
    backgroundColor: SURFACE_COLOR,
    borderWidth: 1,
    borderColor: '#CCC',
    zIndex: 10,
    borderRadius: 4,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: {width: 0, height: 1},
        shadowOpacity: 0.2,
        shadowRadius: 1.41,
      },
      android: {elevation: 2},
    }),
  },
  dropdownOption: {
    padding: 10,
    fontSize: 16,
    color: TEXT_COLOR,
  },

  // Row Styles (for Address section)
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15, // Input container already has margin, but this spaces the rows
  },
  halfInput: {
    width: '48%',
    marginBottom: 0, // Ensure the row controls the spacing
  },

  // Button Group Styles
  buttonGroup: {
    flexDirection: 'column',
    marginTop: 10,
  },
  button: {
    padding: 12,
    borderRadius: 4,
    alignItems: 'center',
    marginBottom: 10,
  },
  outlineButton: {
    borderWidth: 1,
    backgroundColor: 'transparent',
  },
  buttonText: {
    color: SURFACE_COLOR,
    fontWeight: 'bold',
    fontSize: 16,
  },
  buttonTextcencel: {
    color: '#000000',
    fontWeight: 'bold',
    fontSize: 16,
  },

  // Contact Details Styles
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    paddingVertical: 5,
  },
  contactIcon: {
    marginRight: 10,
  },
  contactInput: {
    flex: 1,
    backgroundColor: SURFACE_COLOR,
    paddingHorizontal: 0,
    fontSize: 16,
    height: 40,
    marginStart: 10,
    color: TEXT_COLOR,
  },
  addMoreLink: {
    borderWidth: 1,
    borderColor: '#F97316',
    borderStyle: 'dashed',
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginStart: 10,
    justifyContent: 'center',
  },
});
