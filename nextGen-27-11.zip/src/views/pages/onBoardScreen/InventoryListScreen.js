import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import React, {useState, useMemo, useEffect, useRef} from 'react';
import BottomSheetFilter from './BottomSheetFilter';
import DealsDiscountScreen from './DealsDiscountScreen';

const FilterIcon = require('../../../assets/filter_icon.png');
const ActiveFilterIcon = require('../../../assets/filter_fill.png');
import {useNavigation} from '@react-navigation/native';
import useDashboard from '../../../hooks/useDashboard';
import InventoryList from '../../components/InventoryList';
import {extractFieldLabelMapForPage} from '../../../utils/modal/customCodeModal';
import {fetchChildCategories} from '../../../utils/apiFunction';

// --- Dimensions for Card Width Calculation ---
const {width} = Dimensions.get('window');
const CARD_MARGIN = 8;

// --- Utility to convert a readable name to a machine key (e.g., "Low Stock" -> "low_stock") ---
const toKpiKey = name => {
  if (!name) return '';
  return name.toLowerCase().replace(/\s/g, '_');
};

// --- KPI Value Formatting Function (Updated to use kpi_name/kpi_value) ---
function formatKpiValue(kpi) {
  const value = kpi.kpi_value;
  const kpiKey = toKpiKey(kpi.kpi_name);

  // Since explicit type metadata is missing, we infer currency for these keys
  if (kpiKey === 'revenue' || kpiKey === 'cost') {
    const formattedValue = parseFloat(value).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    // Assuming AED as per typical context, or you can use '$'
    const currencySymbol = 'AED';
    return `${currencySymbol} ${formattedValue}`;
  } else if (!isNaN(parseFloat(value))) {
    const formattedValue = parseFloat(value).toLocaleString(undefined, {
      maximumFractionDigits: 0,
    });
    return formattedValue;
  }
  return value;
}

// --- KpiCard Component Definition (Updated to use kpi_name/kpi_value) ---
const KpiCard = ({item}) => {
  // Derive kpiKey from kpi_name for styling logic
  const kpiKey = toKpiKey(item.kpi_name);

  // Use the derived kpiKey for secondary styling
  const isSecondaryStyle =
    kpiKey === 'low_stock' || kpiKey === 'out_of_stock' || kpiKey === 'cost';

  // Pass the entire item object (with kpi_value) to formatter
  const formattedValue = formatKpiValue(item);
  const cardStyle = isSecondaryStyle ? styles.card2 : styles.card;
  const titleStyle = isSecondaryStyle ? styles.card2Title : styles.cardTitle;

  // Use kpi_period or fallback to kpi_description
  const subText = item.kpi_period || item.kpi_description || 'Overall';

  return (
    <View
      style={[
        cardStyle,
        {width: width / 2 - 24, marginHorizontal: CARD_MARGIN / 2},
      ]}>
      <Text style={titleStyle} numberOfLines={1}>
        {item.kpi_name} {/* 👈 Reading kpi_name */}
      </Text>
      <Text style={styles.cardValue}>{formattedValue}</Text>
      <Text style={styles.cardSub} numberOfLines={1}>
        {subText} {/* 👈 Reading kpi_period/kpi_description */}
      </Text>
    </View>
  );
};
// --- END KpiCard Component ---

const InventoryListScreen = () => {
  const {
    getDashboardList,
    isLoadingDashboard,
    getStuctDashboard,
    isLoadignStuctDashboard,
    filterUIApi,
    isLoadingFilterUI,
  } = useDashboard();
  const isFirstRender = useRef(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterVisible, setIsFilterVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const filterDynamicLabel = extractFieldLabelMapForPage(filterUIApi);

  const [dataList, setDataList] = useState([]);
  console.log(dataList, 'exported data');

  const navigation = useNavigation();
  const dashboardData = getDashboardList?.items || [];

  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      SearchProduct(searchQuery); // 🔥 instant API on mount
      return;
    }

    const timeout = setTimeout(() => {
      if (searchQuery !== '') {
        SearchProduct(searchQuery);
      }
    }, 500); // ⏳ 500ms debounce

    return () => clearTimeout(timeout);
  }, [searchQuery]);

  const SearchProduct = async query => {
    try {
      setLoading(true);

      const response = await fetchChildCategories(
        '/api/v1/Products',
        query,
        'PageName=Inventory_Product_List&Q',
      );

      setDataList(response?.data?.items || []);
    } catch (err) {
      setDataList([]); // reset list on error
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    SearchProduct();
  }, []);

  const openFilters = () => setIsFilterVisible(true);
  const closeFilters = () => setIsFilterVisible(false);

  const handlePressBulk = () => {
    navigation.navigate('BulkUpload');
  };
  const handlePressAddProduct = () => {
    navigation.navigate('AddNewProduct', {});
  };
  const handlePressDeals = () => {
    navigation.navigate('DealsDiscountScreen');
  };

  const renderKpiItem = ({item}) => <KpiCard item={item} />;

  return (
    <View style={styles.container}>
      {/* Search */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <Image
            source={require('../../../assets/search_icon.png')}
            style={styles.searchImage}
            resizeMode="contain"
          />
          <TextInput
            placeholder={filterDynamicLabel?.search_query_placeholder}
            placeholderTextColor="#888"
            style={styles.searchInput}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <TouchableOpacity onPress={openFilters}>
          <Image
            source={isFilterVisible ? ActiveFilterIcon : FilterIcon}
            style={styles.filterImage}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>

      <BottomSheetFilter
        isVisible={isFilterVisible}
        onClose={closeFilters}
        exportData={setDataList}
      />

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>Overall Inventory</Text>

        {/* Cards Grid - FlatList Implementation */}
        <FlatList
          data={dashboardData} // Using the FILTERED data
          keyExtractor={item => item.kpi_name} // 👈 Using kpi_name for key
          renderItem={renderKpiItem}
          numColumns={2}
          scrollEnabled={false}
          columnWrapperStyle={styles.cardRow}
          ListEmptyComponent={() =>
            !isLoadingDashboard &&
            dashboardData.length === 0 && (
              <Text style={styles.emptyText}>
                {searchQuery
                  ? `No results found for "${searchQuery}".`
                  : 'No inventory data available.'}
              </Text>
            )
          }
        />

        {isLoadingDashboard && (
          <ActivityIndicator
            size="large"
            color="#FF8719"
            style={{marginTop: 20}}
          />
        )}

        {/* Buttons and Deals Card... (rest of the component) */}
        <TouchableOpacity
          style={styles.orangeBtn}
          onPress={handlePressAddProduct}>
          <Image
            source={require('../../../assets/plus_icon.png')}
            style={styles.uploadImage}
            resizeMode="contain"
          />
          <Text style={[styles.btnText, {marginStart: 5}]}>
            Add New Products
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.orangeBtnLight}>
          <Text style={styles.btnText}>View all Products</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.uploadBtn} onPress={handlePressBulk}>
          <Image
            source={require('../../../assets/upload_icon.png')}
            style={styles.uploadImage}
            resizeMode="contain"
          />
          <Text style={[styles.btnText, {marginLeft: 6}]}>Bulk Upload</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.dealCard} onPress={handlePressDeals}>
          <Image
            source={require('../../../assets/cuppons_icon.png')}
            style={styles.discountImage}
            resizeMode="contain"
          />
          <Text style={styles.dealText}>Deals & Discount</Text>
          <Image
            source={require('../../../assets/arrow_icon.png')}
            style={styles.arrowImage}
            resizeMode="contain"
          />
        </TouchableOpacity>

        <InventoryList dataList={dataList} loading={loading} />
      </ScrollView>
    </View>
  );
};

export default InventoryListScreen;

// --- Stylesheet (Kept for completeness) ---
const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#fff', paddingHorizontal: 16},
  scrollContent: {
    paddingBottom: 100,
  },

  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffff',
    borderRadius: 8,
    borderColor: '#D7D7D7',
    borderWidth: 1,
    paddingHorizontal: 10,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    color: '#000',
    fontSize: 12,
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginVertical: 10,
    color: '#000',
  },

  cardRow: {
    justifyContent: 'space-between',
    marginBottom: 12,
  },

  card: {
    backgroundColor: '#fff7f0',
    borderColor: '#F89941',
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    height: 100,
    justifyContent: 'space-around',
  },
  card2: {
    backgroundColor: '#ffedee',
    borderColor: '#D24648',
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    height: 100,
    justifyContent: 'space-around',
  },
  cardTitle: {
    fontSize: 13,
    color: '#FF7A00',
    fontWeight: '500',
  },
  card2Title: {
    fontSize: 13,
    color: '#D24648',
    fontWeight: '500',
  },
  cardValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000',
    marginVertical: 4,
  },
  cardSub: {
    fontSize: 10,
    color: '#5F6368',
    fontWeight: '500',
  },

  orangeBtn: {
    backgroundColor: '#FF8719',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  orangeBtnLight: {
    backgroundColor: '#FFAF66',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  uploadBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFAF66',
    padding: 14,
    borderRadius: 10,
    marginTop: 10,
  },
  btnText: {color: '#fff', fontWeight: '600', fontSize: 14},

  dealCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFF',
    padding: 14,
    borderRadius: 10,
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#E2E2E2',
  },
  dealText: {fontWeight: '600', color: '#000', marginStart: 10},
  emptyText: {
    textAlign: 'center',
    color: '#888',
    marginTop: 20,
  },
  filterImage: {width: 50, height: 50, marginStart: 5, marginTop: 5},
  searchImage: {width: 25, height: 25, marginStart: 5},
  uploadImage: {width: 15, height: 15},
  discountImage: {width: 15, height: 15},
  arrowImage: {width: 15, height: 15, marginStart: 25, marginTop: 3},
});
