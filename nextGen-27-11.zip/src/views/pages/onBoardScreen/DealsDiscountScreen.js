import React, {useState, useEffect, useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Alert,
  Modal,
} from 'react-native';

// REQUIRED IMPORTS for Icons (Assuming react-native-vector-icons is used)
import Ionicons from 'react-native-vector-icons/Ionicons';
import Feather from 'react-native-vector-icons/Feather';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';

// Assuming these are standard imports in your project (Adjust paths as necessary)
import PrimaryButton from '../../components/PrimaryButton';
import Header from '../../components/Header';
import useDealForm from '../../../hooks/useDealForm';

const STATIC_DEALS_UI_CONFIG = {
  pageGroupName: 'Deals_List',
  title: 'Deals_List',
  description:
    'Complete deals list workflow with search, filter, list view, and product assignment',
  pages: [
    {
      pageId: 1,
      pageName: 'Ecommerce_Deals_SearchFilter',
      title: 'Search and Filter',
      subtitle: 'Search and filter deals',
      description: 'Search and Filter',
      order: 1,
      sections: [
        {
          id: 5001,
          name: 'SearchFilter',
          title: 'Search and Filter',
          description: 'Search and filter deals',
          order: 1,
          type: 'inline',
          fields: [
            {
              id: 5001,
              fieldName: 'search',
              fieldType: 'Text',
              label: 'Search',
              placeholder: 'Search deals',
              helpText: 'Search deals by name, description, or keywords',
              displayName: 'Search',
              isRequired: false,
              isReadOnly: false,
              isVisible: true,
              displayOrder: 1,
              maxLength: 200,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              fieldMetadata: {
                dataType: 'string',
                inputType: 'text',
                autocomplete: 'off',
                accessibility: {
                  ariaLabel: 'Search deals',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Search',
                localizedPlaceholder: 'Search deals',
                localizedHelpText: 'Search deals by name or keywords',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
            {
              id: 5002,
              fieldName: 'filter',
              fieldType: 'Select',
              label: 'Filter',
              placeholder: 'Select filter',
              helpText: 'Filter deals by category, status, or date',
              displayName: 'Filter',
              isRequired: false,
              isReadOnly: false,
              isVisible: true,
              displayOrder: 2,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              fieldMetadata: {
                dataType: 'string',
                inputType: 'select',
                accessibility: {
                  ariaLabel: 'Filter deals',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Filter',
                localizedPlaceholder: 'Select filter',
                localizedHelpText: 'Filter deals by status',
              },
              options: [
                {
                  value: 'all',
                  label: 'All Deals',
                },
                {
                  value: 'active',
                  label: 'Active',
                },
                {
                  value: 'expired',
                  label: 'Expired',
                },
              ],
              actions: null,
              isDefault: false,
            },
          ],
          buttons: [],
        },
      ],
    },
    {
      pageId: 2,
      pageName: 'Ecommerce_Deals_List_Deals',
      title: 'Deals List',
      subtitle: 'View and manage all deals',
      description: 'Deals List',
      order: 2,
      sections: [
        {
          id: 5102,
          name: 'CreateButton',
          title: '',
          description: '',
          order: 1,
          type: 'normal',
          fields: [
            {
              id: 5102,
              fieldName: 'btn_create',
              fieldType: 'Button',
              label: 'Create',
              placeholder: null,
              helpText: null,
              displayName: 'Create',
              isRequired: false,
              isReadOnly: false,
              isVisible: true,
              displayOrder: 1,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              apiCallRequired: true,
              method: 'POST',
              endpoint: '/api/v1/deals',
              fieldMetadata: {
                dataType: 'string',
                inputType: 'button',
                buttonType: 'button',
                accessibility: {
                  ariaLabel: 'Create deal button',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Create',
                localizedPlaceholder: null,
                localizedHelpText: 'Create a new deal',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
          ],
          buttons: [],
        },
        {
          id: 5103,
          name: 'DealCard',
          title: 'Deal Summary',
          description: 'Review deal information',
          order: 2,
          type: 'cardwithaction',
          fields: [
            {
              id: 5103,
              fieldName: 'title_label',
              fieldType: 'Text',
              label: 'Title',
              placeholder: null,
              helpText: null,
              displayName: 'Title',
              isRequired: false,
              isReadOnly: true,
              isVisible: true,
              displayOrder: 1,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              fieldMetadata: {
                dataType: 'string',
                inputType: 'text',
                accessibility: {
                  ariaLabel: 'Deal title label',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Title',
                localizedPlaceholder: null,
                localizedHelpText: 'Deal title',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
            {
              id: 5104,
              fieldName: 'subtitle_label',
              fieldType: 'Text',
              label: 'Subtitle',
              placeholder: null,
              helpText: null,
              displayName: 'Subtitle',
              isRequired: false,
              isReadOnly: true,
              isVisible: true,
              displayOrder: 2,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              fieldMetadata: {
                dataType: 'string',
                inputType: 'text',
                accessibility: {
                  ariaLabel: 'Deal subtitle label',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Subtitle',
                localizedPlaceholder: null,
                localizedHelpText: 'Deal subtitle',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
            {
              id: 5105,
              fieldName: 'description_label',
              fieldType: 'Text',
              label: 'Description',
              placeholder: null,
              helpText: null,
              displayName: 'Description',
              isRequired: false,
              isReadOnly: true,
              isVisible: true,
              displayOrder: 3,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              fieldMetadata: {
                dataType: 'string',
                inputType: 'text',
                accessibility: {
                  ariaLabel: 'Deal description label',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Description',
                localizedPlaceholder: null,
                localizedHelpText: 'Deal description',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
            {
              id: 5106,
              fieldName: 'labelchip1',
              fieldType: 'LabelChip',
              label: 'Offer',
              placeholder: null,
              helpText: null,
              displayName: 'Offer',
              isRequired: false,
              isReadOnly: true,
              isVisible: true,
              displayOrder: 4,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              fieldMetadata: {
                dataType: 'string',
                inputType: 'chip',
                accessibility: {
                  ariaLabel: 'Offer chip',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Offer',
                localizedPlaceholder: null,
                localizedHelpText: 'Deal offer chip',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
            {
              id: 5107,
              fieldName: 'labelchip2',
              fieldType: 'Text',
              label: 'Validity',
              placeholder: null,
              helpText: null,
              displayName: 'Validity',
              isRequired: false,
              isReadOnly: true,
              isVisible: true,
              displayOrder: 5,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              fieldMetadata: {
                dataType: 'string',
                inputType: 'chip',
                accessibility: {
                  ariaLabel: 'Validity chip',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Validity',
                localizedPlaceholder: null,
                localizedHelpText: 'Deal validity chip',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
            {
              id: 5108,
              fieldName: 'label1',
              fieldType: 'Text',
              label: 'From To',
              placeholder: null,
              helpText: null,
              displayName: 'From To',
              isRequired: false,
              isReadOnly: true,
              isVisible: true,
              displayOrder: 6,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              fieldMetadata: {
                dataType: 'string',
                inputType: 'text',
                accessibility: {
                  ariaLabel: 'From to date label',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'From To',
                localizedPlaceholder: null,
                localizedHelpText: 'Deal validity period from to dates',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
            {
              id: 5109,
              fieldName: 'btn_edit',
              fieldType: 'CardButton',
              label: 'Edit',
              placeholder: null,
              helpText: null,
              displayName: 'Edit',
              isRequired: false,
              isReadOnly: false,
              isVisible: true,
              displayOrder: 7,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              apiCallRequired: true,
              method: 'GET',
              endpoint: '/api/v1/deals',
              fieldMetadata: {
                dataType: 'string',
                inputType: 'button',
                buttonType: 'button_cardaction',
                actionType: 'edit',
                accessibility: {
                  ariaLabel: 'Edit deal button',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Edit',
                localizedPlaceholder: null,
                localizedHelpText: 'Edit deal information',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
            {
              id: 5110,
              fieldName: 'btn_delete',
              fieldType: 'CardButton',
              label: 'Delete',
              placeholder: null,
              helpText: null,
              displayName: 'Delete',
              isRequired: false,
              isReadOnly: false,
              isVisible: true,
              displayOrder: 8,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              apiCallRequired: true,
              method: 'DELETE',
              endpoint: '/api/v1/deals',
              fieldMetadata: {
                dataType: 'string',
                inputType: 'button',
                buttonType: 'button_cardaction',
                actionType: 'delete',
                accessibility: {
                  ariaLabel: 'Delete deal button',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Delete',
                localizedPlaceholder: null,
                localizedHelpText: 'Delete deal',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
            {
              id: 5111,
              fieldName: 'btn_assign_product',
              fieldType: 'CardButton',
              label: 'Assign Product',
              placeholder: null,
              helpText: null,
              displayName: 'Assign Product',
              isRequired: false,
              isReadOnly: false,
              isVisible: true,
              displayOrder: 9,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              apiCallRequired: true,
              method: 'POST',
              endpoint: '/api/v1/deals/products',
              fieldMetadata: {
                dataType: 'string',
                inputType: 'button',
                buttonType: 'button_slidenext',
                actionType: 'assignproduct',
                accessibility: {
                  ariaLabel: 'Assign Product button',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Assign Product',
                localizedPlaceholder: null,
                localizedHelpText: 'Assign products to deal',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
          ],
          buttons: [],
        },
      ],
    },
    {
      pageId: 3,
      pageName: 'Ecommerce_Deals_AssignProduct',
      title: 'Assign Product',
      subtitle: 'Assign products to deal',
      description: 'Assign Product',
      order: 3,
      sections: [
        {
          id: 5201,
          name: 'AssignProductAction',
          title: '',
          description: '',
          order: 1,
          type: 'normal',
          fields: [
            {
              id: 5201,
              fieldName: 'btn_assign_product',
              fieldType: 'Button',
              label: 'Assign Product',
              placeholder: null,
              helpText: null,
              displayName: 'Assign Product',
              isRequired: false,
              isReadOnly: false,
              isVisible: true,
              displayOrder: 1,
              maxLength: null,
              minLength: null,
              regexPattern: null,
              defaultValue: null,
              apiCallRequired: true,
              method: 'POST',
              endpoint: '/api/v1/deals/products',
              fieldMetadata: {
                dataType: 'string',
                inputType: 'button',
                buttonType: 'button',
                accessibility: {
                  ariaLabel: 'Assign Product button',
                  ariaRequired: false,
                },
              },
              localization: {
                languageCode: 'EN',
                countryCode: 'AE',
                localizedText: 'Assign Product',
                localizedPlaceholder: null,
                localizedHelpText: 'Assign products to deal',
              },
              options: null,
              actions: null,
              isDefault: false,
            },
          ],
          buttons: [],
        },
      ],
    },
  ],
};

// --- Centralized Color Palette ---
const Colors = {
  primaryOrange: '#ff9933',
  lightOrangeBg: '#fbe2c8',
  darkText: '#3D3A3A',
  mediumText: '#555',
  lightText: '#999',
  white: '#fff',
  lightBg: '#f5f5f5',
  borderColor: '#ddd',
  activeGreen: '#4CAF50',
  activeBg: '#E8F5E9',
  inactiveGray: '#eee',
  inputBorder: '#ccc',
  dangerRed: '#f44336',
};

// --- Helper Function to format ISO Date string ---
const formatDate = isoString => {
  if (!isoString) return 'N/A';
  const date = new Date(isoString);
  if (isNaN(date.getTime())) {
    return isoString.split('T')[0];
  }
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

// --- Reusable Component for Deal Card ---
const DealCard = ({deal, onDelete, onEdit, onAssignProduct, uiConfig}) => {
  // Dynamic data mapping from the API response object keys
  const dealName = deal.dealName || 'Sample Deal';
  const discountType = deal.discountType || 'Percentage';
  const discountValue = deal.discountValue || 15;
  const currencyCode = deal.currencyCode || 'USD';
  const startDate = deal.startDate || '2025-01-01T00:00:00Z';
  const endDate = deal.endDate || '2025-12-31T00:00:00Z';
  const status = deal.status || 'Active';
  const dealId = deal.id || 'D123';

  // Determine checkbox state based on status
  const isActive = status === 'Active'; // TRUE if status is 'Active'

  // Define colors and styles for status badges
  const statusBg = isActive ? Colors.activeBg : Colors.inactiveGray;
  const statusColor = isActive
    ? Colors.activeGreen
    : status === 'Expired'
    ? Colors.dangerRed
    : Colors.darkText;

  // Map JSON fields to display data
  let offerText = '';
  const offerField = uiConfig.find(f => f.fieldName === 'labelchip1');
  if (offerField) {
    if (discountType === 'Percentage') {
      offerText = `${discountValue}% OFF`;
    } else if (discountType === 'FixedAmount') {
      offerText = `${discountValue} ${currencyCode} OFF`;
    } else {
      offerText = discountType || 'N/A';
    }
  }

  const validityField = uiConfig.find(f => f.fieldName === 'label1');
  const validityText = validityField
    ? `From: ${formatDate(startDate)} - To: ${formatDate(endDate)}`
    : '';

  const [isMenuVisible, setIsMenuVisible] = useState(false);

  // Find action buttons from JSON config
  const editButtonConfig = uiConfig.find(f => f.fieldName === 'btn_edit');
  const deleteButtonConfig = uiConfig.find(f => f.fieldName === 'btn_delete');
  const assignButtonConfig = uiConfig.find(
    f => f.fieldName === 'btn_assign_product',
  );

  const handleDelete = () => {
    setIsMenuVisible(false);
    if (onDelete && deleteButtonConfig) {
      onDelete(
        dealId,
        deleteButtonConfig.endpoint,
        deleteButtonConfig.method,
        dealName,
      );
    }
  };

  const handleEdit = () => {
    setIsMenuVisible(false);
    // Log the complete deal object data to the console
    console.log('Edit Action: Deal Data');
    console.log(deal);
    // Log API details for context
    console.log(
      `Action: Edit selected for deal: ${dealName}. API: ${editButtonConfig?.method} ${editButtonConfig?.endpoint}`,
    );
    if (onEdit) onEdit(dealId, editButtonConfig?.endpoint);
  };

  const handleAssign = () => {
    setIsMenuVisible(false);
    // Log API details for context
    console.log(
      `Action: Assign Product selected for deal: ${dealName}. API: ${assignButtonConfig?.method} ${assignButtonConfig?.endpoint}`,
    );
    if (onAssignProduct) onAssignProduct(dealId, assignButtonConfig?.endpoint);
  };

  const ActionMenu = () => (
    <View style={styles.actionMenu}>
      {/* Edit Button */}
      {editButtonConfig && (
        <TouchableOpacity style={styles.menuItem} onPress={handleEdit}>
          <Text style={styles.menuText}>{editButtonConfig.label}</Text>
        </TouchableOpacity>
      )}
      <View style={styles.menuDivider} />

      {/* Assign Product Button */}
      {assignButtonConfig && (
        <TouchableOpacity style={styles.menuItem} onPress={handleAssign}>
          <Text style={styles.menuText}>{assignButtonConfig.label}</Text>
        </TouchableOpacity>
      )}
      <View style={styles.menuDivider} />

      {/* Delete Button */}
      {deleteButtonConfig && (
        <TouchableOpacity style={styles.menuItem} onPress={handleDelete}>
          <Text style={[styles.menuText, styles.deleteText]}>
            {deleteButtonConfig.label}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <View style={[styles.card, {position: 'relative'}]}>
      <View style={styles.cardHeader}>
        {uiConfig.find(f => f.fieldName === 'title_label') && (
          <Text style={styles.dealTitle}>{dealName}</Text>
        )}

        <TouchableOpacity onPress={() => setIsMenuVisible(!isMenuVisible)}>
          <Feather name="more-vertical" size={24} color={Colors.mediumText} />
        </TouchableOpacity>

        {isMenuVisible && <ActionMenu />}
      </View>

      {uiConfig.find(f => f.fieldName === 'subtitle_label') && (
        <Text style={styles.dealType}>{discountType} Deal</Text>
      )}

      <View style={styles.offerRow}>
        {offerField && (
          <View style={styles.offerBadge}>
            <Text style={styles.offerText}>{offerText}</Text>
          </View>
        )}
      </View>

      <View style={styles.statusRow}>
        <View style={styles.validityContainerNew}>
          <View style={styles.validityHeaderRow}>
            {uiConfig.find(f => f.fieldName === 'labelchip2') && (
              <Text style={styles.validityLabel}>Validity</Text>
            )}

            <View
              style={[
                styles.statusBadgeNew,
                {
                  backgroundColor: statusBg,
                  borderColor:
                    status === 'Active'
                      ? Colors.activeGreen
                      : Colors.borderColor,
                  borderWidth: 1,
                },
              ]}>
              <Text style={[styles.statusText, {color: statusColor}]}>
                {status}
              </Text>
            </View>
          </View>

          {validityField && (
            <Text style={styles.validityDateText}>{validityText}</Text>
          )}
        </View>

        {/* --- CHECKBOX LOGIC START --- */}
        <View
          style={[
            styles.checkboxNew,
            // Apply active (orange) or inactive (white/bordered) styles
            isActive ? styles.checkboxActive : styles.checkboxInactive,
          ]}>
          {isActive ? (
            // If Active, show the white checkmark
            <AntDesign name="check" size={16} color={Colors.white} />
          ) : // If Inactive, keep the box empty (no icon)
          null}
        </View>
        {/* --- CHECKBOX LOGIC END --- */}
      </View>
    </View>
  );
};

const findFieldByFieldType = (page, targetFieldType) => {
  if (!page || !page.sections) return null;

  // Iterate through all sections in the page
  for (const section of page.sections) {
    if (section.fields) {
      // Find the first matching fieldType within the current section's fields
      const foundField = section.fields.find(
        f => f.fieldType === targetFieldType,
      );
      if (foundField) {
        return foundField; // Return the first button found
      }
    }
  }
  return null;
};

// --- Filter Modal Component (Dynamically populated from config) ---
const FilterModal = ({
  isVisible,
  onClose,
  onApply,
  onReset,
  filterConfig,
  currentFilterValue,
}) => {
  // Find the default "all" value or the first option
  const initialFilterValue =
    filterConfig?.options.find(opt => opt.value === 'all')?.value ||
    filterConfig?.options[0]?.value ||
    'all';

  // Local state to manage the temporary selection within the modal
  const [tempSelectedFilter, setTempSelectedFilter] = useState(
    currentFilterValue || initialFilterValue,
  );

  // Initialize local state when modal opens
  useEffect(() => {
    if (isVisible) {
      setTempSelectedFilter(currentFilterValue || initialFilterValue);
    }
  }, [isVisible, currentFilterValue, initialFilterValue]);

  // Reset the internal selected filter state and notify parent
  const handleReset = () => {
    setTempSelectedFilter(initialFilterValue);
    // onReset(initialFilterValue);
  };

  const handleApply = () => {
    onClose();
    onApply(tempSelectedFilter);
  };

  const filterOptions = filterConfig?.options || [];

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={isVisible}
      onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Filters</Text>
            <TouchableOpacity onPress={handleReset}>
              <Text style={styles.resetText}>Reset all</Text>
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {filterConfig && (
              <View style={styles.filterSection}>
                <Text style={styles.filterSectionTitle}>
                  {filterConfig.label || 'Filter'}
                </Text>

                {/* Dynamic Radio Button List */}
                <View style={styles.optionsContainer}>
                  {filterOptions.map((option, index) => (
                    <TouchableOpacity
                      key={option.value}
                      style={[
                        styles.optionItem,
                        index === filterOptions.length - 1 && {
                          borderBottomWidth: 0,
                        },
                      ]}
                      onPress={() => setTempSelectedFilter(option.value)}>
                      <Text style={styles.optionLabel}>{option.label}</Text>
                      <View
                        style={[
                          styles.radioCircle,
                          tempSelectedFilter === option.value &&
                            styles.radioCircleSelected,
                        ]}>
                        {tempSelectedFilter === option.value && (
                          <View style={styles.radioDot} />
                        )}
                      </View>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            )}
            <View style={{height: 100}} />
          </ScrollView>

          <TouchableOpacity style={styles.applyButton} onPress={handleApply}>
            <Text style={styles.applyButtonText}>Apply Filters</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

// --- Main Deals and Discount Screen ---
const DealsDiscountScreen = () => {
  const navigation = useNavigation();

  // --- JSON CONFIG EXTRACTION ---
  const searchFilterPage = STATIC_DEALS_UI_CONFIG.pages.find(
    p => p.pageId === 1,
  );
  const dealsListPage = STATIC_DEALS_UI_CONFIG.pages.find(p => p.pageId === 2);

  const searchFieldConfig = searchFilterPage?.sections
    .find(s => s.name === 'SearchFilter')
    ?.fields.find(f => f.fieldName === 'search');
  const filterFieldConfig = searchFilterPage?.sections
    .find(s => s.name === 'SearchFilter')
    ?.fields.find(f => f.fieldName === 'filter');

  // const createButtonConfig = dealsListPage?.sections.find(s => s.name === 'CreateButton')?.fields.find(f => f.fieldName === 'btn_create');
  const createButtonConfig = findFieldByFieldType(dealsListPage, 'Button');
  const dealCardConfig = dealsListPage?.sections.find(
    s => s.name === 'DealCard',
  )?.fields;
  // --- END JSON CONFIG EXTRACTION ---

  // 1. STATE FOR SEARCH, PAGINATION, AND FILTERS
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [filters, setFilters] = useState({}); // Stores status filter (or other key/value filters)
  const [searchTerm, setSearchTerm] = useState('');
  const [apiQuery, setApiQuery] = useState(''); // Search term sent to API 'q' parameter
  const [cumulativeDealsData, setCumulativeDealsData] = useState([]);
  const [isFilterVisible, setIsFilterVisible] = useState(false);

  // Get the currently applied filter value for initialization of the Modal
  const activeFilterValue =
    filters.status ||
    filterFieldConfig?.options.find(opt => opt.value === 'all')?.value ||
    'all';

  // 2. DEFINE THE COMBINED FILTERS OBJECT FOR THE HOOK
  // Filters are combined from status filters and the search query (q)
  const combinedFilters = {
    ...filters,
    q: apiQuery,
  };

  // 3. ACCESS AND CALL THE REACT QUERY HOOKS
  const {useFetchDeals, useDeleteDeal} = useDealForm();

  // Fetch deals list using the current page, size, and filters
  const {
    data: dealListResponse,
    isLoading,
    isFetching,
  } = useFetchDeals(page, pageSize, combinedFilters);

  console.log('dealListResponse', dealListResponse);
  // Initialize the delete mutation hook
  const {mutate: deleteDeal, isLoading: isDeleting} = useDeleteDeal();

  // 4. Update cumulative data when new data arrives (Pagination Logic)
  useEffect(() => {
    if (dealListResponse?.items) {
      const newDeals = dealListResponse.items;

      if (page === 1) {
        // For first page or new search/filter, replace data
        setCumulativeDealsData(newDeals);
      } else {
        // For subsequent pages (infinite scroll), append data
        setCumulativeDealsData(prev => [...prev, ...newDeals]);
      }
    }
  }, [dealListResponse, page]);

  // Check if there are more deals to load
  const hasMore = dealListResponse?.hasNextPage || false;

  // Handler to load the next page
  const handleLoadMore = () => {
    if (hasMore && !isFetching) {
      setPage(prevPage => prevPage + 1);
    }
  };

  // Infinite scroll trigger logic
  const handleScroll = event => {
    const {layoutMeasurement, contentOffset, contentSize} = event.nativeEvent;
    const paddingToBottom = 20; // Distance from the bottom to trigger load
    const isCloseToBottom =
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom;

    if (isCloseToBottom) {
      handleLoadMore();
    }
  };

  // 5. HANDLERS

  // Handles text input change for search
  const handleSearchChange = useCallback(text => {
    setSearchTerm(text);
  }, []);

  // Handles search submission (via button or keyboard)
  const handleSearchSubmit = useCallback(() => {
    setApiQuery(searchTerm);
    setPage(1); // Reset to first page
    setCumulativeDealsData([]); // Reset data to fetch new search results
  }, [searchTerm]);

  /**
   * Handles filter application from the modal.
   * Crucially resets page to 1 and clears cumulative data for fresh load.
   * If 'all' is selected, the filters state is cleared to fetch all deals.
   */
  const handleApplyFilter = useCallback(selectedFilterValue => {
    // 1. Set the filters state
    if (selectedFilterValue === 'all') {
      // 'All Deals' selected: Clear the status filter
      setFilters({});
    } else {
      // Specific filter selected: Set the status filter
      setFilters({status: selectedFilterValue});
    }

    // 2. Reset to the first page and clear current data
    setPage(1);
    setCumulativeDealsData([]);
  }, []);

  // Handles filter reset from the modal
  const handleResetFilter = useCallback(initialFilterValue => {
    // Reset the main filter state (equivalent to selecting 'all')
    setFilters({});
    setCumulativeDealsData([]);
    setPage(1);
  }, []);

  // Handles the deletion of a deal
  const handleDeleteDeal = useCallback(
    (dealId, endpoint, method, dealName) => {
      Alert.alert(
        'Confirm Deletion',
        `Are you sure you want to delete the deal: ${dealName}?`,
        [
          {text: 'Cancel', style: 'cancel'},
          {
            text: 'Delete',
            style: 'destructive',
            onPress: () => {
              // Call the mutation hook with the required payload
              deleteDeal({dealId, endpoint, method});
            },
          },
        ],
      );
    },
    [deleteDeal],
  );

  // Handles navigation to the Create Deal screen
  const handleCreateDeal = () => {
    if (createButtonConfig?.endpoint && createButtonConfig?.method) {
      navigation.navigate('CreateDeal', {
        apiEndpoint: createButtonConfig.endpoint,
        apiMethod: createButtonConfig.method,
      });
    } else {
      Alert.alert(
        'Configuration Error',
        'Create button endpoint or method is missing in UI config.',
      );
    }
  };

  // --- Main Render ---
  const dealsToRender = cumulativeDealsData;

  return (
    <View style={styles.container}>
      <Header title={dealsListPage?.title || 'Deals List'} />

      {/* --- SEARCH AND FILTER SECTION --- */}
      <View style={styles.searchFilterContainer}>
        {searchFieldConfig && (
          <TextInput
            style={styles.searchInput}
            placeholder={searchFieldConfig.placeholder || 'Search deals'}
            placeholderTextColor={Colors.lightText}
            value={searchTerm}
            onChangeText={handleSearchChange}
            onSubmitEditing={handleSearchSubmit}
            returnKeyType="search"
          />
        )}

        {filterFieldConfig && (
          <TouchableOpacity
            style={styles.filterButton}
            onPress={() => setIsFilterVisible(true)}>
            <Ionicons name="filter-outline" size={24} color={Colors.darkText} />
          </TouchableOpacity>
        )}
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16} // Standard value for smooth scrolling checks
      >
        {/* --- CREATE BUTTON --- */}
        {createButtonConfig && (
          <View style={styles.createButtonContainer}>
            <PrimaryButton
              title={createButtonConfig.label || 'Create'}
              onPress={handleCreateDeal}
              isLoading={isDeleting}
            />
          </View>
        )}
        {/* Initial Loading Indicator */}
        {isLoading && dealsToRender.length === 0 && (
          <ActivityIndicator
            size="large"
            color={Colors.primaryOrange}
            style={{marginVertical: 20}}
          />
        )}
        {/* Empty State Message */}
        {!isLoading && dealsToRender.length === 0 && (
          <View style={styles.emptyStateContainer}>
            <Ionicons
              name="pricetags-outline"
              size={50}
              color={Colors.lightText}
            />
            <Text style={styles.emptyStateText}>No Deals Found.</Text>
            <Text style={styles.emptyStateSubText}>
              Tap 'Create' to add a new deal or adjust filters.
            </Text>
          </View>
        )}
        {/* Deal List */}
        {dealsToRender.map((deal, index) => (
          <DealCard
            key={deal.id || index}
            deal={deal}
            uiConfig={dealCardConfig}
            onDelete={handleDeleteDeal}
            // Add onEdit and onAssignProduct handlers here if navigation is needed
          />
        ))}
        {/* Load More/Pagination Indicator */}
        {hasMore && isFetching && (
          <View style={styles.loadMoreContainer}>
            <ActivityIndicator size="small" color={Colors.primaryOrange} />
            <Text style={styles.loadMoreText}>Loading more deals...</Text>
          </View>
        )}
        <View style={{height: 50}} /> {/* Padding for bottom content */}
      </ScrollView>

      {/* Filter Modal */}
      <FilterModal
        isVisible={isFilterVisible}
        onClose={() => setIsFilterVisible(false)}
        onApply={handleApplyFilter}
        onReset={handleResetFilter}
        filterConfig={filterFieldConfig}
        currentFilterValue={activeFilterValue}
      />

      {/* Deletion Loading Overlay */}
      {isDeleting && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color={Colors.primaryOrange} />
          <Text style={styles.loadingText}>Deleting Deal...</Text>
        </View>
      )}
    </View>
  );
};

// --- Stylesheet ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.lightBg,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 15,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  searchFilterContainer: {
    flexDirection: 'row',
    padding: 15,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderColor,
  },
  searchInput: {
    flex: 1,
    height: 40,
    backgroundColor: Colors.lightBg,
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    color: Colors.darkText,
    marginRight: 10,
  },
  filterButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.borderColor,
    backgroundColor: Colors.white,
  },
  createButtonContainer: {
    marginVertical: 15,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: Colors.borderColor,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.1,
    shadowRadius: 1.5,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dealTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.darkText,
    flexShrink: 1,
    marginRight: 10,
  },
  dealType: {
    fontSize: 14,
    color: Colors.mediumText,
    marginBottom: 8,
  },
  offerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  offerBadge: {
    backgroundColor: Colors.lightOrangeBg,
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 10,
  },
  offerText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.primaryOrange,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: Colors.inactiveGray,
  },
  validityContainerNew: {
    flex: 1,
  },
  validityHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  validityLabel: {
    fontSize: 12,
    color: Colors.lightText,
    fontWeight: '500',
  },
  statusBadgeNew: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 12,
    marginLeft: 10,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  validityDateText: {
    fontSize: 14,
    color: Colors.darkText,
    marginTop: 4,
  },
  checkboxNew: {
    width: 24, // Slightly larger for better visual
    height: 24,
    borderRadius: 4,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
    // Default border color when inactive
    borderColor: Colors.borderColor,
  },
  checkboxInactive: {
    // Empty Checkbox Style
    backgroundColor: Colors.white,
    borderColor: Colors.borderColor,
  },
  checkboxActive: {
    // Checked Checkbox (Orange) Style
    backgroundColor: Colors.primaryOrange,
    borderColor: Colors.primaryOrange,
  },
  actionMenu: {
    position: 'absolute',
    top: 30,
    right: 0,
    backgroundColor: Colors.white,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.borderColor,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    zIndex: 10,
    minWidth: 150,
    paddingVertical: 5,
  },
  menuItem: {
    padding: 10,
  },
  menuText: {
    fontSize: 16,
    color: Colors.darkText,
  },
  menuDivider: {
    height: 1,
    backgroundColor: Colors.inactiveGray,
  },
  deleteText: {
    color: Colors.dangerRed,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: Colors.white,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.darkText,
  },
  resetText: {
    fontSize: 16,
    color: Colors.primaryOrange,
  },
  filterSectionTitle: {
    fontSize: 14,
    color: Colors.mediumText,
    marginBottom: 5,
    marginTop: 15,
    fontWeight: '500',
  },
  applyButton: {
    backgroundColor: Colors.primaryOrange,
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  applyButtonText: {
    color: Colors.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 100,
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: Colors.darkText,
  },
  loadMoreContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
  },
  loadMoreText: {
    marginLeft: 8,
    fontSize: 14,
    color: Colors.mediumText,
  },
  emptyStateContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 80,
  },
  emptyStateText: {
    fontSize: 18,
    color: Colors.mediumText,
    marginTop: 15,
    fontWeight: 'bold',
  },
  emptyStateSubText: {
    fontSize: 14,
    color: Colors.lightText,
    marginTop: 5,
  },
  optionsContainer: {
    marginTop: 10,
    backgroundColor: Colors.white,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.borderColor,
  },
  optionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.inactiveGray,
  },
  optionLabel: {
    fontSize: 16,
    color: Colors.darkText,
  },
  radioCircle: {
    height: 20,
    width: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: Colors.lightText,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioCircleSelected: {
    borderColor: Colors.primaryOrange,
  },
  radioDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.primaryOrange,
  },
});

export default DealsDiscountScreen;
